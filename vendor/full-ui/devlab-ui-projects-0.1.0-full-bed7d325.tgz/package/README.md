# @devlab/ui-projects

Exact source snapshot from DevLab-Full `plugins/ui-projects`. Public ESM, declarations and stylesheet exports follow the existing reusable package conventions. Source files are unchanged; no package was published.
