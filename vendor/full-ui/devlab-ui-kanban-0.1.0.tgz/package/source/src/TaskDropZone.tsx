import { useState } from 'react';
import type { ReactNode } from 'react';
import type { BoardData, TaskStatus } from './types.ts';
import type { BoardInteractions } from './interactions.ts';
import { sliceTasks } from './model.ts';
interface Props {
  readonly data: BoardData;
  readonly sliceId: string;
  readonly interaction: BoardInteractions;
  readonly status?: TaskStatus;
  readonly beforeTaskId?: string;
  readonly className?: string;
  readonly children: ReactNode;
}
export function TaskDropZone({
  data,
  sliceId,
  interaction,
  status,
  beforeTaskId,
  className = '',
  children,
}: Props) {
  const [hovered, setHovered] = useState(false);
  const dragged = data.tasks.find(
    (task) => task.id === interaction.draggedTaskId,
  );
  const source = data.slices.find((slice) => slice.id === dragged?.sliceId);
  const target = data.slices.find((slice) => slice.id === sliceId);
  const allowed =
    !interaction.disabled &&
    Boolean(
      dragged &&
        source &&
        target &&
        (status
          ? dragged.sliceId === sliceId
          : source.milestoneId === target.milestoneId),
    );
  return (
    <div
      className={`kf-drop ${className}${hovered && allowed ? ' kf-drop--active' : ''}`}
      data-ui="kanban.drop"
      data-devlab-id="kanban.drop"
      data-devlab-source="plugins/ui-kanban/src/TaskDropZone.tsx"
      data-drop-slice={sliceId}
      data-drop-status={status}
      data-before-task={beforeTaskId}
      onDragOver={(event) => {
        if (allowed) {
          event.preventDefault();
          event.stopPropagation();
          event.dataTransfer.dropEffect = 'move';
          setHovered(true);
        }
      }}
      onDragLeave={(event) => {
        if (
          !(event.relatedTarget instanceof Node) ||
          !event.currentTarget.contains(event.relatedTarget)
        )
          setHovered(false);
      }}
      onDrop={(event) => {
        if (!allowed || !dragged) return;
        event.preventDefault();
        event.stopPropagation();
        setHovered(false);
        interaction.setDraggedTask(null);
        if (status) {
          if (status === dragged.status) return;
          if (status === 'review') {
            interaction.explain(
              'Use Verify declared checks in the inspector. Dragging never executes project checks.',
            );
            return;
          }
          const action =
            status === 'running'
              ? 'begin'
              : status === 'complete'
                ? 'finish'
                : 'reset';
          interaction.run({ action, taskId: dragged.id });
        } else {
          if (beforeTaskId === dragged.id) return;
          const destination = sliceTasks(data, sliceId).filter(
            (task) => task.id !== dragged.id,
          );
          const position = beforeTaskId
            ? destination.findIndex((task) => task.id === beforeTaskId)
            : destination.length;
          interaction.run({
            action: 'move',
            taskId: dragged.id,
            targetSliceId: sliceId,
            position,
          });
        }
      }}
    >
      {children}
    </div>
  );
}
