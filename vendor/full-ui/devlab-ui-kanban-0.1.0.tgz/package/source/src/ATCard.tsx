import { isBlocked } from './model.ts';
import { STATUS_LABELS } from './types.ts';
import type { AtomicTask, BoardData } from './types.ts';
import type { BoardInteractions } from './interactions.ts';
interface Props {
  readonly task: AtomicTask;
  readonly data: BoardData;
  readonly interaction: BoardInteractions;
  readonly compact?: boolean;
}
export function ATCard({ task, data, interaction, compact = false }: Props) {
  const blocked = isBlocked(data, task);
  const draggable =
    !interaction.disabled &&
    task.availableActions.some((action) =>
      ['begin', 'finish', 'move', 'reset'].includes(action),
    );
  return (
    <button
      type="button"
      className={`kf-task${compact ? ' kf-task--compact' : ''}`}
      data-ui="kanban.task"
      data-devlab-id="kanban.task"
      data-devlab-source="plugins/ui-kanban/src/ATCard.tsx"
      data-task-id={task.id}
      id={`kanban-task-${task.id}`}
      aria-pressed={interaction.selectedTaskId === task.id}
      aria-label={`${task.id}: ${task.title}, ${STATUS_LABELS[task.status]}${blocked ? ', blocked' : ''}`}
      draggable={draggable}
      onClick={(event) => interaction.selectTask(task.id, event.currentTarget)}
      onDragStart={(event) => {
        event.dataTransfer.setData('text/plain', task.id);
        event.dataTransfer.effectAllowed = 'move';
        interaction.setDraggedTask(task.id);
      }}
      onDragEnd={() => interaction.setDraggedTask(null)}
    >
      <span className="kf-task-top">
        <span className="kf-id">{task.id}</span>
        <span
          className="kf-status"
          data-status={blocked ? 'blocked' : task.status}
        >
          {blocked ? 'Blocked' : STATUS_LABELS[task.status]}
        </span>
      </span>
      <span className="kf-task-title">{task.title}</span>
      {!compact && (
        <span className="kf-task-bottom">
          <span>{task.kind || 'Task'}</span>
          <span>
            {task.dependsOn.length
              ? `${task.dependsOn.length} dependencies`
              : 'No prerequisites'}
          </span>
        </span>
      )}
    </button>
  );
}
