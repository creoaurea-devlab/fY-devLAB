import { useEffect, useRef, useState } from 'react';
import { STATUS_LABELS } from './types.ts';
import type { AtomicTask, BoardData } from './types.ts';
import type { BoardInteractions } from './interactions.ts';
import { ordered, sliceTasks, unfinishedDependencies } from './model.ts';
interface Props {
  readonly task: AtomicTask;
  readonly data: BoardData;
  readonly interaction: BoardInteractions;
  readonly onClose: () => void;
}
export function TaskInspector({ task, data, interaction, onClose }: Props) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const [confirmVerify, setConfirmVerify] = useState(false);
  useEffect(() => {
    closeRef.current?.focus();
    setConfirmVerify(false);
  }, [task.id]);
  const slice = data.slices.find((item) => item.id === task.sliceId);
  const milestone = data.milestones.find(
    (item) => item.id === slice?.milestoneId,
  );
  const segment = data.segments.find(
    (item) => item.id === milestone?.segmentId,
  );
  const siblings = sliceTasks(data, task.sliceId),
    index = siblings.findIndex((item) => item.id === task.id);
  const dependencies = unfinishedDependencies(data, task);
  const slices = ordered(
    data.slices.filter((item) => item.milestoneId === milestone?.id),
  );
  const can = (action: AtomicTask['availableActions'][number]) =>
    !interaction.disabled && task.availableActions.includes(action);
  const move = (position: number) =>
    interaction.run({
      action: 'move',
      taskId: task.id,
      targetSliceId: task.sliceId,
      position,
    });
  return (
    <aside
      className="kf-inspector"
      aria-label={`Details for ${task.id}`}
      data-ui="kanban.inspector"
      data-devlab-id="kanban.inspector"
      data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
      onKeyDown={(event) => {
        if (event.key === 'Escape') {
          event.stopPropagation();
          onClose();
        }
      }}
    >
      <header className="kf-inspector-head">
        <span className="kf-eyebrow">{task.id}</span>
        <button
          ref={closeRef}
          type="button"
          className="kf-icon-button"
          data-ui="kanban.inspector.close"
          data-devlab-id="kanban.inspector.close"
          data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
          onClick={onClose}
          aria-label="Close AT details"
        >
          ×
        </button>
      </header>
      <h3>{task.title}</h3>
      <p className="kf-breadcrumb">
        {segment?.title} / {milestone?.title}
        <br />
        {slice?.id} · {slice?.title}
      </p>
      <p className="kf-field">
        <span>Workflow status</span>
        <output
          data-ui="kanban.task.status"
          data-devlab-id="kanban.task.status"
          data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
        >
          {STATUS_LABELS[task.status]}
        </output>
      </p>
      <div className="kf-actions" aria-label="Task actions">
        <button
          type="button"
          data-ui="kanban.begin"
          data-devlab-id="kanban.begin"
          data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
          disabled={!can('begin')}
          onClick={() => interaction.run({ action: 'begin', taskId: task.id })}
        >
          Begin task
        </button>
        <button
          type="button"
          data-ui="kanban.verify"
          data-devlab-id="kanban.verify"
          data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
          disabled={!can('verify')}
          onClick={() => setConfirmVerify(true)}
        >
          Verify declared checks
        </button>
        <button
          type="button"
          data-ui="kanban.finish"
          data-devlab-id="kanban.finish"
          data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
          disabled={!can('finish')}
          onClick={() => interaction.run({ action: 'finish', taskId: task.id })}
        >
          Finish verified task
        </button>
        <button
          type="button"
          data-ui="kanban.reset"
          data-devlab-id="kanban.reset"
          data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
          disabled={!can('reset')}
          onClick={() => interaction.run({ action: 'reset', taskId: task.id })}
        >
          Reset preflight
        </button>
      </div>
      {data.reason && (
        <p role="status" className="kf-description">
          {data.reason}
        </p>
      )}
      {confirmVerify && (
        <section
          className="kf-verify"
          data-ui="kanban.verify.confirm"
          data-devlab-id="kanban.verify.confirm"
          data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
          aria-label="Declared verification commands"
        >
          <p>Run these exact project checks:</p>
          <pre>
            {task.checks.map((check) => JSON.stringify(check.argv)).join('\n')}
          </pre>
          <div className="kf-actions">
            <button
              type="button"
              data-ui="kanban.verify.run"
              data-devlab-id="kanban.verify.run"
              data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
              disabled={!can('verify')}
              onClick={() => {
                setConfirmVerify(false);
                interaction.run({ action: 'verify', taskId: task.id });
              }}
            >
              Run checks
            </button>
            <button
              type="button"
              data-ui="kanban.verify.cancel"
              data-devlab-id="kanban.verify.cancel"
              data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
              onClick={() => setConfirmVerify(false)}
            >
              Cancel
            </button>
          </div>
        </section>
      )}
      <label className="kf-field">
        Parent SL
        <select
          aria-label="Parent SL"
          data-ui="kanban.task.parent"
          data-devlab-id="kanban.task.parent"
          data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
          disabled={!can('move')}
          value={task.sliceId}
          onChange={(event) => {
            const id = event.currentTarget.value;
            interaction.run({
              action: 'move',
              taskId: task.id,
              targetSliceId: id,
              position: sliceTasks(data, id).filter(
                (item) => item.id !== task.id,
              ).length,
            });
          }}
        >
          {slices.map((item) => (
            <option key={item.id} value={item.id}>
              {item.id} · {item.title}
            </option>
          ))}
        </select>
      </label>
      <div className="kf-field">
        <span>Position in SL</span>
        <div className="kf-reorder">
          <button
            type="button"
            data-ui="kanban.task.move-up"
            data-devlab-id="kanban.task.move-up"
            data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
            disabled={!can('move') || index <= 0}
            onClick={() => move(index - 1)}
          >
            ↑ Move up
          </button>
          <button
            type="button"
            data-ui="kanban.task.move-down"
            data-devlab-id="kanban.task.move-down"
            data-devlab-source="plugins/ui-kanban/src/TaskInspector.tsx"
            disabled={!can('move') || index >= siblings.length - 1}
            onClick={() => move(index + 1)}
          >
            ↓ Move down
          </button>
        </div>
      </div>
      <div className="kf-detail-label">Write scope</div>
      <pre className="kf-description">
        {task.write.join('\n') || 'No source writes declared.'}
      </pre>
      <div className="kf-detail-label">Dependencies</div>
      <p className="kf-description">
        {task.dependsOn.join(', ') || 'No prerequisites.'}
      </p>
      {!!dependencies.length && (
        <p className="kf-dependencies">
          Waiting for: {dependencies.join(', ')}
        </p>
      )}
      {task.status === 'complete' && (
        <p className="kf-description">
          Completion is terminal. Plan a new scoped task to redo work.
        </p>
      )}
    </aside>
  );
}
