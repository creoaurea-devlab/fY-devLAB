import { createElement, lazy, Suspense } from 'react';
import type { UIPlugin, UIPluginProps } from '@devlab/ui-contracts';
const View = lazy(() =>
  import('./MilestoneBoard.tsx').then((module) => ({
    default: module.PlanningView,
  })),
);
function Contribution(props: UIPluginProps) {
  return createElement(
    Suspense,
    { fallback: createElement('p', { role: 'status' }, 'Loading planning…') },
    createElement(View, props),
  );
}
export const planningPanel: UIPlugin = {
  id: 'ui-kanban',
  apiVersion: 1,
  title: 'Project planning',
  slot: 'planning',
  Component: Contribution,
};
