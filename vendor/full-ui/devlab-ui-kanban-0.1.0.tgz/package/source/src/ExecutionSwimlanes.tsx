import { TASK_STATUSES, STATUS_LABELS } from './types.ts';
import type { BoardData, Slice } from './types.ts';
import type { BoardInteractions } from './interactions.ts';
import { sliceTasks } from './model.ts';
import { ATCard } from './ATCard.tsx';
import { TaskDropZone } from './TaskDropZone.tsx';

interface Props {
  readonly slices: readonly Slice[];
  readonly data: BoardData;
  readonly interaction: BoardInteractions;
}
export function ExecutionSwimlanes({ slices, data, interaction }: Props) {
  const sliceIds = new Set(slices.map((slice) => slice.id));
  const tasks = data.tasks.filter((task) => sliceIds.has(task.sliceId));
  return (
    <div className="kf-flow">
      <div className="kf-flow-head">
        <span className="kf-eyebrow">SL</span>
        {TASK_STATUSES.map((status) => (
          <div key={status} className="kf-flow-stage">
            <span className="kf-status" data-status={status}>
              {STATUS_LABELS[status]}
            </span>
            <span className="kf-flow-count">
              {tasks.filter((task) => task.status === status).length}
            </span>
          </div>
        ))}
      </div>
      {slices.map((slice) => (
        <section
          key={slice.id}
          className="kf-flow-row"
          aria-label={`${slice.id}: ${slice.title}`}
        >
          <header className="kf-flow-row-title">
            <span className="kf-eyebrow">{slice.id}</span>
            <h4>{slice.title}</h4>
          </header>
          {TASK_STATUSES.map((status) => {
            const matching = sliceTasks(data, slice.id).filter(
              (task) => task.status === status,
            );
            return (
              <TaskDropZone
                key={status}
                data={data}
                sliceId={slice.id}
                status={status}
                interaction={interaction}
                className="kf-flow-cell"
              >
                <div className="kf-mobile-stage">{STATUS_LABELS[status]}</div>
                {matching.map((task) => (
                  <ATCard
                    key={task.id}
                    task={task}
                    data={data}
                    interaction={interaction}
                    compact
                  />
                ))}
                {!matching.length && (
                  <span
                    className="kf-empty-cell"
                    aria-label={`No ${STATUS_LABELS[status].toLowerCase()} ATs`}
                  >
                    ·
                  </span>
                )}
              </TaskDropZone>
            );
          })}
        </section>
      ))}
      {!slices.length && (
        <div className="kf-empty">No SLs in this milestone.</div>
      )}
    </div>
  );
}
