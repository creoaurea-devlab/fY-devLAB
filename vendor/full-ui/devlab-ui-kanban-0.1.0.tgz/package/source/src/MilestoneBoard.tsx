import {
  useCallback,
  useEffect,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import type {
  ApplicationClient,
  ProjectWorkspace,
  UIPluginProps,
} from '@devlab/ui-contracts';
import type { PlanSnapshot } from '@devlab/contracts';
import type {
  BoardCommand,
  BoardPresentation,
  MilestoneBoardProps,
} from './types.ts';
import type { BoardInteractions } from './interactions.ts';
import { assertBoardCommand, assertBoardData, ordered } from './model.ts';
import { MilestoneSection } from './MilestoneSection.tsx';
import { TaskInspector } from './TaskInspector.tsx';
import './board.css';

/** Thin transport observer; canonical writes always go through client.planning. */
export function PlanningView({
  client,
  projectWorkspace,
  planningVisible = true,
}: UIPluginProps) {
  if (!client.planning || !projectWorkspace)
    return (
      <p
        role="status"
        data-ui="kanban.unavailable"
        data-devlab-id="kanban.unavailable"
        data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
      >
        Planning is unavailable in this workspace.
      </p>
    );
  return (
    <ProjectPlanning
      service={client.planning}
      owner={projectWorkspace}
      visible={planningVisible}
    />
  );
}
function readPresentation(
  key: string | undefined,
): BoardPresentation | undefined {
  try {
    if (!key) return;
    const raw = localStorage.getItem(key);
    if (!raw || raw.length > 16384) return;
    const value = JSON.parse(raw);
    if (
      value?.version !== 1 ||
      !['structure', 'execution'].includes(value.view)
    )
      return;
    const openMilestones: Record<string, string | null> = {};
    if (value.openMilestones && typeof value.openMilestones === 'object')
      for (const [key, id] of Object.entries(value.openMilestones).slice(
        0,
        100,
      )) {
        if (
          key.length <= 200 &&
          (id === null || (typeof id === 'string' && id.length <= 200))
        )
          Object.defineProperty(openMilestones, key, {
            value: id,
            enumerable: true,
            writable: true,
            configurable: true,
          });
      }
    return {
      view: value.view,
      segmentId:
        typeof value.segmentId === 'string' ? value.segmentId : undefined,
      selectedTaskId:
        typeof value.selectedTaskId === 'string' ? value.selectedTaskId : null,
      openMilestones,
    };
  } catch {
    return;
  }
}
function ProjectPlanning({
  service,
  owner,
  visible,
}: {
  service: NonNullable<ApplicationClient['planning']>;
  owner: ProjectWorkspace;
  visible: boolean;
}) {
  const workspace = useSyncExternalStore(owner.subscribe, owner.snapshot);
  const projectId = workspace.projectId,
    workspaceId = workspace.projects.find((p) => p.base)?.workspaceId;
  const preferenceKey = workspaceId
    ? 'devlab.kanban.presentation.v1:' + workspaceId + ':' + projectId
    : undefined;
  const [resource, setResource] = useState<{
    projectId: string;
    data: PlanSnapshot | null;
    error: string;
  }>({ projectId, data: null, error: '' });
  const generation = useRef(0),
    commandLock = useRef(false);
  const refresh = useRef<() => Promise<void>>(async () => {});
  const presentation = readPresentation(preferenceKey);
  const savePresentation = useCallback(
    (value: BoardPresentation) => {
      try {
        if (!preferenceKey) return;
        const raw = localStorage.getItem(preferenceKey);
        if (raw !== null && !readPresentation(preferenceKey)) return;
        localStorage.setItem(
          preferenceKey,
          JSON.stringify({ ...value, version: 1 }),
        );
      } catch {
        /* UI preferences never block canonical work. */
      }
    },
    [preferenceKey],
  );
  useEffect(() => {
    const token = ++generation.current;
    refresh.current = async () => {};
    if (!visible) return;
    let live = true,
      inFlight = false;
    setResource((previous) =>
      previous.projectId === projectId
        ? previous
        : { projectId, data: null, error: '' },
    );
    async function reload() {
      if (inFlight || !live) return;
      inFlight = true;
      try {
        const data = await service.snapshot(projectId);
        if (data.projectId !== projectId)
          throw new Error('Planning response belongs to a different project.');
        assertBoardData(data);
        if (live && generation.current === token)
          setResource((previous) =>
            previous.projectId === projectId &&
            previous.data &&
            previous.data.revision > data.revision
              ? previous
              : { projectId, data, error: '' },
          );
      } catch (error) {
        if (live && generation.current === token)
          setResource((previous) => ({
            ...previous,
            error: error instanceof Error ? error.message : String(error),
          }));
      } finally {
        inFlight = false;
      }
    }
    refresh.current = reload;
    void reload();
    const timer = setInterval(() => void reload(), 1200);
    return () => {
      live = false;
      clearInterval(timer);
    };
  }, [projectId, service, visible, preferenceKey]);
  const data = resource.projectId === projectId ? resource.data : null;
  const commit = async (command: BoardCommand) => {
    if (!data || owner.snapshot().projectId !== data.projectId)
      throw new Error('The selected project changed. Refresh the board.');
    if (commandLock.current)
      throw new Error('A planning command is still running.');
    const token = generation.current;
    commandLock.current = true;
    try {
      const next = await service.command({
        ...command,
        projectId: data.projectId,
        expectedRevision: data.revision,
        expectedDigest: data.digest,
        commandId: crypto.randomUUID(),
      });
      if (next.projectId !== data.projectId)
        throw new Error('Planning result belongs to a different project.');
      assertBoardData(next);
      if (
        generation.current === token &&
        owner.snapshot().projectId === data.projectId
      )
        setResource((previous) =>
          previous.data && previous.data.revision > next.revision
            ? previous
            : { projectId: data.projectId, data: next, error: '' },
        );
    } finally {
      commandLock.current = false;
      void refresh.current();
    }
  };
  return (
    <section
      className="kf-planning"
      aria-label="Project planning"
      data-ui="workspace.planning"
      data-devlab-id="workspace.planning"
      data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
    >
      <div className="kf-transport-status">
        <span>
          {projectId} · {data ? `revision ${data.revision}` : 'Loading plan…'}
        </span>
        <button
          type="button"
          data-ui="kanban.refresh"
          data-devlab-id="kanban.refresh"
          data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
          onClick={() => void refresh.current()}
        >
          Refresh plan
        </button>
      </div>
      {resource.error && resource.projectId === projectId && (
        <p
          role="alert"
          className="kf-read-error"
          data-ui="kanban.error"
          data-devlab-id="kanban.error"
          data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
        >
          {resource.error}
        </p>
      )}
      {data ? (
        <MilestoneBoard
          key={preferenceKey ?? projectId}
          data={data}
          onCommand={commit}
          presentation={presentation}
          onPresentation={savePresentation}
        />
      ) : (
        <p
          role="status"
          data-ui="kanban.loading"
          data-devlab-id="kanban.loading"
          data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
        >
          {resource.error
            ? 'The canonical plan is unavailable. Retry after checking its authority.'
            : 'Reading the canonical plan…'}
        </p>
      )}
    </section>
  );
}

export function MilestoneBoard({
  data,
  onCommand,
  presentation,
  onPresentation,
  className = '',
}: MilestoneBoardProps) {
  const [view, setView] = useState(presentation?.view ?? 'structure');
  const [segmentId, setSegmentId] = useState(presentation?.segmentId);
  const [openMilestones, setOpenMilestones] = useState<
    Readonly<Record<string, string | null>>
  >(presentation?.openMilestones ?? {});
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(
    presentation?.selectedTaskId ?? null,
  );
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false),
    [feedback, setFeedback] = useState({ message: '', error: false });
  const lock = useRef(false),
    opener = useRef<HTMLButtonElement | null>(null),
    viewButton = useRef<HTMLButtonElement>(null);
  const activeTask = data.tasks.find((t) => t.id === data.activeTaskId),
    activeSlice = data.slices.find((s) => s.id === activeTask?.sliceId),
    activeMilestone = data.milestones.find(
      (m) => m.id === activeSlice?.milestoneId,
    );
  const segments = ordered(data.segments),
    segment =
      segments.find((item) => item.id === segmentId) ??
      segments.find((item) => item.id === activeMilestone?.segmentId) ??
      segments[0];
  const milestones = ordered(
    data.milestones.filter((item) => item.segmentId === segment?.id),
  );
  const requestedOpen = segment ? openMilestones[segment.id] : undefined;
  const activeMilestoneId =
    requestedOpen === null
      ? null
      : (milestones.find((item) => item.id === requestedOpen)?.id ??
        milestones[0]?.id);
  const selectedTask = data.tasks.find((task) => task.id === selectedTaskId);
  useEffect(() => {
    onPresentation?.({ view, segmentId, openMilestones, selectedTaskId });
  }, [view, segmentId, openMilestones, selectedTaskId, onPresentation]);
  useEffect(() => {
    if (selectedTaskId && !selectedTask) {
      setSelectedTaskId(null);
      viewButton.current?.focus();
    }
  }, [selectedTaskId, selectedTask]);
  async function commit(command: BoardCommand) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setFeedback({ message: '', error: false });
    try {
      assertBoardCommand(data, command);
      await onCommand(command);
      setFeedback({
        message: `${command.taskId}: ${command.action} accepted.`,
        error: false,
      });
    } catch (error) {
      setFeedback({
        message: error instanceof Error ? error.message : 'The update failed.',
        error: true,
      });
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  function closeInspector() {
    setSelectedTaskId(null);
    if (opener.current?.isConnected) opener.current.focus();
    else viewButton.current?.focus();
  }
  const interaction: BoardInteractions = {
    busy,
    disabled: busy || !data.writable,
    selectedTaskId,
    draggedTaskId,
    selectTask: (id, button) => {
      opener.current = button;
      setSelectedTaskId(id);
    },
    setDraggedTask: setDraggedTaskId,
    run: (command) => void commit(command),
    explain: (message) => setFeedback({ message, error: true }),
  };
  return (
    <section
      className={`kf-board ${className}`}
      aria-label="Milestone dashboard"
      aria-busy={busy}
      data-ui="kanban.board"
      data-devlab-id="kanban.board"
      data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
    >
      <header className="kf-board-header">
        <div>
          <h2>Plan</h2>
          <p>Segment · Milestone · SL · AT</p>
        </div>
        <div className="kf-view-switch" role="group" aria-label="Board view">
          <button
            ref={viewButton}
            type="button"
            data-ui="kanban.view.structure"
            data-devlab-id="kanban.view.structure"
            data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
            aria-pressed={view === 'structure'}
            onClick={() => {
              setView('structure');
              setDraggedTaskId(null);
            }}
          >
            Structure
          </button>
          <button
            type="button"
            data-ui="kanban.view.execution"
            data-devlab-id="kanban.view.execution"
            data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
            aria-pressed={view === 'execution'}
            onClick={() => {
              setView('execution');
              setDraggedTaskId(null);
            }}
          >
            Execution
          </button>
        </div>
      </header>
      {!data.writable && (
        <p
          className="kf-readonly"
          role="status"
          data-ui="kanban.readonly"
          data-devlab-id="kanban.readonly"
          data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
        >
          {data.reason ||
            'This plan is read-only. Task actions are unavailable.'}
        </p>
      )}
      {!segment ? (
        <div
          className="kf-empty"
          data-ui="kanban.empty"
          data-devlab-id="kanban.empty"
          data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
        >
          No segments in this plan.
        </div>
      ) : (
        <>
          <div className="kf-segment-bar">
            <span className="kf-eyebrow">SEGMENT</span>
            <select
              data-ui="kanban.segment"
              data-devlab-id="kanban.segment"
              data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
              aria-label="Segment"
              value={segment.id}
              onChange={(event) => {
                setSegmentId(event.currentTarget.value);
                setSelectedTaskId(null);
                setDraggedTaskId(null);
              }}
            >
              {segments.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.title}
                </option>
              ))}
            </select>
            <span className="kf-segment-count">
              {milestones.length} milestones
            </span>
          </div>
          <div
            className={`kf-board-layout${selectedTask ? ' kf-board-layout--inspecting' : ''}`}
          >
            <div className="kf-milestone-list">
              {milestones.map((milestone) => (
                <MilestoneSection
                  key={milestone.id}
                  milestone={milestone}
                  data={data}
                  view={view}
                  expanded={activeMilestoneId === milestone.id}
                  interaction={interaction}
                  onToggle={() =>
                    setOpenMilestones((previous) => ({
                      ...previous,
                      [segment.id]:
                        activeMilestoneId === milestone.id
                          ? null
                          : milestone.id,
                    }))
                  }
                />
              ))}
              {!milestones.length && (
                <div className="kf-empty">No milestones in this segment.</div>
              )}
            </div>
            {selectedTask && (
              <TaskInspector
                task={selectedTask}
                data={data}
                interaction={interaction}
                onClose={closeInspector}
              />
            )}
          </div>
        </>
      )}
      <footer className="kf-footer">
        {view === 'structure'
          ? 'Drag within one milestone to organize ATs.'
          : 'Drag within one SL row to request a guarded status action.'}{' '}
        Select an AT for keyboard controls and explicit verification.
      </footer>
      <div
        className={`kf-feedback${feedback.error ? ' kf-feedback--error' : ''}`}
        role={feedback.error ? 'alert' : 'status'}
        aria-live="polite"
        data-ui="kanban.feedback"
        data-devlab-id="kanban.feedback"
        data-devlab-source="plugins/ui-kanban/src/MilestoneBoard.tsx"
      >
        {busy ? 'Waiting for canonical acceptance…' : feedback.message}
      </div>
    </section>
  );
}
