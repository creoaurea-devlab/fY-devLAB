import type { AtomicTask, BoardCommand, BoardData } from './types.ts';
import { TASK_STATUSES } from './types.ts';
export class BoardCommandError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'BoardCommandError';
  }
}
export function ordered<
  T extends { readonly id: string; readonly position: number },
>(items: readonly T[]): T[] {
  return [...items].sort(
    (a, b) => a.position - b.position || a.id.localeCompare(b.id),
  );
}
export function sliceTasks(data: BoardData, sliceId: string): AtomicTask[] {
  return ordered(data.tasks.filter((task) => task.sliceId === sliceId));
}
export function milestoneTasks(
  data: BoardData,
  milestoneId: string,
): AtomicTask[] {
  const ids = new Set(
    data.slices
      .filter((slice) => slice.milestoneId === milestoneId)
      .map((slice) => slice.id),
  );
  return data.tasks.filter((task) => ids.has(task.sliceId));
}
export function taskProgress(tasks: readonly AtomicTask[]) {
  const done = tasks.filter((task) => task.status === 'complete').length;
  return {
    done,
    total: tasks.length,
    percent: tasks.length ? Math.round((done / tasks.length) * 100) : 0,
  };
}
export function unfinishedDependencies(
  data: BoardData,
  task: AtomicTask,
): string[] {
  return task.dependsOn.filter(
    (id) => data.tasks.find((other) => other.id === id)?.status !== 'complete',
  );
}
export function isBlocked(data: BoardData, task: AtomicTask): boolean {
  return (
    task.status !== 'complete' && unfinishedDependencies(data, task).length > 0
  );
}
/** Only view fields are projected; production schema and authority are checked by the service. */
export function assertBoardData(data: BoardData): void {
  for (const [name, entities] of Object.entries({
    segments: data.segments,
    milestones: data.milestones,
    slices: data.slices,
    tasks: data.tasks,
  })) {
    const ids = new Set<string>();
    for (const entity of entities) {
      if (!entity.id || ids.has(entity.id))
        throw new BoardCommandError(`Duplicate or empty ID in ${name}.`);
      if (!Number.isFinite(entity.position))
        throw new BoardCommandError(`Invalid position for ${entity.id}.`);
      ids.add(entity.id);
    }
  }
  for (const item of data.milestones)
    if (!data.segments.some((parent) => parent.id === item.segmentId))
      throw new BoardCommandError(`Missing segment for ${item.id}.`);
  for (const item of data.slices)
    if (!data.milestones.some((parent) => parent.id === item.milestoneId))
      throw new BoardCommandError(`Missing milestone for ${item.id}.`);
  for (const item of data.tasks) {
    if (!data.slices.some((parent) => parent.id === item.sliceId))
      throw new BoardCommandError(`Missing SL for ${item.id}.`);
    if (!TASK_STATUSES.includes(item.status))
      throw new BoardCommandError(`Invalid status for ${item.id}.`);
    for (const id of item.dependsOn)
      if (!data.tasks.some((task) => task.id === id))
        throw new BoardCommandError(`Missing dependency ${id} for ${item.id}.`);
  }
  const visiting = new Set<string>(),
    visited = new Set<string>();
  const byId = new Map(data.tasks.map((task) => [task.id, task]));
  function visit(id: string): void {
    if (visiting.has(id))
      throw new BoardCommandError(`Dependency cycle at ${id}.`);
    if (visited.has(id)) return;
    visiting.add(id);
    for (const dependency of byId.get(id)?.dependsOn ?? []) visit(dependency);
    visiting.delete(id);
    visited.add(id);
  }
  data.tasks.forEach((task) => visit(task.id));
}
/** Helpful preflight only; never constructs a writable graph or fabricates proof. */
export function assertBoardCommand(
  data: BoardData,
  command: BoardCommand,
): void {
  if (!data.writable)
    throw new BoardCommandError(
      data.reason || 'This project plan is read-only.',
    );
  const task = data.tasks.find((item) => item.id === command.taskId);
  if (!task)
    throw new BoardCommandError('This AT no longer exists. Refresh the board.');
  if (!task.availableActions.includes(command.action))
    throw new BoardCommandError(
      'This action is unavailable for the current task state.',
    );
  if (command.action === 'move') {
    const source = data.slices.find((slice) => slice.id === task.sliceId);
    const target = data.slices.find(
      (slice) => slice.id === command.targetSliceId,
    );
    if (!source || !target)
      throw new BoardCommandError('The source or target SL no longer exists.');
    if (source.milestoneId !== target.milestoneId)
      throw new BoardCommandError(
        'Move ATs only between SLs in the same milestone.',
      );
    if (
      !Number.isInteger(command.position) ||
      command.position! < 0 ||
      command.position! >
        sliceTasks(data, target.id).filter((item) => item.id !== task.id).length
    )
      throw new BoardCommandError('The target position is invalid.');
    return;
  }
  if (task.status === 'complete')
    throw new BoardCommandError(
      'Completed ATs are terminal. Create a new scoped task to redo work.',
    );
  if (command.action === 'begin') {
    const waiting = unfinishedDependencies(data, task);
    if (task.status !== 'pending')
      throw new BoardCommandError('Only a Ready AT can begin.');
    if (waiting.length)
      throw new BoardCommandError(`Waiting for ${waiting.join(', ')}.`);
  } else if (
    command.action === 'verify' &&
    task.status !== 'running' &&
    task.status !== 'review'
  )
    throw new BoardCommandError('Begin this AT before verification.');
  else if (command.action === 'finish' && task.status !== 'review')
    throw new BoardCommandError('Run verification before finishing this AT.');
  else if (
    command.action === 'reset' &&
    task.status !== 'running' &&
    task.status !== 'review'
  )
    throw new BoardCommandError('Only active work can be reset.');
}
