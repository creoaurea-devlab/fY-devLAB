import { useId } from 'react';
import type { CSSProperties } from 'react';
import type { BoardData, BoardView, Milestone } from './types.ts';
import type { BoardInteractions } from './interactions.ts';
import { milestoneTasks, ordered, taskProgress } from './model.ts';
import { SLLane } from './SLLane.tsx';
import { ExecutionSwimlanes } from './ExecutionSwimlanes.tsx';

interface Props {
  readonly milestone: Milestone;
  readonly data: BoardData;
  readonly view: BoardView;
  readonly expanded: boolean;
  readonly onToggle: () => void;
  readonly interaction: BoardInteractions;
}
export function MilestoneSection({
  milestone,
  data,
  view,
  expanded,
  onToggle,
  interaction,
}: Props) {
  const bodyId = useId();
  const slices = ordered(
    data.slices.filter((slice) => slice.milestoneId === milestone.id),
  );
  const progress = taskProgress(milestoneTasks(data, milestone.id));
  const columns = {
    '--kf-lane-count': Math.max(1, Math.min(4, slices.length)),
  } as CSSProperties;
  return (
    <section className={`kf-milestone${expanded ? ' kf-milestone--open' : ''}`}>
      <h3 className="kf-milestone-heading">
        <button
          type="button"
          className="kf-milestone-toggle"
          data-ui="kanban.milestone.toggle"
          data-devlab-id="kanban.milestone.toggle"
          data-devlab-source="plugins/ui-kanban/src/MilestoneSection.tsx"
          data-milestone-id={milestone.id}
          aria-expanded={expanded}
          aria-controls={bodyId}
          onClick={onToggle}
        >
          <span className="kf-diamond" aria-hidden="true">
            ◇
          </span>
          <span className="kf-milestone-copy">
            <span className="kf-eyebrow">MILESTONE · {milestone.id}</span>
            <span className="kf-milestone-title">{milestone.title}</span>
          </span>
          <span className="kf-milestone-progress">
            <span>
              {progress.done} / {progress.total} AT done
            </span>
            <span className="kf-progress-track" aria-hidden="true">
              <span style={{ width: `${progress.percent}%` }} />
            </span>
          </span>
          <span className="kf-chevron" aria-hidden="true">
            {expanded ? '⌄' : '›'}
          </span>
        </button>
      </h3>
      <div id={bodyId} hidden={!expanded}>
        {view === 'structure' ? (
          <div className="kf-lanes" style={columns}>
            {slices.map((slice) => (
              <SLLane
                key={slice.id}
                slice={slice}
                data={data}
                interaction={interaction}
              />
            ))}
            {!slices.length && (
              <div className="kf-empty">No SLs in this milestone.</div>
            )}
          </div>
        ) : (
          <ExecutionSwimlanes
            slices={slices}
            data={data}
            interaction={interaction}
          />
        )}
      </div>
    </section>
  );
}
