import type { BoardCommand } from './types.ts';
export interface BoardInteractions {
  readonly selectedTaskId: string | null;
  readonly draggedTaskId: string | null;
  readonly busy: boolean;
  readonly disabled: boolean;
  readonly selectTask: (taskId: string, opener: HTMLButtonElement) => void;
  readonly setDraggedTask: (taskId: string | null) => void;
  readonly run: (command: BoardCommand) => void;
  readonly explain: (message: string) => void;
}
