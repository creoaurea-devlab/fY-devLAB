import type { BoardData, Slice } from './types.ts';
import type { BoardInteractions } from './interactions.ts';
import { sliceTasks } from './model.ts';
import { ATCard } from './ATCard.tsx';
import { TaskDropZone } from './TaskDropZone.tsx';

interface Props {
  readonly slice: Slice;
  readonly data: BoardData;
  readonly interaction: BoardInteractions;
}
export function SLLane({ slice, data, interaction }: Props) {
  const tasks = sliceTasks(data, slice.id);
  return (
    <section className="kf-lane" aria-label={`${slice.id}: ${slice.title}`}>
      <header className="kf-lane-head">
        <div>
          <div className="kf-eyebrow">{slice.id}</div>
          <h4>{slice.title}</h4>
        </div>
        <span className="kf-count">{tasks.length}</span>
      </header>
      <TaskDropZone
        data={data}
        sliceId={slice.id}
        interaction={interaction}
        className="kf-task-stack"
      >
        {tasks.map((task) => (
          <TaskDropZone
            key={task.id}
            data={data}
            sliceId={slice.id}
            beforeTaskId={task.id}
            interaction={interaction}
          >
            <ATCard task={task} data={data} interaction={interaction} />
          </TaskDropZone>
        ))}
        {!tasks.length && <div className="kf-empty-lane">No ATs yet</div>}
        <div className="kf-lane-tail" aria-hidden="true" />
      </TaskDropZone>
    </section>
  );
}
