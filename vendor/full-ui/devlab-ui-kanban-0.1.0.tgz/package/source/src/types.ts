import type { PlanCommand, PlanSnapshot, PlanTask } from '@devlab/contracts';
/** Canonical status names stay unchanged; Ready/Done are display labels only. */
export const TASK_STATUSES = [
  'pending',
  'running',
  'review',
  'complete',
] as const;
export type TaskStatus = PlanTask['status'];
export type AtomicTask = PlanTask;
export type BoardData = PlanSnapshot;
export type Segment = PlanSnapshot['segments'][number];
export type Milestone = PlanSnapshot['milestones'][number];
export type Slice = PlanSnapshot['slices'][number];
export type BoardView = 'structure' | 'execution';
export const STATUS_LABELS: Record<TaskStatus, string> = {
  pending: 'Ready',
  running: 'Running',
  review: 'Review',
  complete: 'Done',
};
export type BoardCommand = Pick<
  PlanCommand,
  'taskId' | 'action' | 'targetSliceId' | 'position'
>;
export interface BoardPresentation {
  readonly view: BoardView;
  readonly segmentId?: string;
  readonly openMilestones: Readonly<Record<string, string | null>>;
  readonly selectedTaskId: string | null;
}
export interface MilestoneBoardProps {
  readonly data: BoardData;
  /** Resolve only after the host commits. Rejection leaves this snapshot intact. */
  readonly onCommand: (command: BoardCommand) => void | Promise<void>;
  readonly presentation?: BoardPresentation;
  readonly onPresentation?: (value: BoardPresentation) => void;
  readonly className?: string;
}
