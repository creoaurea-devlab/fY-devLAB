# @creoaurea/pop-the-hood

Local reusable copy of `packages/pop-the-hood`. Node 24.18+; see the bundle README for Linux/native limits and composition.

Install through the containing bundle installer so all unpublished local dependencies resolve together.

Exports: `@creoaurea/pop-the-hood/contracts`, `@creoaurea/pop-the-hood/analyzer`, `@creoaurea/pop-the-hood/react`, `@creoaurea/pop-the-hood/graph`, `@creoaurea/pop-the-hood/layout`, `@creoaurea/pop-the-hood/node`, `@creoaurea/pop-the-hood/browser`, `@creoaurea/pop-the-hood/http`, `@creoaurea/pop-the-hood/style.css`.

Import `@creoaurea/pop-the-hood/style.css` once in your browser entry. Third-party stylesheet imports remain explicit.

Backend factories return the existing PluginDefinition; select them in your host profile and grant the required capabilities. React contributions need an ApplicationClient and their existing workspace owners. UI detach does not stop backend resources. Source and provenance are included; no additional license grant or new product behavior is implied.
