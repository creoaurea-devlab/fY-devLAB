/** Consumers import this contract, never the adapter implementation. */
export interface Greeting {
  greet(name: string): string;
}
export const greetingKey = 'greeting';
