import type { Greeting } from './contracts.js';
/** Replace this adapter without changing its consumers or plugin host. */
export function greetingAdapter(prefix = 'Hello'): Greeting {
  return { greet: (name) => `${prefix}, ${name.trim() || 'world'}!` };
}
