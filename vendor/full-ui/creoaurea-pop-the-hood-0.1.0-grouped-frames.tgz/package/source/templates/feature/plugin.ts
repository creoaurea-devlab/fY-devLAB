import { greetingKey, type Greeting } from './contracts.js';
import { greetingAdapter } from './adapter.js';
/** Adapt these two operations to Cordis, another DI host, or your application. */
export interface FeatureHost {
  provide<T>(key: string, value: T): () => void;
  onDispose(cleanup: () => void): void;
}
export function greetingPlugin(adapter: Greeting = greetingAdapter()) {
  return {
    id: 'greeting',
    provides: [greetingKey],
    requires: [] as string[],
    activate(host: FeatureHost) {
      host.onDispose(host.provide(greetingKey, adapter));
    },
  };
}
