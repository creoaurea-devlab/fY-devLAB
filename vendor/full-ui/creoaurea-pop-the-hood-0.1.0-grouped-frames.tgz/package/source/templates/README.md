# Pop the Hood

Install the local tarball and its optional live analyzer dependency:

```sh
npm install -D /path/to/creoaurea-pop-the-hood-0.1.0.tgz typescript@5.9.3
npx pop-the-hood . --projects ./projects --port 5420
```

Open http://127.0.0.1:5420. Supported source files are indexed automatically;
create/edit/rename/delete updates the graph. Project folders under `--projects`
appear automatically. This CLI is independent of devLAB/Cordis/Wisdom and does
not execute project scripts. Node 24+ is required; Linux is verified.

Embed the Node observer using `createHood` from the `/node` export, or mount the
optional loopback host with `startHoodServer` from `/http`. Browser applications
use `createHoodClient` from `/browser` and `HoodView` from `/react`. Install the
React/React Flow/Dagre/lucide peers listed in package.json when embedding that
viewer, and import `@creoaurea/pop-the-hood/style.css`. The standalone CLI ships
its own bundled browser assets and needs none of those peers installed.

Contract-only and static-artifact users need only Zod; the compiler loads only
for live analysis. `HoodView` accepts `client`, optional `onClose`, optional
`uiContributions`, and `theme: "dark" | "light" | "inherit"`. Call `close()` on
the observer/host when its owning plugin shuts down. This is read-only observation;
trusted application/plugin code still uses the host's actual lifecycle.

# Feature template

Copy `feature/` to `features/greeting/` in a TypeScript project. Copy its
`hood.registry.json` to the project root (merge its graph with any existing
registry; do not overwrite your own declarations).

- `contracts.ts`: public interface and service identity.
- `adapter.ts`: replaceable implementation.
- `plugin.ts`: feature factory; activation registers cleanup with its host.
- `hood.registry.json`: data-only wiring declaration, never runtime health proof.

Implement `FeatureHost.provide()` with your host's DI registration; its return
function removes that registration. Implement `onDispose()` with the owning
plugin's cleanup scope. Consumers depend on `Greeting`, not `greetingAdapter`.
For devLAB, wrap this feature in a `PluginDefinition` and use `scope.provide()` /
`scope.onDispose()`; declare the service in its typed contract. The microkernel
continues to own activation, dependencies and teardown.

Hood detects source files and imports without this manifest. Runtime registries
and IPC are explicit contracts: supply `HoodOptions.runtime` when embedding the
Node observer, or data-only declarations in the root `hood.registry.json`.
File declarations always have unknown health. An adapter may supply actual health.

To link an already running local app, create `hood.project.json` at the project
root: `{"label":"My app","previewUrl":"http://127.0.0.1:5173"}`. Its own framework
owns HMR. Hood opens this URL explicitly and does not run project scripts.
