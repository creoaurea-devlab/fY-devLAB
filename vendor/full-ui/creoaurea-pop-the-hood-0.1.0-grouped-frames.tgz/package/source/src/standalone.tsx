import { createRoot } from 'react-dom/client';
import { HoodView } from './react.tsx';
import { createHoodClient } from './browser.ts';
const root = document.getElementById('root');
if (!root) throw new Error('Missing Hood root');
createRoot(root).render(<HoodView client={createHoodClient()} theme="dark" />);
