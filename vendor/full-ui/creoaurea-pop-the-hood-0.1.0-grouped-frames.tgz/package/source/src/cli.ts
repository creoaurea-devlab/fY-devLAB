#!/usr/bin/env node
import { resolve } from 'node:path';
import { startHoodServer } from './http.ts';
const args = process.argv.slice(2);
if (args.includes('--help')) {
  console.log(
    'pop-the-hood [project-root] [--projects projects-directory] [--port 5420]\nRead-only live TypeScript architecture viewer. Node 24+ and TypeScript 5.9.3 required.\nCopyable feature templates: node_modules/@creoaurea/pop-the-hood/templates',
  );
} else {
  let root = '.',
    projectsRoot: string | undefined,
    port = 5420,
    positional = false;
  for (let i = 0; i < args.length; i++) {
    const arg = args[i]!;
    if (arg === '--projects' && args[i + 1]) projectsRoot = resolve(args[++i]!);
    else if (arg === '--port' && args[i + 1]) port = Number(args[++i]);
    else if (!arg.startsWith('-') && !positional) {
      root = arg;
      positional = true;
    } else throw new Error('Unknown or incomplete option: ' + arg);
  }
  const host = await startHoodServer({
    root: resolve(root),
    projectsRoot,
    port,
  });
  console.log(
    JSON.stringify({ name: 'pop-the-hood', phase: 'ready', url: host.url }),
  );
  let stopping = false;
  const stop = () => {
    if (stopping) return;
    stopping = true;
    const deadline = setTimeout(() => process.exit(1), 8000);
    deadline.unref();
    void host
      .close()
      .then(() => clearTimeout(deadline))
      .catch((error) => {
        console.error(error);
        process.exitCode = 1;
      });
  };
  process.once('SIGINT', stop);
  process.once('SIGTERM', stop);
}
