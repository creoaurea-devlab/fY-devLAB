import { z } from 'zod';

export const RegistryEvidenceSchema = z
  .object({
    path: z.string(),
    line: z.number().int().positive(),
    text: z.string().max(500),
  })
  .strict();
export const RegistryItemSchema = z
  .object({
    id: z.string().min(1),
    label: z.string(),
    kind: z.enum([
      'group',
      'module',
      'directory',
      'file',
      'symbol',
      'external',
      'plugin',
      'service',
      'channel',
      'client',
      'worker',
      'ui',
    ]),
    parentId: z.string().nullable(),
    path: z.string().optional(),
    line: z.number().int().positive().optional(),
    endLine: z.number().int().positive().optional(),
    detail: z.string(),
    sha256: z.string().optional(),
    bytes: z.number().int().nonnegative().optional(),
    exported: z.boolean().optional(),
  })
  .strict();
export type RegistryItem = z.infer<typeof RegistryItemSchema>;
export const RegistryEdgeSchema = z
  .object({
    id: z.string(),
    source: z.string(),
    target: z.string(),
    kind: z.enum([
      'import',
      'reexport',
      'contains',
      'provides',
      'requires',
      'live',
      'ipc',
      'ui',
    ]),
    label: z.string(),
    typeOnly: z.boolean().optional(),
    evidence: z.array(RegistryEvidenceSchema),
  })
  .strict();
export type RegistryEdge = z.infer<typeof RegistryEdgeSchema>;
export const RegistryChannelSchema = z
  .object({
    id: z.string(),
    title: z.string(),
    protocol: z.enum(['HTTP', 'SSE', 'Worker']),
    direction: z.enum(['request/reply', 'stream']),
    from: z.string(),
    to: z.string(),
    service: z.string().optional(),
    request: z.string(),
    response: z.string(),
    evidence: z.array(RegistryEvidenceSchema).min(1),
  })
  .strict();
export type RegistryChannel = z.infer<typeof RegistryChannelSchema>;
const GraphSchema = z
  .object({
    items: z.array(RegistryItemSchema).max(12000),
    edges: z.array(RegistryEdgeSchema).max(30000),
  })
  .strict();
function validateGraph(
  graph: z.infer<typeof GraphSchema>,
  ctx: z.RefinementCtx,
) {
  const ids = new Map(graph.items.map((i) => [i.id, i]));
  if (ids.size !== graph.items.length)
    ctx.addIssue({ code: 'custom', message: 'Duplicate registry item IDs' });
  const edgeIds = new Set(graph.edges.map((e) => e.id));
  if (edgeIds.size !== graph.edges.length)
    ctx.addIssue({ code: 'custom', message: 'Duplicate registry edge IDs' });
  for (const item of graph.items) {
    const visited = new Set<string>();
    let current: RegistryItem | undefined = item;
    while (current?.parentId) {
      if (visited.has(current.id)) {
        ctx.addIssue({ code: 'custom', message: 'Registry parent cycle' });
        break;
      }
      visited.add(current.id);
      const parent = ids.get(current.parentId);
      if (!parent) {
        ctx.addIssue({ code: 'custom', message: 'Missing registry parent' });
        break;
      }
      current = parent;
    }
  }
  for (const edge of graph.edges)
    if (!ids.has(edge.source) || !ids.has(edge.target))
      ctx.addIssue({ code: 'custom', message: 'Dangling registry wire' });
}
export const RegistryGraphSchema = GraphSchema.superRefine(validateGraph);
export const RegistryCatalogSchema = z
  .object({
    schemaVersion: z.literal(1),
    snapshotId: z.string().regex(/^[a-f0-9]{64}$/),
    builtAt: z.string().datetime(),
    graph: RegistryGraphSchema,
    channels: z.array(RegistryChannelSchema),
  })
  .strict();
export type RegistryCatalog = z.infer<typeof RegistryCatalogSchema>;
export const RegistryArtifactSchema = z
  .object({
    catalog: RegistryCatalogSchema,
    sources: z.record(z.string().max(131072)),
  })
  .strict();
export type RegistryArtifact = z.infer<typeof RegistryArtifactSchema>;
export const RegistryPluginSchema = z
  .object({
    id: z.string(),
    version: z.string(),
    provides: z.array(z.string()),
    requires: z.array(z.string()),
    live: z.array(z.string()),
    capabilities: z.array(z.string()),
    reload: z.enum(['idle', 'restart']),
    state: z.enum(['active', 'failed', 'disposed', 'unknown']),
    generation: z.number().int().nonnegative(),
    leases: z.number().int().nonnegative(),
  })
  .strict();
export const RegistrySnapshotSchema = z
  .object({
    catalog: RegistryCatalogSchema,
    plugins: z.array(RegistryPluginSchema),
    wiring: RegistryGraphSchema,
    observation: z
      .object({
        mode: z.enum(['live', 'snapshot']),
        projectId: z.string(),
        revision: z.number().int().nonnegative(),
        status: z.enum(['ready', 'stale']),
        message: z.string().optional(),
      })
      .strict()
      .optional(),
  })
  .strict();
export type RegistrySnapshot = z.infer<typeof RegistrySnapshotSchema>;
export const RegistrySourceSchema = z
  .object({
    path: z.string(),
    sha256: z.string(),
    text: z.string().max(131072),
  })
  .strict();
export type RegistrySource = z.infer<typeof RegistrySourceSchema>;
export const HoodProjectIdSchema = z
  .string()
  .regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}$/);
export const PreviewUrlSchema = z
  .string()
  .url()
  .refine((value) => {
    const url = new URL(value);
    return (
      url.protocol === 'http:' &&
      ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) &&
      !url.username &&
      !url.password
    );
  }, 'Preview must be a loopback HTTP URL without credentials');
export const ProjectConfigSchema = z
  .object({
    label: z.string().min(1).max(120).optional(),
    previewUrl: PreviewUrlSchema.optional(),
  })
  .strict();
export const RegistryProjectSchema = ProjectConfigSchema.extend({
  id: HoodProjectIdSchema,
  warning: z.string().optional(),
}).strict();
export type RegistryProject = z.infer<typeof RegistryProjectSchema>;
export const RegistryEventSchema = z
  .object({
    kind: z.enum(['snapshot', 'projects', 'error']),
    projectId: z.string(),
    revision: z.number().int().nonnegative(),
    message: z.string().optional(),
  })
  .strict();
export type RegistryEvent = z.infer<typeof RegistryEventSchema>;
export const RegistryRuntimeSchema = z
  .object({
    plugins: z.array(RegistryPluginSchema),
    wiring: RegistryGraphSchema,
  })
  .strict();
export type RegistryRuntime = z.infer<typeof RegistryRuntimeSchema>;
/** Notifications invalidate snapshots. Reconnect always fetches current state. */
export interface RegistryClient {
  snapshot(projectId?: string): Promise<RegistrySnapshot>;
  source(path: string, projectId?: string): Promise<RegistrySource>;
  projects?(): Promise<RegistryProject[]>;
  listen?(
    projectId: string,
    receive: (event: RegistryEvent) => void,
    error: () => void,
  ): () => void;
}
/** Static hosts can return synchronously; live adapters may return promises. */
export interface RegistryMap {
  snapshot(projectId?: string): RegistrySnapshot | Promise<RegistrySnapshot>;
  source(
    path: string,
    projectId?: string,
  ): RegistrySource | Promise<RegistrySource>;
  projects?(): Promise<RegistryProject[]>;
  subscribe?(
    projectId: string,
    receive: (event: RegistryEvent) => void,
  ): () => void;
}
export function canonicalJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (value !== null && typeof value === 'object') {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      .sort()
      .map((k) => `${JSON.stringify(k)}:${canonicalJson(record[k])}`)
      .join(',')}}`;
  }
  return JSON.stringify(value);
}
