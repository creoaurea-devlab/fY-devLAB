import ts from 'typescript';
import { readdir, realpath, lstat, open } from 'node:fs/promises';
import { resolve, dirname, basename, extname } from 'node:path';
import { constants } from 'node:fs';
import { createHash } from 'node:crypto';
import {
  RegistryArtifactSchema,
  canonicalJson,
  type RegistryArtifact,
  type RegistryItem,
  type RegistryEdge,
  type RegistryChannel,
} from './contracts.ts';

export interface AnalyzerOptions {
  roots?: string[];
  ignore?: string[];
}
export const ignoredDirectories = new Set([
  'node_modules',
  'dist',
  'vendor',
  'build',
  'build-output',
  'coverage',
  'secrets',
  'release',
  'out',
]);
const extensions = new Set([
  '.ts',
  '.tsx',
  '.mts',
  '.cts',
  '.js',
  '.jsx',
  '.mjs',
  '.cjs',
  '.css',
]);
const sha = (text: string) => createHash('sha256').update(text).digest('hex');
export async function analyzeProject(
  root: string,
  options: AnalyzerOptions = {},
): Promise<RegistryArtifact> {
  root = await realpath(root);
  const roots = options.roots ?? [''];
  if (
    roots.some(
      (p) =>
        p &&
        (p.startsWith('/') ||
          p.split('/').some((v) => !v || v === '.' || v === '..')),
    )
  )
    throw new Error('Invalid analyzer root');
  let directories = 0;
  const items: RegistryItem[] = [],
    edges: RegistryEdge[] = [],
    sources: Record<string, string> = {},
    paths: string[] = [];
  const known = new Set<string>();
  const parsed = new Map<string, ts.SourceFile>();
  function item(value: RegistryItem) {
    if (!known.has(value.id)) {
      known.add(value.id);
      items.push(value);
    }
  }
  async function walk(directory: string) {
    if (++directories > 2048)
      throw new Error('Project directory budget exceeded');
    const dir = resolve(root, directory);
    if ((await realpath(dir).catch(() => dir)) !== dir) return;
    let entries;
    try {
      entries = await readdir(resolve(root, directory), {
        withFileTypes: true,
      });
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return;
      throw error;
    }
    if (paths.length + entries.length > 12000)
      throw new Error('Project entry budget exceeded');
    for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
      if (
        entry.name.startsWith('.') ||
        ignoredDirectories.has(entry.name) ||
        options.ignore?.includes(entry.name)
      )
        continue;
      const path = directory ? directory + '/' + entry.name : entry.name;
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) await walk(path);
      else if (
        !/\.(?:pem|key|p12|pfx)$/.test(entry.name) &&
        (extensions.has(extname(path)) ||
          /^(package|tsconfig[^/]*|hood\.project|hood\.registry)\.json$/.test(
            entry.name,
          ))
      )
        paths.push(path);
    }
  }
  for (const name of roots) await walk(name);
  let total = 0;
  for (const path of paths) {
    const stat = await lstat(resolve(root, path));
    if (!stat.isFile() || stat.size > 131072)
      throw new Error(`Source preview too large: ${path}`);
    const text = await readProjectFile(root, path);
    total += Buffer.byteLength(text);
    if (total > 8 * 1024 * 1024)
      throw new Error('Registry source budget exceeded');
    sources[path] = text;
    const parts = path.split('/'),
      group = parts.length > 1 ? parts[0]! : 'project';
    item({
      id: 'group:' + group,
      label: group,
      kind: 'group',
      parentId: null,
      detail:
        group === 'plugins'
          ? 'Replaceable product capabilities'
          : 'Source ownership',
    });
    let parent = 'group:' + group;
    for (let i = 1; i < parts.length - 1; i++) {
      const folder = parts.slice(0, i + 1).join('/'),
        module = i === 1 && ['plugins', 'packages', 'apps'].includes(group),
        id = (module ? 'module:' : 'dir:') + folder;
      item({
        id,
        label: parts[i]!,
        kind: module ? 'module' : 'directory',
        parentId: parent,
        path: folder,
        detail: module ? 'Independent module' : 'Directory',
      });
      parent = id;
    }
    const id = 'file:' + path;
    item({
      id,
      label: basename(path),
      kind: 'file',
      parentId: parent,
      path,
      detail: `${text.split('\n').length} lines · ${stat.size} bytes`,
      sha256: sha(text),
      bytes: stat.size,
      line: 1,
      endLine: text.split('\n').length,
    });
    if (!/^\.[cm]?[jt]sx?$/.test(extname(path))) continue;
    const source = ts.createSourceFile(
      path,
      text,
      ts.ScriptTarget.Latest,
      true,
    );
    parsed.set(path, source);
    for (const statement of source.statements) {
      const line =
        source.getLineAndCharacterOfPosition(statement.getStart(source)).line +
        1;
      const endLine =
        source.getLineAndCharacterOfPosition(statement.end).line + 1;
      const exported =
        ts.canHaveModifiers(statement) &&
        Boolean(
          ts
            .getModifiers(statement)
            ?.some((m) => m.kind === ts.SyntaxKind.ExportKeyword),
        );
      const addSymbol = (name: string, kind: string) =>
        item({
          id: `symbol:${path}#${name}:${line}`,
          label: name,
          kind: 'symbol',
          parentId: id,
          path,
          line,
          endLine,
          detail: `${exported ? 'exported ' : ''}${kind}`,
          exported,
        });
      if (
        ts.isFunctionDeclaration(statement) ||
        ts.isClassDeclaration(statement) ||
        ts.isInterfaceDeclaration(statement) ||
        ts.isTypeAliasDeclaration(statement) ||
        ts.isEnumDeclaration(statement)
      ) {
        if (statement.name)
          addSymbol(
            statement.name.text,
            ts.SyntaxKind[statement.kind]!.replace(
              'Declaration',
              '',
            ).toLowerCase(),
          );
      } else if (ts.isVariableStatement(statement))
        for (const declaration of statement.declarationList.declarations)
          if (ts.isIdentifier(declaration.name))
            addSymbol(declaration.name.text, 'value');
    }
  }
  const absolute = new Map<string, string>();
  for (const path of paths)
    absolute.set(await realpath(resolve(root, path)), path);
  const moduleMap = new Map<string, string>();
  for (const path of paths.filter((p) => p.endsWith('/package.json'))) {
    const pkg = JSON.parse(sources[path]!);
    if (typeof pkg.name === 'string' && typeof pkg.exports === 'string')
      moduleMap.set(pkg.name, resolve(root, dirname(path), pkg.exports));
  }
  const configFile = ts.findConfigFile(root, ts.sys.fileExists);
  const compilerOptions =
    configFile && configFile.startsWith(root + '/')
      ? ts.parseJsonConfigFileContent(
          ts.readConfigFile(configFile, ts.sys.readFile).config,
          { ...ts.sys, readDirectory: () => [] },
          dirname(configFile),
        ).options
      : {
          moduleResolution: ts.ModuleResolutionKind.Bundler,
          allowImportingTsExtensions: true,
        };
  for (const path of paths.filter((p) => /^\.[cm]?[jt]sx?$/.test(extname(p)))) {
    const source = parsed.get(path)!;
    const imports: {
      specifier: string;
      line: number;
      kind: 'import' | 'reexport';
      typeOnly: boolean;
    }[] = [];
    function visit(node: ts.Node) {
      if (
        (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) &&
        node.moduleSpecifier &&
        ts.isStringLiteral(node.moduleSpecifier)
      )
        imports.push({
          specifier: node.moduleSpecifier.text,
          line:
            source.getLineAndCharacterOfPosition(node.getStart(source)).line +
            1,
          kind: ts.isExportDeclaration(node) ? 'reexport' : 'import',
          typeOnly: ts.isExportDeclaration(node)
            ? node.isTypeOnly
            : (node.importClause?.isTypeOnly ?? false),
        });
      if (
        ts.isCallExpression(node) &&
        node.expression.kind === ts.SyntaxKind.ImportKeyword &&
        node.arguments[0] &&
        ts.isStringLiteral(node.arguments[0])
      )
        imports.push({
          specifier: node.arguments[0].text,
          line:
            source.getLineAndCharacterOfPosition(node.getStart(source)).line +
            1,
          kind: 'import',
          typeOnly: false,
        });
      ts.forEachChild(node, visit);
    }
    visit(source);
    for (const [index, entry] of imports.entries()) {
      let targetPath =
        ts.resolveModuleName(
          entry.specifier,
          resolve(root, path),
          compilerOptions,
          ts.sys,
        ).resolvedModule?.resolvedFileName ??
        (entry.specifier.startsWith('.')
          ? resolve(root, dirname(path), entry.specifier)
          : moduleMap.get(entry.specifier));
      if (targetPath) {
        try {
          targetPath = absolute.get(await realpath(targetPath));
        } catch {
          targetPath = undefined;
        }
      }
      let target: string;
      if (targetPath) target = 'file:' + targetPath;
      else {
        target = 'external:' + entry.specifier;
        item({
          id: 'group:external',
          label: 'External dependencies',
          kind: 'group',
          parentId: null,
          detail: 'Imports outside the indexed application',
        });
        item({
          id: target,
          label: entry.specifier,
          kind: 'external',
          parentId: 'group:external',
          detail: 'External package or unresolved literal import',
        });
      }
      edges.push({
        id: `import:${path}:${entry.line}:${index}`,
        source: 'file:' + path,
        target,
        kind: entry.kind,
        label: entry.specifier,
        typeOnly: entry.typeOnly,
        evidence: [
          {
            path,
            line: entry.line,
            text: sources[path]!.split('\n')
              [entry.line - 1]!.trim()
              .slice(0, 500),
          },
        ],
      });
    }
  }
  const channels: RegistryChannel[] = [];
  const graph = { items, edges };
  const snapshotId = sha(canonicalJson({ graph, channels, sources }));
  return RegistryArtifactSchema.parse({
    catalog: {
      schemaVersion: 1,
      snapshotId,
      builtAt: new Date().toISOString(),
      graph,
      channels,
    },
    sources,
  });
}

/** Read only an exact ordinary file below root; refuse symbolic ancestors/finals. */
export async function readProjectFile(
  root: string,
  path: string,
): Promise<string> {
  if (
    !path ||
    path.includes('\\') ||
    path.startsWith('/') ||
    path
      .split('/')
      .some((p) => !p || p === '.' || p === '..' || p.startsWith('.'))
  )
    throw new Error('PATH_DENIED');
  const absolute = resolve(root, path);
  if (!absolute.startsWith(root + '/')) throw new Error('PATH_DENIED');
  if ((await realpath(absolute)) !== absolute) throw new Error('PATH_DENIED');
  const handle = await open(
    absolute,
    constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK,
  );
  try {
    const info = await handle.stat();
    if (!info.isFile() || info.size > 131072)
      throw new Error('Source file budget exceeded: ' + path);
    // Linux validates the opened inode too, closing the ancestor-swap escape.
    if (
      process.platform === 'linux' &&
      (await realpath('/proc/self/fd/' + handle.fd)) !== absolute
    )
      throw new Error('PATH_DENIED');
    const data = await handle.readFile();
    if (data.length > 131072)
      throw new Error('Source file budget exceeded: ' + path);
    return data.toString('utf8');
  } finally {
    await handle.close();
  }
}
