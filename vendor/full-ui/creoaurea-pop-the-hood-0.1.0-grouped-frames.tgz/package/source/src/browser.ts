import {
  RegistrySnapshotSchema,
  RegistrySourceSchema,
  RegistryProjectSchema,
  RegistryEventSchema,
  type RegistryClient,
} from './contracts.ts';

/** Same-origin HTTP/SSE adapter; server owns project scope and Host/Origin checks. */
export function createHoodClient(base = '/api/architecture'): RegistryClient {
  async function get(suffix: string, projectId?: string) {
    const url = new URL(base + suffix, window.location.href);
    if (projectId) url.searchParams.set('projectId', projectId);
    const response = await fetch(url);
    const value: unknown = await response.json();
    if (!response.ok)
      throw new Error(
        (value as { message?: string }).message ??
          `Hood request failed (${response.status})`,
      );
    return value;
  }
  return {
    snapshot: async (id) => RegistrySnapshotSchema.parse(await get('', id)),
    source: async (path, id) =>
      RegistrySourceSchema.parse(
        await get('/source?path=' + encodeURIComponent(path), id),
      ),
    projects: async () =>
      RegistryProjectSchema.array().parse(await get('/projects')),
    listen(id, receive, error) {
      const url = new URL(base + '/events', window.location.href);
      url.searchParams.set('projectId', id);
      let stream: EventSource;
      let closed = false;
      const connect = () => {
        if (closed) return;
        stream?.close();
        stream = new EventSource(url);
        stream.addEventListener('hood', (event) => {
          try {
            receive(
              RegistryEventSchema.parse(
                JSON.parse((event as MessageEvent).data),
              ),
            );
          } catch {
            error();
          }
        });
        stream.onerror = error;
      };
      // A suspended/offline browser can miss events while its old socket appears open.
      const visible = () => {
        if (document.visibilityState === 'visible') connect();
      };
      window.addEventListener('online', connect);
      document.addEventListener('visibilitychange', visible);
      connect();
      return () => {
        closed = true;
        stream.close();
        window.removeEventListener('online', connect);
        document.removeEventListener('visibilitychange', visible);
      };
    },
  };
}
