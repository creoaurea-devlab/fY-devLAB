import type { IncomingMessage, ServerResponse } from 'node:http';
import {
  HoodProjectIdSchema,
  type RegistryMap,
  type RegistryEvent,
} from './contracts.ts';

/** Mount behind the host's Host/Origin guard. No filesystem paths come from HTTP. */
export async function serveHoodRequest(
  request: IncomingMessage,
  response: ServerResponse,
  hood: RegistryMap,
  streams: Set<() => void>,
  base = '/api/architecture',
): Promise<boolean> {
  const url = new URL(request.url ?? '/', 'http://127.0.0.1');
  if (
    request.method !== 'GET' ||
    !(
      url.pathname === base ||
      [base + '/source', base + '/projects', base + '/events'].includes(
        url.pathname,
      )
    )
  )
    return false;
  const projectId = HoodProjectIdSchema.parse(
    url.searchParams.get('projectId') ?? 'workspace',
  );
  const json = (value: unknown) => {
    response.writeHead(200, {
      'content-type': 'application/json',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
    });
    response.end(JSON.stringify(value));
  };
  if (url.pathname === base) json(await hood.snapshot(projectId));
  else if (url.pathname === base + '/source') {
    const path = url.searchParams.get('path');
    if (!path || path.length > 1024)
      throw new Error('Invalid Hood source path');
    json(await hood.source(path, projectId));
  } else if (url.pathname === base + '/projects')
    json(
      await (hood.projects?.() ??
        Promise.resolve([{ id: 'workspace', label: 'Built workspace' }])),
    );
  else {
    if (streams.size >= 64) throw new Error('Hood stream limit reached');
    const snapshot = await hood.snapshot(projectId); // Reject unknown project before headers.
    if (response.destroyed) return true;
    let closed = false,
      unsubscribe = () => {};
    const close = () => {
      if (closed) return;
      closed = true;
      clearInterval(heartbeat);
      unsubscribe();
      streams.delete(close);
      response.end();
    };
    const send = (event: RegistryEvent) => {
      if (closed) return;
      // Latest-state protocol: slow consumers reconnect instead of buffering history.
      if (!response.write(`event: hood\ndata: ${JSON.stringify(event)}\n\n`))
        close();
    };
    const heartbeat = setInterval(() => {
      if (!response.write(': heartbeat\n\n')) close();
    }, 15000);
    heartbeat.unref();
    response.writeHead(200, {
      'content-type': 'text/event-stream',
      'cache-control': 'no-store',
      'x-accel-buffering': 'no',
      'x-content-type-options': 'nosniff',
    });
    response.flushHeaders();
    response.on('close', close);
    streams.add(close);
    send({
      kind: 'snapshot',
      projectId,
      revision: snapshot.observation?.revision ?? 0,
    });
    if (!closed) {
      try {
        unsubscribe = hood.subscribe?.(projectId, send) ?? (() => {});
      } catch (error) {
        send({ kind: 'error', projectId, revision: 0, message: String(error) });
        close();
      }
    }
  }
  return true;
}

/** Optional standalone live host. Static transport users never import the compiler. */
export async function startHoodServer(
  options: import('./node.ts').HoodOptions & {
    port?: number;
    webRoot?: string;
  },
) {
  const [{ createServer }, { readFile }, { fileURLToPath }, { createHood }] =
    await Promise.all([
      import('node:http'),
      import('node:fs/promises'),
      import('node:url'),
      import('./node.ts'),
    ]);
  const port = options.port ?? 5420;
  if (!Number.isInteger(port) || port < 0 || port > 65535)
    throw new Error('Port must be an integer from 0 to 65535');
  const hood = await createHood(options);
  const streams = new Set<() => void>();
  const webRoot =
    options.webRoot ?? fileURLToPath(new URL('../web/', import.meta.url));
  const { resolve } = await import('node:path');
  const server = createServer((request, response) => {
    void (async () => {
      const address = server.address();
      const own =
        typeof address === 'object' && address
          ? `http://127.0.0.1:${address.port}`
          : '';
      if (
        request.headers.host !== own.slice(7) ||
        (request.headers.origin && request.headers.origin !== own)
      ) {
        response.writeHead(403, { 'content-type': 'application/json' });
        response.end('{"message":"Origin is not allowed"}');
        return;
      }
      if (await serveHoodRequest(request, response, hood, streams)) return;
      const path = new URL(request.url ?? '/', own).pathname;
      const assets: Record<string, [string, string]> = {
        '/': ['index.html', 'text/html; charset=utf-8'],
        '/app.js': ['app.js', 'text/javascript'],
        '/app.css': ['app.css', 'text/css'],
      };
      const asset = request.method === 'GET' ? assets[path] : undefined;
      if (!asset) {
        response.writeHead(404);
        response.end('Not found');
        return;
      }
      const bytes = await readFile(resolve(webRoot, asset[0]));
      response.writeHead(200, {
        'content-type': asset[1],
        'cache-control': 'no-store',
        'x-content-type-options': 'nosniff',
        'referrer-policy': 'no-referrer',
        'content-security-policy':
          "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'",
      });
      response.end(bytes);
    })().catch((error) => {
      if (response.headersSent) {
        response.destroy();
        return;
      }
      const message =
        error instanceof Error ? error.message : 'Hood request failed';
      const status = message.includes('PATH_DENIED')
        ? 403
        : message.includes('Unknown Hood project')
          ? 404
          : error?.name === 'ZodError'
            ? 400
            : 500;
      response.writeHead(status, {
        'content-type': 'application/json',
        'cache-control': 'no-store',
      });
      response.end(JSON.stringify({ message }));
    });
  });
  try {
    await new Promise<void>((ready, reject) => {
      server.once('error', reject);
      server.listen(port, '127.0.0.1', () => {
        server.removeListener('error', reject);
        ready();
      });
    });
  } catch (error) {
    await hood.close();
    throw error;
  }
  const address = server.address();
  if (!address || typeof address === 'string')
    throw new Error('Missing Hood host address');
  let closing: Promise<void> | undefined;
  return {
    url: `http://127.0.0.1:${address.port}`,
    hood,
    close() {
      return (closing ??= (async () => {
        for (const close of [...streams]) close();
        const stopped = new Promise<void>((resolveClose, reject) =>
          server.close((error) => (error ? reject(error) : resolveClose())),
        );
        server.closeIdleConnections();
        await Promise.all([stopped, hood.close()]);
      })());
    },
  };
}
