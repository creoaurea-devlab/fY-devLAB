import { watch, type FSWatcher } from 'node:fs';
import { readdir, realpath } from 'node:fs/promises';
import { resolve } from 'node:path';
import {
  analyzeProject,
  ignoredDirectories,
  readProjectFile,
} from './analyzer.ts';
import {
  HoodProjectIdSchema,
  ProjectConfigSchema,
  RegistryRuntimeSchema,
  RegistrySnapshotSchema,
  canonicalJson,
  type RegistryArtifact,
  type RegistryProject,
  type RegistryEvent,
  type RegistryRuntime,
  type RegistrySnapshot,
  type RegistrySource,
} from './contracts.ts';

export interface HoodOptions {
  root: string;
  label?: string;
  projectsRoot?: string;
  /** Host-supplied authoritative catalog; portable hosts can retain directory discovery. */
  projectRoots?: () => Promise<{ id: string; root: string; label: string }[]>;
  /** Native events are hints; reconciliation is the correctness fallback. */
  pollMs?: number;
  debounceMs?: number;
  maxActive?: number;
  analyze?: (root: string, projectId: string) => Promise<RegistryArtifact>;
  runtime?: (
    artifact: RegistryArtifact,
    projectId: string,
  ) => RegistryRuntime | undefined;
}
export interface HoodHost {
  projects(): Promise<RegistryProject[]>;
  snapshot(projectId?: string): Promise<RegistrySnapshot>;
  source(path: string, projectId?: string): Promise<RegistrySource>;
  subscribe(
    projectId: string,
    receive: (event: RegistryEvent) => void,
  ): () => void;
  close(): Promise<void>;
}
interface Entry {
  id: string;
  root: string;
  artifact?: RegistryArtifact;
  declaration?: RegistryRuntime;
  revision: number;
  error?: string;
  used: number;
  watchers: Map<string, FSWatcher>;
  timer?: ReturnType<typeof setTimeout>;
  pending?: Promise<void>;
  dirty: boolean;
  closed: boolean;
}
const emptyRuntime: RegistryRuntime = {
  plugins: [],
  wiring: { items: [], edges: [] },
};

/** No Cordis/devLAB dependency and no project code execution. One owner per scan. */
export async function createHood(options: HoodOptions): Promise<HoodHost> {
  const root = await realpath(resolve(options.root));
  const projectsRoot = options.projectsRoot
    ? resolve(options.projectsRoot)
    : undefined;
  const pollMs = Math.max(100, options.pollMs ?? 3000);
  const debounceMs = Math.max(10, options.debounceMs ?? 140);
  const maxActive = Math.min(8, Math.max(1, options.maxActive ?? 3));
  const entries = new Map<string, Entry>();
  const opening = new Map<string, Promise<Entry>>();
  const subscribers = new Set<{
    id: string;
    receive: (event: RegistryEvent) => void;
  }>();
  let alive = true,
    catalogHash = '',
    useCounter = 0;
  function active() {
    if (!alive) throw new Error('Hood is closed');
  }
  function emit(event: RegistryEvent) {
    if (!alive) return;
    for (const subscriber of subscribers)
      if (event.kind === 'projects' || subscriber.id === event.projectId)
        try {
          subscriber.receive(event);
        } catch {
          /* An observer cannot break the owner. */
        }
  }
  async function config(path: string): Promise<Partial<RegistryProject>> {
    try {
      return ProjectConfigSchema.parse(
        JSON.parse(await readProjectFile(path, 'hood.project.json')),
      );
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return {};
      return { warning: 'Invalid hood.project.json; preview disabled' };
    }
  }
  async function projects(): Promise<RegistryProject[]> {
    active();
    if (options.projectRoots) {
      const supplied = await options.projectRoots();
      if (supplied.length > 201 || new Set(supplied.map(p => p.id)).size !== supplied.length) throw new Error('Invalid project catalog');
      const list: RegistryProject[] = [];
      for (const p of supplied) {
        HoodProjectIdSchema.parse(p.id);
        if ((await realpath(p.root).catch(() => undefined)) !== p.root) continue;
        list.push({ id: p.id, ...(await config(p.root)), label: p.label });
      }
      return list;
    }
    const list: RegistryProject[] = [
      {
        id: 'workspace',
        label: options.label ?? 'Workspace',
        ...(await config(root)),
      },
    ];
    if (!projectsRoot) return list;
    const physical = await realpath(projectsRoot).catch(() => undefined);
    if (physical !== projectsRoot) return list; // No symlink project authority.
    const dirs = await readdir(projectsRoot, { withFileTypes: true });
    for (const dir of dirs.sort((a, b) => a.name.localeCompare(b.name))) {
      if (list.length >= 101) break;
      if (
        !dir.isDirectory() ||
        dir.name === 'workspace' ||
        !HoodProjectIdSchema.safeParse(dir.name).success ||
        dir.name.startsWith('.') ||
        ignoredDirectories.has(dir.name)
      )
        continue;
      const path = resolve(projectsRoot, dir.name);
      if ((await realpath(path).catch(() => undefined)) !== path) continue;
      list.push({ id: dir.name, label: dir.name, ...(await config(path)) });
    }
    return list;
  }
  function release(entry: Entry) {
    entry.closed = true;
    if (entry.timer) clearTimeout(entry.timer);
    for (const watcher of entry.watchers.values()) watcher.close();
    entry.watchers.clear();
  }
  async function syncWatchers(entry: Entry) {
    const dirs = new Set<string>();
    async function walk(path: string) {
      if (dirs.size >= 2048)
        throw new Error('Watcher directory budget exceeded');
      if ((await realpath(path).catch(() => undefined)) !== path) return;
      dirs.add(path);
      for (const child of await readdir(path, { withFileTypes: true }))
        if (
          child.isDirectory() &&
          !child.name.startsWith('.') &&
          !ignoredDirectories.has(child.name)
        )
          await walk(resolve(path, child.name));
    }
    await walk(entry.root);
    if (!alive || entry.closed) return;
    for (const [path, watcher] of entry.watchers)
      if (!dirs.has(path)) {
        watcher.close();
        entry.watchers.delete(path);
      }
    for (const path of dirs) {
      if (entry.watchers.has(path)) continue;
      try {
        const watcher = watch(
          path,
          { persistent: false },
          (_event, filename) => {
            const name = filename?.toString();
            if (name?.startsWith('.') || (name && ignoredDirectories.has(name)))
              return;
            schedule(entry);
          },
        );
        watcher.on('error', () => {
          watcher.close();
          entry.watchers.delete(path);
          schedule(entry);
        });
        entry.watchers.set(path, watcher);
      } catch {
        /* Periodic reconciliation works when native watches are unavailable. */
      }
    }
  }
  async function scan(entry: Entry) {
    entry.dirty = true;
    if (entry.pending) return entry.pending;
    entry.pending = (async () => {
      do {
        entry.dirty = false;
        try {
          if (options.projectRoots && !(await options.projectRoots()).some(p => p.id === entry.id && p.root === entry.root))
            throw new Error('Project is no longer registered');
          if ((await realpath(entry.root)) !== entry.root)
            throw new Error('Project root was replaced by a symbolic link');
          const artifact = await (options.analyze?.(entry.root, entry.id) ??
            analyzeProject(entry.root));
          const declaration = artifact.sources['hood.registry.json']
            ? RegistryRuntimeSchema.parse(
                JSON.parse(artifact.sources['hood.registry.json']),
              )
            : emptyRuntime;
          // A file declaration never proves active runtime state.
          for (const plugin of declaration.plugins) {
            plugin.state = 'unknown';
            plugin.generation = 0;
            plugin.leases = 0;
          }
          if (entry.closed || !alive) return;
          const changed =
            artifact.catalog.snapshotId !==
              entry.artifact?.catalog.snapshotId || Boolean(entry.error);
          entry.artifact = artifact;
          entry.declaration = declaration;
          entry.error = undefined;
          await syncWatchers(entry);
          if (changed && !entry.closed && alive) {
            entry.revision++;
            emit({
              kind: 'snapshot',
              projectId: entry.id,
              revision: entry.revision,
            });
          }
        } catch (error) {
          if (entry.closed || !alive) return;
          const message =
            error instanceof Error ? error.message : 'Project scan failed';
          if (entry.error !== message) {
            entry.error = message;
            entry.revision++;
            emit({
              kind: 'error',
              projectId: entry.id,
              revision: entry.revision,
              message,
            });
          }
        }
      } while (entry.dirty && !entry.closed && alive);
    })().finally(() => {
      entry.pending = undefined;
    });
    return entry.pending;
  }
  function schedule(entry: Entry) {
    if (!alive || entry.closed) return;
    if (entry.pending) {
      entry.dirty = true;
      return;
    }
    if (entry.timer) return; // Bounded coalescing, not starvation under a write storm.
    entry.timer = setTimeout(() => {
      entry.timer = undefined;
      void scan(entry);
    }, debounceMs);
    entry.timer.unref();
  }
  async function open(id: string) {
    active();
    HoodProjectIdSchema.parse(id);
    const supplied = options.projectRoots ? (await options.projectRoots()).find(p => p.id === id) : undefined;
    if (options.projectRoots && !supplied) throw new Error('Unknown Hood project');
    let existing = entries.get(id);
    if (existing && supplied && existing.root !== supplied.root) {
      release(existing);
      await existing.pending;
      entries.delete(id);
      existing = undefined;
    }
    if (existing) {
      existing.used = ++useCounter;
      if (!existing.artifact) await existing.pending;
      return existing;
    }
    const inProgress = opening.get(id);
    if (inProgress) return inProgress;
    const promise = (async () => {
      // Resolve from the current catalog, never from a browser-supplied absolute path.
      if (!(await projects()).some((p) => p.id === id))
        throw new Error('Unknown Hood project');
      active();
      if (entries.size >= maxActive) {
        const candidate = [...entries.values()]
          .filter((e) => ![...subscribers].some((s) => s.id === e.id))
          .sort((a, b) => a.used - b.used)[0];
        if (!candidate) throw new Error('Hood active project limit reached');
        release(candidate);
        entries.delete(candidate.id);
      }
      const path = options.projectRoots ? (await options.projectRoots()).find(p => p.id === id)?.root : id === 'workspace' ? root : resolve(projectsRoot!, id);
      if (!path) throw new Error('Unknown Hood project');
      const entry: Entry = {
        id,
        root: path,
        revision: 0,
        used: ++useCounter,
        watchers: new Map(),
        dirty: false,
        closed: false,
      };
      entries.set(id, entry);
      await scan(entry);
      return entry;
    })().finally(() => {
      opening.delete(id);
    });
    opening.set(id, promise);
    return promise;
  }
  async function snapshot(id = 'workspace'): Promise<RegistrySnapshot> {
    const entry = await open(id);
    active();
    if (!entry.artifact)
      throw new Error(entry.error ?? 'Project snapshot is not ready');
    const runtime = RegistryRuntimeSchema.parse(
      options.runtime?.(entry.artifact, id) ??
        entry.declaration ??
        emptyRuntime,
    );
    return RegistrySnapshotSchema.parse({
      catalog: entry.artifact.catalog,
      ...runtime,
      observation: {
        mode: 'live',
        projectId: id,
        revision: entry.revision,
        status: entry.error ? 'stale' : 'ready',
        ...(entry.error ? { message: entry.error } : {}),
      },
    });
  }
  async function source(
    path: string,
    id = 'workspace',
  ): Promise<RegistrySource> {
    const entry = await open(id);
    active();
    // Text belongs to the committed revision, never a different concurrent disk read.
    const file = entry.artifact?.catalog.graph.items.find(
      (i) => i.kind === 'file' && i.path === path,
    );
    if (!file || !Object.hasOwn(entry.artifact!.sources, path))
      throw new Error('PATH_DENIED');
    return { path, sha256: file.sha256!, text: entry.artifact!.sources[path]! };
  }
  const interval = setInterval(() => {
    if (!alive) return;
    for (const entry of entries.values()) schedule(entry);
    void projects()
      .then((list) => {
        if (!alive) return;
        const hash = canonicalJson(list);
        if (hash !== catalogHash) {
          catalogHash = hash;
          emit({ kind: 'projects', projectId: '*', revision: 0 });
          const ids = new Set(list.map((p) => p.id));
          for (const entry of entries.values())
            if (!ids.has(entry.id)) schedule(entry);
        }
      })
      .catch(() => {
        /* Transient directory changes are retried next interval. */
      });
  }, pollMs);
  interval.unref();
  return {
    projects,
    snapshot,
    source,
    subscribe(id, receive) {
      active();
      HoodProjectIdSchema.parse(id);
      if (subscribers.size >= 128)
        throw new Error('Hood observer limit reached');
      const subscriber = { id, receive };
      subscribers.add(subscriber);
      void snapshot(id)
        .then((value) => {
          if (alive && subscribers.has(subscriber))
            try {
              receive({
                kind: 'snapshot',
                projectId: id,
                revision: value.observation!.revision,
              });
            } catch {
              /* Observer failure is isolated. */
            }
        })
        .catch((error) => {
          if (alive && subscribers.has(subscriber))
            try {
              receive({
                kind: 'error',
                projectId: id,
                revision: 0,
                message: String(error),
              });
            } catch {
              /* Observer failure is isolated. */
            }
        });
      return () => subscribers.delete(subscriber);
    },
    async close() {
      if (!alive) return;
      alive = false;
      clearInterval(interval);
      subscribers.clear();
      for (const entry of entries.values()) release(entry);
      await Promise.allSettled([
        ...opening.values(),
        ...[...entries.values()].map((e) => e.pending),
      ]);
      entries.clear();
    },
  };
}
