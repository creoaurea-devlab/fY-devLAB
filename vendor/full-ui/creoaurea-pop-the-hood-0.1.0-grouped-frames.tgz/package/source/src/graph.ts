import type { RegistryItem, RegistryEdge } from './contracts.ts';
export type RegistryGraph = { items: RegistryItem[]; edges: RegistryEdge[] };
export interface ProjectedWire extends RegistryEdge {
  originals: RegistryEdge[];
}
export interface HoodProjection {
  items: RegistryItem[];
  wires: ProjectedWire[];
  representative: Map<string, string>;
  children: Map<string, RegistryItem[]>;
  internal: Map<string, number>;
  matches: Set<string>;
}
export const wireColors: Record<RegistryEdge['kind'], string> = {
  contains: '#59677d',
  import: '#60a5fa',
  reexport: '#a78bfa',
  provides: '#34d399',
  requires: '#38bdf8',
  live: '#c084fc',
  ipc: '#fbbf24',
  ui: '#fb7185',
};

function parentChain(map: Map<string, RegistryItem>, id: string): string[] {
  const result: string[] = [];
  let current = map.get(id);
  while (current?.parentId) {
    result.push(current.parentId);
    current = map.get(current.parentId);
  }
  return result;
}
export function ancestors(items: RegistryItem[], id: string): string[] {
  return parentChain(new Map(items.map((i) => [i.id, i])), id);
}
export function expansionAtDepth(
  items: RegistryItem[],
  depth: number,
): Set<string> {
  const parents = new Set(items.map((i) => i.parentId));
  const map = new Map(items.map((i) => [i.id, i]));
  return new Set(
    items
      .filter((i) => parents.has(i.id) && parentChain(map, i.id).length < depth)
      .map((i) => i.id),
  );
}
export function projectRegistry(
  graph: RegistryGraph,
  options: {
    expanded: Set<string>;
    query: string;
    external: boolean;
    layers: Set<RegistryEdge['kind']>;
    selected?: string | null;
    neighbors?: boolean;
    hideFiles?: boolean;
  },
): HoodProjection {
  const all = new Map(graph.items.map((i) => [i.id, i]));
  const children = new Map<string, RegistryItem[]>();
  for (const item of graph.items)
    if (item.parentId) {
      const list = children.get(item.parentId) ?? [];
      list.push(item);
      children.set(item.parentId, list);
    }
  const query = options.query.trim().toLowerCase();
  const matches = new Set(
    graph.items
      .filter(
        (i) =>
          !query ||
          [i.label, i.path ?? '', i.detail].some((v) =>
            v.toLowerCase().includes(query),
          ),
      )
      .map((i) => i.id),
  );
  const forced = new Set<string>();
  if (query)
    for (const id of matches)
      for (const parent of parentChain(all, id)) forced.add(parent);
  const allowed = (i: RegistryItem) =>
    (options.external ||
      (i.kind !== 'external' && i.id !== 'group:external')) &&
    (!query || matches.has(i.id) || forced.has(i.id));
  let visible = graph.items.filter(
    (i) =>
      (!options.hideFiles || !['file', 'symbol'].includes(i.kind)) &&
      allowed(i) &&
      parentChain(all, i.id).every(
        (id) => options.expanded.has(id) || forced.has(id),
      ),
  );
  const representatives = new Map<string, string>();
  const visibleIds = new Set(visible.map((i) => i.id));
  for (const item of graph.items) {
    if (!allowed(item)) continue;
    let current: RegistryItem | undefined = item;
    while (current && !visibleIds.has(current.id))
      current = current.parentId ? all.get(current.parentId) : undefined;
    if (current) representatives.set(item.id, current.id);
  }
  const bundled = new Map<string, ProjectedWire>(),
    internal = new Map<string, number>();
  function add(edge: RegistryEdge) {
    if (!options.layers.has(edge.kind)) return;
    const source = representatives.get(edge.source),
      target = representatives.get(edge.target);
    if (!source || !target) return;
    if (source === target) {
      internal.set(source, (internal.get(source) ?? 0) + 1);
      return;
    }
    const key = `wire:${edge.kind}:${source}:${target}:${edge.typeOnly ? 'type' : 'value'}`;
    const existing = bundled.get(key);
    if (existing) {
      existing.originals.push(edge);
      existing.evidence.push(...edge.evidence);
      existing.label = `${edge.kind} · ${existing.originals.length} wires`;
    } else
      bundled.set(key, {
        ...edge,
        id: key,
        source,
        target,
        evidence: [...edge.evidence],
        originals: [edge],
      });
  }
  for (const e of graph.edges) add(e);
  if (options.layers.has('contains'))
    for (const item of visible)
      if (item.parentId && visibleIds.has(item.parentId))
        add({
          id: 'contains:' + item.id,
          source: item.parentId,
          target: item.id,
          kind: 'contains',
          label: 'contains',
          evidence: [],
        });
  let wires = [...bundled.values()];
  if (options.neighbors && options.selected) {
    const focus = representatives.get(options.selected);
    if (focus) {
      const keep = new Set([focus]);
      for (const wire of wires)
        if (wire.source === focus || wire.target === focus) {
          keep.add(wire.source);
          keep.add(wire.target);
        }
      visible = visible.filter((i) => keep.has(i.id));
      wires = wires.filter((e) => e.source === focus || e.target === focus);
    }
  }
  return {
    items: visible,
    wires,
    representative: representatives,
    children,
    internal,
    matches,
  };
}
