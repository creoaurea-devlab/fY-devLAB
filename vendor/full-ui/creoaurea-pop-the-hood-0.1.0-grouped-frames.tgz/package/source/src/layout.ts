import { graphlib, layout } from '@dagrejs/dagre';
import type { HoodProjection } from './graph.ts';
export const NODE_WIDTH = 248,
  NODE_HEIGHT = 100;
type Point = { x: number; y: number };
type Block = { id: string; width: number; height: number; positions: Map<string, Point> };

/** Lay out sibling subtrees as rectangles, then place their descendants inside.
 * Dagre sees ordinary graphs at each level, avoiding its compound-edge caveat.
 */
export function layoutRegistry(
  projection: Pick<HoodProjection, 'items' | 'wires'>,
  direction: 'LR' | 'TB',
) {
  const items = new Map(projection.items.map(item => [item.id, item]));
  const parents = new Map(projection.items.map(item => [item.id,
    item.parentId && items.has(item.parentId) && item.parentId !== item.id ? item.parentId : null]));
  // Schema-valid hierarchies are acyclic; keep a malformed imported parent cycle finite too.
  for (const item of projection.items) {
    const seen = new Set<string>();
    let id: string | null = item.id;
    while (id) {
      if (seen.has(id)) { parents.set(id, null); break; }
      seen.add(id);
      id = parents.get(id) ?? null;
    }
  }
  const children = new Map<string | null, string[]>();
  for (const item of projection.items) {
    const parent = parents.get(item.id) ?? null;
    const list = children.get(parent) ?? [];
    list.push(item.id);
    children.set(parent, list);
  }
  function siblings(ids: string[], packDisconnected = false): Block {
    const blocks = ids.map(branch);
    const membership = new Map<string, string>();
    const graph = new graphlib.Graph();
    graph.setGraph({ rankdir: direction, nodesep: 48, ranksep: 90, marginx: 32, marginy: 32 });
    graph.setDefaultEdgeLabel(() => ({}));
    for (const block of blocks) {
      graph.setNode(block.id, { width: block.width, height: block.height });
      for (const id of block.positions.keys()) membership.set(id, block.id);
    }
    for (const wire of projection.wires) {
      const source = membership.get(wire.source), target = membership.get(wire.target);
      if (source && target && source !== target) graph.setEdge(source, target, {});
    }
    if (packDisconnected && blocks.length > 1 && graph.edgeCount() === 0) {
      // Disconnected symbols have no rank constraints; pack their real blocks
      // into balanced shelves rather than inventing dependency edges.
      const cellWidth = Math.max(...blocks.map(block => block.width)) + 48;
      const cellHeight = Math.max(...blocks.map(block => block.height)) + 48;
      const columns = Math.max(1, Math.ceil(Math.sqrt(blocks.length * cellHeight / cellWidth)));
      blocks.forEach((block, index) => graph.setNode(block.id, {
        x: 32 + (index % columns) * cellWidth + block.width / 2,
        y: 32 + Math.floor(index / columns) * cellHeight + block.height / 2,
      }));
    } else if (blocks.length) layout(graph);
    const positions = new Map<string, Point>();
    let width = 0, height = 0;
    for (const block of blocks) {
      const p = graph.node(block.id);
      const x = p.x - block.width / 2, y = p.y - block.height / 2;
      width = Math.max(width, x + block.width);
      height = Math.max(height, y + block.height);
      for (const [id, point] of block.positions) positions.set(id, { x: x + point.x, y: y + point.y });
    }
    return { id: '', width, height, positions };
  }
  function branch(id: string): Block {
    const ids = children.get(id) ?? [];
    if (!ids.length) return { id, width: NODE_WIDTH, height: NODE_HEIGHT, positions: new Map([[id, { x: 0, y: 0 }]]) };
    const nested = siblings(ids, true);
    const x = direction === 'LR' ? NODE_WIDTH + 64 : 0;
    const y = direction === 'TB' ? NODE_HEIGHT + 64 : 0;
    const width = Math.max(NODE_WIDTH, nested.width + x);
    const height = Math.max(NODE_HEIGHT, nested.height + y);
    const positions = new Map<string, Point>([[id, {
      x: direction === 'TB' ? (width - NODE_WIDTH) / 2 : 0,
      y: direction === 'LR' ? (height - NODE_HEIGHT) / 2 : 0,
    }]]);
    for (const [child, point] of nested.positions) positions.set(child, { x: x + point.x, y: y + point.y });
    return { id, width, height, positions };
  }
  return siblings(children.get(null) ?? []).positions;
}
