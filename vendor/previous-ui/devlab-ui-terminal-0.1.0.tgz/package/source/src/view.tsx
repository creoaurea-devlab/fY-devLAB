import { useEffect, useRef, useState } from 'react';
import { Terminal } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import { ApplicationError, type TerminalSession } from '@devlab/contracts';
import type { UIPluginProps } from '@devlab/ui-contracts';
import { acquireTerminalInput } from './input.ts';
import '@xterm/xterm/css/xterm.css';
import './terminal.css';

export function TerminalView({ client, terminalOptions }: UIPluginProps) {
  const host = useRef<HTMLDivElement>(null);
  const focusStarted = useRef<string | null>(null);
  const actions = useRef<{
    start(): Promise<void>;
    stop(): Promise<void>;
    resize(): void;
    resumeInput(): void;
  } | null>(null);
  const [session, setSession] = useState<TerminalSession | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [connection, setConnection] = useState('Checking sessions'),
    [inputBlocked, setInputBlocked] = useState(false);
  const options = useRef(terminalOptions);
  options.current = terminalOptions;
  const api = client.terminals,
    projectId = terminalOptions?.projectId,
    nodeId = terminalOptions?.nodeId,
    sessionId = terminalOptions?.sessionId;
  const identity = `${projectId}/${nodeId}/${sessionId ?? '*'}`;
  const currentIdentity = useRef(identity);
  currentIdentity.current = identity;

  useEffect(() => {
    if (!api || !projectId || !nodeId || !host.current) return;
    let alive = true,
      detach = () => {},
      current: TerminalSession | null = null,
      attachment = 0,
      observation = 0,
      operation = 0,
      pending = false,
      resizeTimer: ReturnType<typeof setTimeout> | undefined;
    let input: ReturnType<typeof acquireTerminalInput> | undefined;
    const live = () => alive && currentIdentity.current === identity;
    const surface = getComputedStyle(host.current.parentElement!);
    const term = new Terminal({
      fontSize: 11,
      fontFamily: 'ui-monospace, monospace',
      cursorBlink: true,
      scrollback: 2000,
      theme: {
        background: surface.backgroundColor || '#10141c',
        foreground: surface.color || '#d9e1ee',
        cursor: surface.color || '#67e8f9',
      },
    });
    const fit = new FitAddon();
    term.loadAddon(fit);
    term.open(host.current);
    setSession(null);
    setBusy(false);
    setError('');
    setConnection('Checking sessions');
    const failure = (e: unknown) => {
      if (live()) setError(e instanceof Error ? e.message : String(e));
    };
    const endInput = () => { input?.release(true); input = undefined; setInputBlocked(false); setError(''); };
    const matches = (s: TerminalSession) =>
      s.projectId === projectId && s.nodeId === nodeId;
    const resize = () => {
      clearTimeout(resizeTimer);
      if (!live() || !host.current?.clientWidth || !host.current.clientHeight)
        return;
      fit.fit();
      if (options.current?.resizeOwner === false) return;
      const id = current?.id,
        generation = attachment;
      resizeTimer = setTimeout(() => {
        if (
          live() &&
          options.current?.resizeOwner !== false &&
          attachment === generation &&
          id &&
          current?.id === id &&
          current.status === 'running' &&
          host.current?.clientWidth &&
          host.current.clientHeight
        )
          void api.resize(id, term.cols, term.rows).catch((e) => {
            if (attachment === generation) failure(e);
          });
      }, 100);
    };
    const attach = (s: TerminalSession, focus = false) => {
      if (!live() || !matches(s)) return;
      const generation = ++attachment;
      detach();
      input?.release();
      clearTimeout(resizeTimer);
      term.reset();
      current = s;
      setSession(s);
      setError('');
      setConnection('Connecting');
      const attached = () =>
        live() && attachment === generation && current?.id === s.id;
      input = acquireTerminalInput(api, s.id, message => {
        if (attached()) { setError(message); setInputBlocked(Boolean(message)); }
      });
      setInputBlocked(input.blocked());
      detach = api.listen(
        s.id,
        0,
        (event) => {
          if (
            !attached() ||
            event.session.id !== s.id ||
            !matches(event.session)
          )
            return;
          ++observation;
          if (event.reset) {
            term.reset();
            term.writeln('[Earlier output was truncated]');
          }
          for (const chunk of event.chunks) term.write(chunk.data);
          current = event.session;
          if (event.session.status === 'exited') { endInput(); }
          setSession(event.session);
          setConnection(
            event.session.status === 'running'
              ? 'Connected'
              : `Exited (${event.session.exitCode})`,
          );
        },
        () => {
          if (!attached() || current?.status !== 'running') return;
          setConnection('Reconnecting');
          const observed = observation;
          void api
            .inspect(s.id)
            .then((value) => {
              if (
                !attached() ||
                observation !== observed ||
                value.id !== s.id ||
                !matches(value)
              )
                return;
              ++observation;
              current = value;
              setSession(value);
              if (value.status === 'exited') { endInput(); setConnection(`Exited (${value.exitCode})`); }
            })
            .catch((e) => {
              if (!attached() || observation !== observed) return;
              if (
                e instanceof ApplicationError &&
                e.code === 'TERMINAL_NOT_FOUND'
              ) {
                detach();
                ++attachment;
                current = null;
                endInput();
                setSession(null);
                setConnection('Session unavailable · start a new shell');
              } else failure(e);
            });
        },
      );
      resize();
      if (focus) term.focus();
    };
    const inputListener = term.onData((data) => {
      if (!live() || current?.status !== 'running') return;
      try { input?.push(data); } catch (error) { failure(error); }
    });
    const observer = new ResizeObserver(resize);
    observer.observe(host.current);
    resize();
    const discovery = operation;
    const discovered = (s: TerminalSession | undefined) => {
      if (!live() || discovery !== operation) return;
      if (s && matches(s)) {
        const focus = focusStarted.current === s.id;
        attach(s, focus);
        if (focus) focusStarted.current = null;
      } else {
        current = null;
        setSession(null);
        setConnection('Stopped');
      }
    };
    // Explicit history tabs inspect that exact ID; they never fall back by node.
    void (
      sessionId
        ? api.inspect(sessionId).then((s) => {
            if (s.id !== sessionId || !matches(s))
              throw new Error('Terminal session identity changed');
            discovered(s);
          })
        : api
            .list(projectId)
            .then((sessions) =>
              discovered(
                sessions.find(
                  (s) =>
                    s.nodeId === nodeId &&
                    s.projectId === projectId &&
                    s.status === 'running',
                ),
              ),
            )
    ).catch((e) => {
      if (!live() || discovery !== operation) return;
      setConnection('Session unavailable · start a new shell');
      failure(e);
    });
    actions.current = {
      resize,
      resumeInput() {
        try { input?.discardUnsent(); setInputBlocked(false); setError(''); } catch (error) { failure(error); }
      },
      async start() {
        const value = options.current;
        if (!live() || !value || pending) return;
        const request = ++operation;
        pending = true;
        setBusy(true);
        setError('');
        try {
          const s = await api.create({
            projectId,
            nodeId,
            cwd: value.cwd,
            shell: value.shell,
            cols: term.cols,
            rows: term.rows,
          });
          if (!live() || request !== operation) return;
          if (!matches(s)) throw new Error('Terminal session identity changed');
          if (value.onStarted) focusStarted.current = s.id;
          attach(s, true);
          value.onStarted?.(s);
        } catch (e) {
          if (request === operation) failure(e);
        } finally {
          if (live() && request === operation) {
            pending = false;
            setBusy(false);
          }
        }
      },
      async stop() {
        const s = current;
        if (!live() || !s || s.status !== 'running' || pending) return;
        const request = ++operation;
        pending = true;
        setBusy(true);
        try {
          const value = await api.close(s.id);
          if (!live() || request !== operation || current?.id !== s.id) return;
          ++observation;
          current = value;
          endInput();
          setSession(value);
          setConnection(`Exited (${value.exitCode})`);
        } catch (e) {
          if (request === operation) failure(e);
        } finally {
          if (live() && request === operation) {
            pending = false;
            setBusy(false);
          }
        }
      },
    };
    return () => {
      alive = false;
      ++attachment;
      ++operation;
      detach();
      observer.disconnect();
      input?.release();
      clearTimeout(resizeTimer);
      inputListener.dispose();
      term.dispose();
      actions.current = null;
    };
  }, [api, projectId, nodeId, sessionId, identity]);
  useEffect(() => {
    actions.current?.resize();
  }, [terminalOptions?.resizeOwner]);
  const instance =
    terminalOptions?.instanceId ?? `canvas.${projectId}.${nodeId}`;
  const source = 'plugins/ui-terminal/src/view.tsx';
  return (
    <div
      className="devlab-terminal"
      data-testid={
        terminalOptions?.instanceId
          ? `terminal-${terminalOptions.instanceId}`
          : `terminal-${nodeId}`
      }
      data-devlab-id={`terminal.${instance}`}
      data-devlab-source={source}
      data-terminal-session-id={session?.id ?? ''}
      data-resize-owner={terminalOptions?.resizeOwner !== false}
    >
      <div className="terminal-actions">
        <span
          role="status"
          data-testid="terminal-status"
          data-devlab-id={`terminal.${instance}.status`}
          data-devlab-source={source}
        >
          {connection}
        </span>
        {session?.status === 'running' ? (
          <button
            aria-label={
              terminalOptions?.instanceId
                ? `Stop terminal ${nodeId}`
                : 'Stop shell'
            }
            disabled={busy}
            onClick={() => void actions.current?.stop()}
            data-devlab-id={`terminal.${instance}.stop`}
            data-devlab-source={source}
          >
            Stop
          </button>
        ) : (
          <button
            aria-label="Start shell"
            disabled={busy || !api || connection === 'Checking sessions'}
            onClick={() => void actions.current?.start()}
            data-devlab-id={`terminal.${instance}.start`}
            data-devlab-source={source}
          >
            Start
          </button>
        )}
      </div>
      <div
        className="terminal-screen"
        ref={host}
        aria-label="Terminal screen"
        data-devlab-id={`terminal.${instance}.screen`}
        data-devlab-source={source}
      />
      {error && (
        <div
          className="terminal-error"
          role="alert"
          data-devlab-id={`terminal.${instance}.error`}
          data-devlab-source={source}
        >
          {error}
          {inputBlocked && <button
            type="button"
            onClick={() => actions.current?.resumeInput()}
            data-devlab-id={`terminal.${instance}.resume-input`}
            data-devlab-source={source}
          >Discard unsent input and continue</button>}
        </div>
      )}
      <span
        className="terminal-caption"
        title={session?.cwd ?? terminalOptions?.cwd}
      >
        {' '}
        {session?.cwd ?? terminalOptions?.cwd} · {terminalOptions?.shell} ·
        local
      </span>
    </div>
  );
}
