import { z } from 'zod';

export const ProjectRelativePathSchema = z
  .string()
  .max(512)
  .refine(
    (p) =>
      p === '.' ||
      (!!p &&
        !p.startsWith('/') &&
        !p.includes('\\') &&
        !p.includes('\0') &&
        p
          .split('/')
          .every(
            (v) =>
              !!v &&
              v !== '.' &&
              v !== '..' &&
              !v.startsWith('.') &&
              v !== 'node_modules' &&
              v !== 'secrets',
          )),
    'Expected a project-relative path without traversal or hidden directories',
  );
const argv = z
  .array(
    z
      .string()
      .min(1)
      .max(4096)
      .refine((v) => !v.includes('\0')),
  )
  .min(1)
  .max(64);
export const LoopbackPreviewUrlSchema = z
  .string()
  .url()
  .refine((value) => {
    const url = new URL(value);
    return (
      url.protocol === 'http:' &&
      ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) &&
      !url.username &&
      !url.password
    );
  }, 'Preview must use a credential-free loopback HTTP URL');
export const PreviewDescriptorSchema = z
  .object({
    schemaVersion: z.literal(1),
    adapter: z.enum(['vite', 'next', 'static', 'none', 'custom']),
    cwd: ProjectRelativePathSchema.default('.'),
    workspaceRoot: ProjectRelativePathSchema.default('.'),
    packageManager: z.enum(['pnpm', 'npm', 'yarn', 'bun']).optional(),
    packageManagerVersion: z
      .string()
      .regex(/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/)
      .optional(),
    install: argv.optional(),
    start: argv.optional(),
    autoStart: z.boolean().default(false),
    port: z.number().int().min(1024).max(65535).default(5173),
    readinessPath: z
      .string()
      .max(256)
      .regex(/^\/(?!\/)[^\s]*$/)
      .default('/'),
    timeoutMs: z.number().int().min(1000).max(120000).default(30000),
    environment: z
      .array(z.string().regex(/^[A-Z_][A-Z0-9_]*$/))
      .max(32)
      .default([]),
    views: z
      .array(
        z
          .object({
            id: z.string().regex(/^[a-z][a-z0-9-]{0,63}$/),
            label: z.string().min(1).max(80),
            path: z
              .string()
              .max(512)
              .regex(/^\/(?!\/)[^\s]*$/),
          })
          .strict(),
      )
      .min(1)
      .max(32)
      .default([{ id: 'app', label: 'App', path: '/' }]),
    tokens: z.array(ProjectRelativePathSchema).max(32).default([]),
    elements: z
      .object({
        attribute: z.literal('data-devlab-id').default('data-devlab-id'),
        sourceAttribute: z
          .literal('data-devlab-source')
          .default('data-devlab-source'),
      })
      .strict()
      .default({}),
    inspection: z.enum(['bridge', 'manual', 'none']).default('manual'),
  })
  .strict()
  .superRefine((d, ctx) => {
    if (new Set(d.views.map((v) => v.id)).size !== d.views.length)
      ctx.addIssue({
        code: 'custom',
        message: 'Preview view IDs must be unique',
      });
    if (d.adapter !== 'none' && !d.start)
      ctx.addIssue({
        code: 'custom',
        message: 'Preview adapter requires explicit start argv',
      });
    if (d.adapter === 'none' && (d.start || d.install || d.autoStart))
      ctx.addIssue({
        code: 'custom',
        message: 'No-UI adapter cannot execute commands',
      });
    if (d.autoStart && !d.start)
      ctx.addIssue({
        code: 'custom',
        message: 'Auto-start requires start argv',
      });
  });
export type PreviewDescriptor = z.infer<typeof PreviewDescriptorSchema>;
/** Descriptor capability is distinct from a live project connection observation. */
export function previewRefreshMode(adapter?: PreviewDescriptor['adapter']):
  'framework-hmr' | 'reload-required' | 'none' | 'unknown' {
  if (adapter === 'vite') return 'framework-hmr';
  if (adapter === 'static') return 'reload-required';
  if (adapter === 'none') return 'none';
  return 'unknown';
}
export const PreviewBridgeMessageSchema = z.object({
  channel: z.literal('devlab-preview-v1'),
  type: z.enum(['ready', 'picking', 'cancelled', 'reset', 'invalidated', 'selection', 'refresh-state']),
  projectId: z.string().regex(/^[a-zA-Z0-9_-]{1,128}$/),
  generation: z.string().regex(/^[a-zA-Z0-9_-]{1,128}$/),
  nonce: z.string().regex(/^[a-zA-Z0-9_-]{16,128}$/),
  epoch: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  refresh: z.enum(['unknown', 'connected', 'disconnected']).optional(),
  selection: z.unknown().optional(),
});

export type PreviewDiscovery = {
  status: 'configured' | 'inferred' | 'unconfigured' | 'invalid';
  descriptor?: PreviewDescriptor;
  warnings: string[];
  legacyUrl?: string;
};

/** Pure discovery: evidence comes from bounded host reads, never evaluated project code. */
export function discoverPreview(input: {
  descriptor?: unknown;
  manifest?: unknown;
  files: string[];
  legacyUrl?: string;
}): PreviewDiscovery {
  const warnings: string[] = [];
  const legacyUrl =
    input.legacyUrl &&
    LoopbackPreviewUrlSchema.safeParse(input.legacyUrl).success
      ? input.legacyUrl
      : undefined;
  if (input.descriptor !== undefined) {
    const result = PreviewDescriptorSchema.safeParse(input.descriptor);
    return result.success
      ? { status: 'configured', descriptor: result.data, warnings, legacyUrl }
      : {
          status: 'invalid',
          warnings: result.error.issues.map((i) => i.message),
        };
  }
  const manifest =
    input.manifest && typeof input.manifest === 'object'
      ? (input.manifest as Record<string, unknown>)
      : {};
  const locks = [
    ['pnpm-lock.yaml', 'pnpm'],
    ['package-lock.json', 'npm'],
    ['yarn.lock', 'yarn'],
    ['bun.lock', 'bun'],
    ['bun.lockb', 'bun'],
  ].filter(([name]) => input.files.includes(name!));
  const managers = [...new Set(locks.map(([, manager]) => manager))];
  const pinned =
    typeof manifest.packageManager === 'string'
      ? /^(pnpm|npm|yarn|bun)@(\d+\.\d+\.\d+(?:[-+][\w.-]+)?)$/.exec(
          manifest.packageManager,
        )
      : null;
  if (
    managers.length > 1 ||
    (pinned && managers.length && managers[0] !== pinned[1])
  )
    return {
      status: 'invalid',
      warnings: [
        'Conflicting package manager/lockfile evidence; configure the project explicitly.',
      ],
    };
  const manager = (pinned?.[1] ??
    managers[0]) as PreviewDescriptor['packageManager'];
  const scripts =
    manifest.scripts && typeof manifest.scripts === 'object'
      ? (manifest.scripts as Record<string, unknown>)
      : {};
  const dependencies = {
    ...((manifest.dependencies as Record<string, unknown>) ?? {}),
    ...((manifest.devDependencies as Record<string, unknown>) ?? {}),
  };
  const adapter =
    dependencies.vite &&
    typeof scripts.dev === 'string' &&
    /^\s*vite(?:\s|$)/.test(scripts.dev)
      ? 'vite'
      : dependencies.next &&
          typeof scripts.dev === 'string' &&
          /^\s*next\s+dev(?:\s|$)/.test(scripts.dev)
        ? 'next'
        : undefined;
  if (!manager || !adapter || typeof scripts.dev !== 'string')
    return {
      status: 'unconfigured',
      warnings: [
        'No supported dev script and package-manager evidence. Add devlab.preview.json.',
      ],
      legacyUrl,
    };
  const descriptor = PreviewDescriptorSchema.parse({
    schemaVersion: 1,
    adapter,
    packageManager: manager,
    ...(pinned ? { packageManagerVersion: pinned[2] } : {}),
    install:
      manager === 'npm'
        ? ['npm', managers.length ? 'ci' : 'install']
        : [
            manager,
            'install',
            ...(managers.length && (manager === 'pnpm' || manager === 'yarn')
              ? ['--frozen-lockfile']
              : []),
          ],
    start:
      adapter === 'vite'
        ? [
            manager,
            'run',
            'dev',
            ...(manager === 'npm' ? ['--'] : []),
            '--host',
            '127.0.0.1',
            '--port',
            '{port}',
            '--strictPort',
          ]
        : [
            manager,
            'run',
            'dev',
            ...(manager === 'npm' ? ['--'] : []),
            '--hostname',
            '127.0.0.1',
            '--port',
            '{port}',
          ],
  });
  warnings.push(
    'Inferred configuration; save a reviewed descriptor before enabling automatic execution.',
  );
  return { status: 'inferred', descriptor, warnings, legacyUrl };
}

export const PreviewNativeTargetSchema=z.object({paneId:z.string().regex(/^[a-zA-Z0-9_-]{1,128}$/),viewId:z.string().regex(/^[a-z][a-z0-9-]{0,63}$/)}).strict();
export type PreviewNativeTarget=z.infer<typeof PreviewNativeTargetSchema>;

/** Cooperative metadata is evidence from project DOM, never instruction authority. */
export interface PreviewInspector {
  bridgeScript(): string;
  openWorkspace(
    ownHostUrl: string,
    projectId: string,
    target?: PreviewNativeTarget,
  ): Promise<{ sessionId: string }>;
  openDevTools(
    sessionId: string,
    projectId: string,
  ): Promise<{
    targetId: string;
    devToolsTargetId: string;
    projectId: string;
    generation: number;
  }>;
  closeWorkspace(sessionId: string): Promise<void>;
}
export const PreviewSelectionSchema = z
  .object({
    stableId: z.string().max(128).nullable(),
    identityStatus: z.enum(['missing', 'duplicate', 'annotated']),
    tag: z.string().max(64),
    role: z.string().max(64).nullable(),
    name: z.string().max(256),
    source: z.union([
      z
        .object({ status: z.literal('unknown'), reason: z.string().max(256) })
        .strict(),
      z
        .object({
          status: z.literal('annotated'),
          value: z.string().max(512),
          verified: z.literal(false),
        })
        .strict(),
    ]),
    tokens: z
      .object({
        references: z
          .array(
            z
              .object({
                token: z.string().max(96),
                properties: z.array(z.string().max(96)).max(8),
                evidence: z.string().max(64),
                computedValue: z.string().max(256),
                propertyValues: z.record(z.string().max(256)),
              })
              .strict(),
          )
          .max(64),
        unreadableSheets: z.number().int().nonnegative(),
        coverage: z.string().max(512),
      })
      .strict(),
    bounds: z
      .object({
        x: z.number().finite(),
        y: z.number().finite(),
        width: z.number().finite().nonnegative(),
        height: z.number().finite().nonnegative(),
      })
      .strict(),
    shadow: z.enum(['open-shadow', 'document']),
  })
  .strict();
export type PreviewSelection = z.infer<typeof PreviewSelectionSchema>;
