import { z } from 'zod';
export type WisdomInspection = {
  projectId: string;
  status: 'absent' | 'partial' | 'existing' | 'unpopulated';
  version?: string;
  warnings: string[];
};
export type WisdomProposal = {
  projectId: string;
  sha256: string;
  bundleVersion: string;
  changes: {
    path: string;
    operation: 'add' | 'append';
    sha256: string;
    expectedHash: string | null;
    text: string;
  }[];
  targetGateRequired?: boolean;
  previewOnly?: boolean;
  conflicts: string[];
  warnings: string[];
};
export interface WisdomTool {
  inspect(projectId: string): Promise<WisdomInspection>;
  plan(
    projectId: string,
    options?: { previewOnly?: boolean },
  ): Promise<WisdomProposal>;
  apply(
    projectId: string,
    proposalSha: string,
  ): Promise<{ inspection: WisdomInspection; added: string[] }>;
}

export const WisdomInspectionSchema = z.object({
  projectId: z.string(),
  status: z.enum(['absent', 'partial', 'existing', 'unpopulated']),
  version: z.string().optional(),
  warnings: z.array(z.string()),
});
export const WisdomProposalSchema = z.object({
  projectId: z.string(),
  sha256: z.string().regex(/^[a-f0-9]{64}$/),
  bundleVersion: z.string(),
  targetGateRequired: z.boolean().optional(),
  previewOnly: z.boolean().optional(),
  changes: z.array(
    z.object({
      path: z.string(),
      operation: z.enum(['add', 'append']),
      sha256: z.string(),
      expectedHash: z.string().nullable(),
      text: z.string(),
    }),
  ),
  conflicts: z.array(z.string()),
  warnings: z.array(z.string()),
});
