import { z } from 'zod';
import { ProjectIdSchema } from './workspace.ts';

export const TerminalSizeSchema = z.object({
  cols: z.number().int().min(2).max(500),
  rows: z.number().int().min(2).max(500),
}).strict();
export const TerminalCreateSchema = TerminalSizeSchema.extend({
  projectId: ProjectIdSchema,
  nodeId: z.string().min(1).max(128),
  cwd: z.string().max(1024).refine(v => !v.includes('\0')).default('.'),
  shell: z.enum(['bash', 'sh']).default('bash'),
}).strict();
export type TerminalCreate = z.infer<typeof TerminalCreateSchema>;
export const TerminalInputSchema = z.object({
  data: z.string().min(1).max(65536),
}).strict();
export const TerminalSessionSchema = TerminalSizeSchema.extend({
  id: z.string().uuid(),
  projectId: ProjectIdSchema,
  nodeId: z.string(),
  cwd: z.string(),
  shell: z.enum(['bash', 'sh']),
  pid: z.number().int().positive(),
  status: z.enum(['running', 'exited']),
  exitCode: z.number().int().nullable(),
  cursor: z.number().int().nonnegative(),
}).strict();
export type TerminalSession = z.infer<typeof TerminalSessionSchema>;
export const TerminalReplaySchema = z.object({
  session: TerminalSessionSchema,
  reset: z.boolean(),
  chunks: z.array(z.object({seq: z.number().int().positive(), data: z.string()}).strict()),
}).strict();
export type TerminalReplay = z.infer<typeof TerminalReplaySchema>;

/** Configured host roots; resolving cwd does not sandbox an interactive shell. */
export interface WorkspaceRoots {
  resolve(projectId: string, cwd: string): Promise<string>;
}
/** App owns PTYs. Detaching observers never stops a process. Output is transient. */
export interface TerminalService {
  create(command: TerminalCreate): Promise<TerminalSession>;
  list(projectId: string): TerminalSession[];
  inspect(id: string): TerminalSession;
  read(id: string, after: number): TerminalReplay;
  subscribe(id: string, listener: () => void): () => void;
  write(id: string, data: string): void;
  resize(id: string, size: z.infer<typeof TerminalSizeSchema>): void;
  close(id: string): Promise<TerminalSession>;
}
