import type { PlanningService } from './planning.ts';
export * from './planning.ts';
import type { WisdomTool } from './wisdom.ts';
export * from './wisdom.ts';
import type { PreviewInspector } from './preview.ts';
import type { ProjectServers } from './servers.ts';
export * from './servers.ts';
export * from './preview.ts';
import type { BrowserHost, BrowserControl } from './browser.ts';
export * from './browser.ts';
import type { ProjectCatalog } from './projects.ts';
export * from './projects.ts';
import type { RegistryMap } from './architecture.ts';
export * from './architecture.ts';
import { z } from 'zod';
import type { CanvasStore } from './workspace.ts';
import type { TerminalService, WorkspaceRoots } from './terminal.ts';
export * from './workspace.ts';
export * from './terminal.ts';

export const StartCommandSchema = z
  .object({
    commandId: z.string().min(1).max(128),
    projectId: z.string().min(1).max(128),
    sessionId: z.string().min(1).max(128),
    prompt: z.string().trim().min(1).max(2000),
  })
  .strict();
export type StartCommand = z.infer<typeof StartCommandSchema>;
export const ToolRequestSchema = z
  .object({
    operationId: z.string(),
    attemptId: z.string(),
    runId: z.string(),
    projectId: z.string(),
    tool: z.literal('echo'),
    args: z.object({ text: z.string().max(2000) }).strict(),
  })
  .strict();
export type ToolRequest = z.infer<typeof ToolRequestSchema>;
export const ToolResultSchema = z
  .object({ output: z.string().max(10000) })
  .strict();
export type ToolResult = z.infer<typeof ToolResultSchema>;
export const ModelReplySchema = z.discriminatedUnion('kind', [
  z
    .object({
      kind: z.literal('tool'),
      tool: z.literal('echo'),
      args: z.object({ text: z.string().max(2000) }).strict(),
    })
    .strict(),
  z.object({ kind: z.literal('final'), text: z.string().max(10000) }).strict(),
]);
export type ModelReply = z.infer<typeof ModelReplySchema>;
export interface AuthorizedToolRequest {
  readonly authorizationVersion: 1;
  readonly request: ToolRequest;
  readonly requestHash: string;
  readonly policyVersion: string;
}
export type PolicyDecision =
  | { allowed: true; authorized: AuthorizedToolRequest }
  | { allowed: false; reason: string };
export interface ModelProvider {
  complete(input: {
    prompt: string;
    previous?: ToolResult;
    signal: AbortSignal;
  }): Promise<ModelReply>;
}
export interface ToolExecutor {
  execute(
    request: AuthorizedToolRequest,
    signal: AbortSignal,
  ): Promise<ToolResult>;
}
export interface PermissionPolicy {
  authorize(request: ToolRequest): Promise<PolicyDecision>;
}

export const EventInputSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('run.created'), data: StartCommandSchema }),
  z.object({ type: z.literal('run.started'), data: z.object({}) }),
  z.object({ type: z.literal('model.completed'), data: ModelReplySchema }),
  z.object({ type: z.literal('operation.intent'), data: ToolRequestSchema }),
  z.object({
    type: z.literal('operation.dispatched'),
    data: z.object({ operationId: z.string(), attemptId: z.string() }),
  }),
  z.object({
    type: z.literal('operation.completed'),
    data: z.object({ operationId: z.string(), result: ToolResultSchema }),
  }),
  z.object({
    type: z.literal('run.completed'),
    data: z.object({ output: z.string().max(10000) }),
  }),
  z.object({
    type: z.literal('run.cancelled'),
    data: z.object({ reason: z.string() }),
  }),
  z.object({
    type: z.literal('run.failed'),
    data: z.object({ error: z.string() }),
  }),
  z.object({
    type: z.literal('run.reconciliation-required'),
    data: z.object({ operationId: z.string(), reason: z.string() }),
  }),
]);
export type EventInput = z.infer<typeof EventInputSchema>;
export interface RunEvent {
  seq: number;
  eventId: string;
  at: string;
  schemaVersion: 1;
  input: EventInput;
}
export interface Journal {
  runId: string;
  command: StartCommand;
  events: RunEvent[];
}
export interface RunStore {
  create(command: StartCommand): Promise<Journal>;
  read(runId: string): Promise<Journal>;
  list(): Promise<Journal[]>;
  append(
    runId: string,
    expectedSequence: number,
    event: EventInput,
  ): Promise<Journal>;
}
export type RunStatus =
  | 'queued'
  | 'running'
  | 'interrupted'
  | 'completed'
  | 'cancelled'
  | 'failed'
  | 'reconciliation-required';
export interface RunSnapshot {
  runId: string;
  command: StartCommand;
  status: RunStatus;
  output?: string;
  error?: string;
  events: RunEvent[];
}
export interface RunController {
  start(command: StartCommand): Promise<RunSnapshot>;
  inspect(runId: string): Promise<RunSnapshot>;
  list(): Promise<RunSnapshot[]>;
  resume(runId: string): Promise<RunSnapshot>;
  cancel(runId: string): Promise<RunSnapshot>;
}
export interface HttpEndpoint {
  url: string;
}
export interface ServiceMap {
  planning: PlanningService;
  wisdom: WisdomTool;
  servers: ProjectServers;
  previewInspector: PreviewInspector;
  browsers: BrowserHost;
  browserControl: BrowserControl;
  projects: ProjectCatalog;
  architecture: RegistryMap;
  workspace: WorkspaceRoots;
  terminals: TerminalService;
  canvas: CanvasStore;
  store: RunStore;
  model: ModelProvider;
  tools: ToolExecutor;
  policy: PermissionPolicy;
  runs: RunController;
  http: HttpEndpoint;
}
export type ServiceKey = keyof ServiceMap;
export interface PluginManifest {
  id: string;
  version: string;
  apiVersion: 1;
  provides: readonly ServiceKey[];
  requires: readonly ServiceKey[];
  live?: readonly ServiceKey[];
  capabilities: readonly string[];
  reload: 'idle' | 'restart';
}
export interface PluginScope {
  get<K extends ServiceKey>(key: K): ServiceMap[K];
  ref<K extends ServiceKey>(key: K): () => ServiceMap[K];
  provide<K extends ServiceKey>(key: K, service: ServiceMap[K]): void;
  onDispose(cleanup: () => void | Promise<void>): void;
  lease(): () => void;
}
export interface PluginDefinition {
  manifest: PluginManifest;
  activate(scope: PluginScope): void | Promise<void>;
}
export interface PluginHealth {
  id: string;
  version: string;
  state: 'active' | 'failed' | 'disposed';
  generation: number;
  leases: number;
}
export class ApplicationError extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = 'ApplicationError';
    this.code = code;
  }
}
/** Stable, deterministic JSON for normalized contract values (no secrets or binary data). */
export function canonicalJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (value !== null && typeof value === 'object') {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      .sort()
      .map((k) => `${JSON.stringify(k)}:${canonicalJson(record[k])}`)
      .join(',')}}`;
  }
  const result = JSON.stringify(value);
  if (result === undefined)
    throw new ApplicationError('INVALID_JSON', 'Unsupported JSON value');
  return result;
}
