import { z } from 'zod';
import { ProjectIdSchema } from './workspace.ts';
const id = z.string().min(1).max(160);
export const PlanActionSchema = z.enum([
  'begin',
  'verify',
  'finish',
  'reset',
  'move',
]);
export const PlanCommandSchema = z
  .object({
    projectId: ProjectIdSchema,
    commandId: z.string().uuid(),
    expectedRevision: z
      .number()
      .int()
      .nonnegative()
      .max(Number.MAX_SAFE_INTEGER),
    expectedDigest: z.string().regex(/^[a-f0-9]{64}$/),
    taskId: id,
    action: PlanActionSchema,
    targetSliceId: id.optional(),
    position: z
      .number()
      .int()
      .nonnegative()
      .max(Number.MAX_SAFE_INTEGER)
      .optional(),
  })
  .strict()
  .superRefine((command, ctx) => {
    if (
      command.action === 'move'
        ? command.targetSliceId === undefined || command.position === undefined
        : command.targetSliceId !== undefined || command.position !== undefined
    )
      ctx.addIssue({
        code: 'custom',
        message: 'Only move commands require targetSliceId and position.',
      });
  });
export type PlanCommand = z.infer<typeof PlanCommandSchema>;
const entity = {
  id,
  title: z.string(),
  position: z.number().int().nonnegative(),
};
export const PlanTaskSchema = z
  .object({
    id,
    title: z.string(),
    sliceId: id,
    status: z.enum(['pending', 'running', 'review', 'complete']),
    position: z.number().int().nonnegative(),
    dependsOn: z.array(id),
    checks: z.array(
      z.object({ id, argv: z.array(z.string()).min(1) }).strict(),
    ),
    write: z.array(z.string()),
    kind: z.string().optional(),
    availableActions: z.array(PlanActionSchema),
  })
  .strict();
export type PlanTask = z.infer<typeof PlanTaskSchema>;
export const PlanSnapshotSchema = z
  .object({
    projectId: ProjectIdSchema,
    revision: z.number().int().nonnegative(),
    digest: z.string().regex(/^[a-f0-9]{64}$/),
    writable: z.boolean(),
    reason: z.string().optional(),
    activeTaskId: id.optional(),
    segments: z.array(z.object(entity).strict()),
    milestones: z.array(z.object({ ...entity, segmentId: id }).strict()),
    slices: z.array(z.object({ ...entity, milestoneId: id }).strict()),
    tasks: z.array(PlanTaskSchema),
  })
  .strict();
export type PlanSnapshot = z.infer<typeof PlanSnapshotSchema>;
export interface PlanningService {
  snapshot(projectId: string): Promise<PlanSnapshot>;
  command(command: PlanCommand): Promise<PlanSnapshot>;
}
