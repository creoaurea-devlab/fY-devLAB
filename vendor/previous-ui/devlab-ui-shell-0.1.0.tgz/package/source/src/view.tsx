import { useWorkspaceFocus } from './workspace-focus.ts';
import { useTerminalDock } from './terminals.tsx';
import { ServerSessions } from './servers.tsx';
import {
  useEffect,
  useRef,
  useId,
  useState,
  useSyncExternalStore,
  type ReactNode,
} from 'react';
import {
  FolderOpen,
  ChevronDown,
  GitBranch,
  Palette,
  Layout,
  AlignCenter,
  LayoutGrid,
  Map as MapIcon,
  Wrench,
  RotateCcw,
  Trash2,
  Download,
  Upload,
  Settings2,
  Sun,
  Moon,
  Terminal,
  Bot,
  TerminalSquare,
  X,
  Maximize2,
  Minimize2,
  Send,
  Save,
  Undo2,
  Redo2,
} from 'lucide-react';
import {
  CanvasGraphSchema,
  type RunSnapshot,
  type PluginHealth,
} from '@devlab/contracts';
import type { CanvasWorkspaceState, UIPluginProps } from '@devlab/ui-contracts';

const EMPTY: CanvasWorkspaceState = {
  projectId: 'default',
  graph: { name: 'My Agent Flow', nodes: [], edges: [] },
  revision: 0,
  selectedNodeId: null,
  dirty: false,
  loading: false,
  saving: false,
  error: '',
  canUndo: false,
  canRedo: false,
};
const subscribeEmpty = () => () => {};
const emptySnapshot = () => EMPTY;
function IconButton({
  title,
  children,
  onClick,
  disabled = false,
  testId,
  active = false,
}: {
  title: string;
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
  testId?: string;
  active?: boolean;
}) {
  return (
    <button
      className={`icon-button${active ? ' active-icon' : ''}`}
      title={title}
      aria-label={title}
      onClick={onClick}
      disabled={disabled}
      data-testid={testId}
    >
      {children}
    </button>
  );
}

/** Original workspace geometry and visual tokens; all data access crosses typed ports. */
export function WorkspaceShell({
  client,
  draft,
  setDraft,
  workspace,
  renderCanvas,
  renderHood,
  projectWorkspace,
  renderProjects,
  renderPreview,
  renderTerminal,
  renderPlanning,
}: UIPluginProps) {
  const state = useSyncExternalStore(
    workspace?.subscribe ?? subscribeEmpty,
    workspace?.snapshot ?? emptySnapshot,
  );
  const projectState = useSyncExternalStore(
    projectWorkspace?.subscribe ?? subscribeEmpty,
    projectWorkspace?.snapshot ?? (() => null),
  );
  const [hoodOpen, setHoodOpen] = useState(false);
  const previewFocus = useWorkspaceFocus();
  const [dark, setDark] = useState(() => {
    try {
      return localStorage.getItem('devlab:theme') !== 'light';
    } catch {
      return true;
    }
  });
  const [explorer, setExplorer] = useState(true),
    [paletteVisible, setPaletteVisible] = useState(true);
  const projectsId = useId();
  const projectsElement = useRef<HTMLDivElement>(null);
  const workspaceBody = useRef<HTMLDivElement>(null);
  const drawerTrigger = useRef<HTMLElement | null>(null);
  const [compact, setCompact] = useState(() => matchMedia('(max-width: 1100px)').matches);
  const [compactDrawer, setCompactDrawer] = useState<'projects' | 'catalog' | null>(null);
  const projectsOpen = compact ? compactDrawer === 'projects' : explorer;
  const catalogOpen = compact ? compactDrawer === 'catalog' : paletteVisible;
  const restoreDrawerFocus = () => { requestAnimationFrame(() => { if (drawerTrigger.current?.isConnected) drawerTrigger.current.focus(); }); };
  const setProjectsOpen = (next: boolean) => {
    if (next) drawerTrigger.current = document.activeElement as HTMLElement;
    if (compact) setCompactDrawer(next ? 'projects' : null); else setExplorer(next);
    if (!next) restoreDrawerFocus();
  };
  const setCatalogOpen = (next: boolean) => {
    if (next) drawerTrigger.current = document.activeElement as HTMLElement;
    if (compact) setCompactDrawer(next ? 'catalog' : null); else setPaletteVisible(next);
    if (!next) restoreDrawerFocus();
  };
  useEffect(() => {
    const media = matchMedia('(max-width: 1100px)');
    const change = () => { setCompact(media.matches); setCompactDrawer(null); };
    media.addEventListener('change', change);
    return () => media.removeEventListener('change', change);
  }, []);
  useEffect(() => {
    if (!compactDrawer) return;
    const tick = requestAnimationFrame(() => {
      const region = compactDrawer === 'projects' ? projectsElement.current : workspaceBody.current?.querySelector('.node-palette');
      region?.querySelector<HTMLElement>('button:not(:disabled),input:not(:disabled),summary')?.focus();
    });
    return () => cancelAnimationFrame(tick);
  }, [compactDrawer]);

  const [minimapVisible, setMinimapVisible] = useState(() => {
    try {
      return localStorage.getItem('devlab:workflow-minimap') !== 'false';
    } catch {
      return true;
    }
  });
  const [settings, setSettings] = useState(false),
    [settingsTab, setSettingsTab] = useState('keys'),
    [menu, setMenu] = useState(false);
  const [consoleOpen, setConsoleOpen] = useState(false),
    [execution, setExecution] = useState(false),
    [maximized, setMaximized] = useState(false),
    [terminalTab, setTerminalTab] = useState(false),
    [serverTab, setServerTab] = useState(false),
    [planningOpen,setPlanningOpen] = useState(false);
  const [terminalMounted, setTerminalMounted] = useState(false);
  const outputTrigger = useRef<HTMLElement | null>(null);
  const closeOutput = () => {
    setExecution(false); setConsoleOpen(false);
    requestAnimationFrame(() => { if (outputTrigger.current?.isConnected) outputTrigger.current.focus(); });
  };
  const openOutput = (view: 'agents' | 'terminal' | 'servers' | 'planning') => {
    outputTrigger.current = document.activeElement as HTMLElement;
    if (view === 'terminal') setTerminalMounted(true);
    setPlanningOpen(view === 'planning'); setServerTab(view === 'servers'); setTerminalTab(view === 'terminal');
    setConsoleOpen(false); setExecution(true);
  };
  const selectOutput = (view: 'agents' | 'terminal' | 'servers' | 'planning') => {
    const same = view === 'planning' ? planningOpen : !planningOpen && (view === 'servers' ? serverTab : !serverTab && (view === 'terminal' ? terminalTab : !terminalTab));
    if (execution && !consoleOpen && same) closeOutput(); else openOutput(view);
  };
  const toggleConsole = () => {
    if (consoleOpen) { closeOutput(); return; }
    outputTrigger.current = document.activeElement as HTMLElement;
    setExecution(false); setConsoleOpen(true);
  };
  const [runs, setRuns] = useState<RunSnapshot[]>([]),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [uppercase, setUppercase] = useState(false);
  const [nameDraft, setNameDraft] = useState<string | null>(null);
  const [health, setHealth] = useState<PluginHealth[] | null>(null),
    [logFilter, setLogFilter] = useState('all');
  const input = useRef<HTMLInputElement>(null);
  const terminalDock = useTerminalDock({
    client,
    workspace,
    renderTerminal,
    active: execution && !consoleOpen && terminalTab && !serverTab && !planningOpen,
    show: () => openOutput('terminal'),
  });
  const graph = state.graph;
  const agents = graph.nodes.filter(
    (n) => n.type === 'piAgent' || n.type === 'subagent',
  );
  const active = agents.find((n) => n.id === state.selectedNodeId) ?? agents[0];
  const label = (id: string) =>
    String(
      agents.find((n) => n.id === id)?.data.label ??
        `Hermes Agent ${agents.findIndex((n) => n.id === id) + 1}`,
    );
  const agentRuns = runs.filter(
    (r) =>
      r.command.projectId === state.projectId &&
      r.command.sessionId === active?.id,
  );
  const current = agentRuns[0];
  const running = current?.status === 'running' || current?.status === 'queued';
  const action = async (fn: () => Promise<unknown>) => {
    setError('');
    setBusy(true);
    try {
      await fn();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };
  const update = (next: typeof graph) => {
    try {
      workspace?.update(next);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  };
  const layout = () =>
    update({
      ...graph,
      nodes: graph.nodes.map((n, i) => ({
        ...n,
        position: { x: (i % 3) * 320 + 100, y: Math.floor(i / 3) * 280 + 80 },
      })),
      viewport: { x: 0, y: 0, zoom: 1 },
    });
  const alignSelected = () => {
    const selected = graph.nodes.filter((node) => node.selected === true);
    if (selected.length < 2) return;
    const left = Math.min(...selected.map((node) => node.position.x));
    const top = Math.min(...selected.map((node) => node.position.y));
    const positions = new Map(
      selected.map((node, index) => [
        node.id,
        { x: left + (index % 3) * 280, y: top + Math.floor(index / 3) * 240 },
      ]),
    );
    update({
      ...graph,
      nodes: graph.nodes.map((node) => ({
        ...node,
        position: positions.get(node.id) ?? node.position,
      })),
    });
  };
  useEffect(() => {
    let disposed = false;
    let timer: ReturnType<typeof setTimeout>;
    const refresh = async () => {
      try {
        const value = await client.list();
        if (!disposed) setRuns(value.slice().reverse());
      } catch (e) {
        if (!disposed) setError(String(e));
      } finally {
        if (!disposed) timer = setTimeout(() => void refresh(), 700);
      }
    };
    void refresh();
    return () => {
      disposed = true;
      clearTimeout(timer);
    };
  }, [client]);
  useEffect(() => {
    const handle = (event: KeyboardEvent) => {
      if (event.defaultPrevented) return;
      if (event.key === 'Escape') {
        if (settings || health || menu) { event.preventDefault(); setSettings(false); setHealth(null); setMenu(false); return; }
        if (execution || consoleOpen) { event.preventDefault(); closeOutput(); return; }
        if (compactDrawer) { event.preventDefault(); setCompactDrawer(null); restoreDrawerFocus(); return; }
        if (previewFocus.mode) { event.preventDefault(); void previewFocus.exit(); return; }
        setSettings(false);
        setMenu(false);
        setHealth(null);
        workspace?.select(null);
      }
      const target = event.target as HTMLElement;
      const editing =
        ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) ||
        target.isContentEditable;
      if (!(event.ctrlKey || event.metaKey)) return;
      if (event.key.toLowerCase() === 's') {
        event.preventDefault();
        void workspace?.save();
      }
      if (event.key === '`') {
        event.preventDefault();
        toggleConsole();
      }
      if (!editing && event.key.toLowerCase() === 'z') {
        event.preventDefault();
        event.shiftKey ? workspace?.redo() : workspace?.undo();
      }
      if (!editing && event.key.toLowerCase() === 'l') {
        event.preventDefault();
        alignSelected();
      }
    };
    window.addEventListener('keydown', handle);
    return () => window.removeEventListener('keydown', handle);
  });
  useEffect(() => {
    const warn = (event: BeforeUnloadEvent) => {
      if (state.dirty) {
        event.preventDefault();
        event.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [state.dirty]);
  const exportFlow = () => {
    const blob = new Blob(
      [JSON.stringify({ ...graph, version: '2.0.0' }, null, 2)],
      { type: 'application/json' },
    );
    const url = URL.createObjectURL(blob),
      anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${graph.name.replace(/[^\w-]+/g, '-')}.flow.json`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const run = () =>
    void action(async () => {
      if (!active || !draft.trim()) return;
      const next = await client.start({
        commandId: crypto.randomUUID(),
        projectId: state.projectId,
        sessionId: active.id,
        prompt: draft,
      });
      setRuns((values) => [
        next,
        ...values.filter((r) => r.runId !== next.runId),
      ]);
      setDraft('');
      setExecution(true);
    });
  const icon = (
    title: string,
    child: ReactNode,
    fn: () => void,
    testId?: string,
    disabled = false,
  ) => (
    <IconButton
      key={title}
      title={title}
      onClick={fn}
      testId={testId}
      disabled={disabled}
    >
      {child}
    </IconButton>
  );
  const editingStage = (
    <>
      <div
        className="project-flow-stage"
        style={{ display: projectState?.mode === 'build' ? 'none' : 'flex' }}
      >
        {renderCanvas ? (
          renderCanvas({
        paletteVisible: catalogOpen,
        setPaletteVisible: setCatalogOpen,
            minimapVisible,
            setMinimapVisible: (next) => {
              setMinimapVisible(next);
              try { localStorage.setItem('devlab:workflow-minimap', String(next)); } catch {}
            },
            dockedTerminal: terminalDock.dockedTerminal,
          })
        ) : (
          <div className="canvas-loading">Loading canvas module…</div>
        )}
      </div>
      {projectState?.mode === 'build' && renderProjects && (
        <div className="project-build-stage">
          {renderProjects({ view: 'canvas' })}
        </div>
      )}
    </>
  );
  return (
    <div
      className={`devlab${dark ? ' dark' : ''}`}
      data-canvas-mode={projectState?.mode ?? 'flow'}
      ref={previewFocus.root}
      data-preview-focused={!!previewFocus.mode}
      data-preview-focus-mode={previewFocus.mode ?? ''}
      data-testid="flow-editor-root"
    >
      <div className="toolbar">
        <div className="devlab-brand">
          <div className="devlab-brand-icon">
            <svg
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              aria-label="ClaudeFlow"
            >
              <circle cx="3" cy="8" r="2" fill="white" />
              <circle cx="13" cy="4" r="2" fill="white" />
              <circle cx="13" cy="12" r="2" fill="white" />
              <path
                d="M5 8 L11 4 M5 8 L11 12"
                stroke="white"
                strokeWidth="1.2"
              />
            </svg>
          </div>
          <div>
            <strong>ClaudeFlow</strong>
            <small>
              v2 · Agent Editor{state.saving && <span title="Saving…"> ·</span>}
            </small>
          </div>
        </div>
        {projectWorkspace ? (
          <>
            <select
              className="project-switcher"
              aria-label="Active project"
              value={state.projectId}
              disabled={projectState?.busy}
              onChange={(e) =>
                void projectWorkspace.select(e.target.value).catch(() => {})
              }
            >
              {projectState?.projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.label}
                </option>
              ))}
            </select>
            <div className="project-mode-toggle" aria-label="Canvas mode">
              <button
                aria-pressed={projectState?.mode === 'flow'}
                onClick={() => projectWorkspace.setMode('flow')}
              >
                Workflow
              </button>
              <button
                aria-pressed={projectState?.mode === 'build'}
                onClick={() => projectWorkspace.setMode('build')}
              >
                Build canvas
              </button>
            </div>
          </>
        ) : (
          <button className="project-switcher" disabled>
            <FolderOpen size={12} />
            Default Project
            <ChevronDown size={10} />
          </button>
        )}
        <input
          aria-label="Flow name"
          data-testid="flow-name-input"
          className="flow-title"
          value={nameDraft ?? graph.name}
          disabled={!workspace || state.loading}
          onChange={(e) => setNameDraft(e.target.value)}
          onBlur={() => {
            if (nameDraft?.trim()) update({ ...graph, name: nameDraft.trim() });
            setNameDraft(null);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter') e.currentTarget.blur();
          }}
        />
        <span className="graph-badge">
          <GitBranch size={9} />
          {graph.nodes.length}n · {graph.edges.length}e · {agents.length}ag
        </span>
        <label className="canvas-color" title="Canvas background color">
          <Palette size={13} />
          <input
            type="color"
            aria-label="Canvas background color"
            value={
              typeof graph.background === 'string'
                ? graph.background
                : '#0d1117'
            }
            onChange={(e) => update({ ...graph, background: e.target.value })}
            disabled={!workspace}
          />
        </label>
        <div className="toolbar-spacer" />
        {icon(
          'Layout nodes',
          <Layout size={13} />,
          layout,
          'btn-layout',
          !workspace || projectState?.mode === 'build',
        )}
        {icon(
          'Align selected nodes',
          <AlignCenter size={13} />,
          alignSelected,
          'btn-align-selected',
          !workspace,
        )}
        <IconButton
          title="Toggle Node Catalog"
          onClick={() => setCatalogOpen(!catalogOpen)}
          testId="btn-toggle-catalog"
          active={catalogOpen}
        >
          <LayoutGrid size={13} />
        </IconButton>
        <button
          type="button"
          className={`icon-button${minimapVisible ? ' active-icon' : ''}`}
          title="Toggle workflow minimap"
          aria-label="Toggle workflow minimap"
          aria-pressed={minimapVisible}
          data-testid="btn-toggle-minimap"
          data-devlab-id="workspace.minimap-toggle"
          data-devlab-source="plugins/ui-shell/src/view.tsx"
          disabled={!renderCanvas || projectState?.mode === 'build'}
          onClick={() => {
            const next = !minimapVisible;
            setMinimapVisible(next);
            try {
              localStorage.setItem('devlab:workflow-minimap', String(next));
            } catch {
              // The view preference remains usable without browser storage.
            }
          }}
        >
          <MapIcon size={13} aria-hidden="true" />
        </button>
        {icon(
          'Pop the Hood',
          <Wrench size={13} />,
          () => setHoodOpen(true),
          'btn-hood',
          !renderHood,
        )}
        {icon(
          'Reload saved graph',
          <RotateCcw size={13} />,
          () => {
            if (
              !state.dirty ||
              confirm('Discard unsaved edits and reload the saved graph?')
            )
              void workspace?.reload();
          },
          'btn-load-default',
          !workspace,
        )}
        {icon(
          'Clear canvas',
          <Trash2 size={13} />,
          () => {
            if (confirm('Clear all nodes and connections?'))
              update({ ...graph, nodes: [], edges: [] });
          },
          'btn-clear',
          !workspace || projectState?.mode === 'build',
        )}
        {icon(
          'Export flow',
          <Download size={13} />,
          exportFlow,
          'btn-export',
          !workspace,
        )}
        {icon(
          'Import flow',
          <Upload size={13} />,
          () => input.current?.click(),
          'btn-import',
          !workspace,
        )}
        <div className="gear-menu">
          {icon(
            'Settings',
            <Settings2 size={13} />,
            () => setMenu((v) => !v),
            'btn-gear',
          )}
          {menu && (
            <div className="settings-menu">
              <button
                data-testid="menu-api-keys"
                onClick={() => {
                  setSettings(true);
                  setMenu(false);
                }}
              >
                API Keys & Settings
              </button>
              <a href="/?view=kernel">Kernel Lab</a>
            </div>
          )}
        </div>
        {icon(
          dark ? 'Light mode' : 'Dark mode',
          dark ? <Sun size={13} /> : <Moon size={13} />,
          () => {
            setDark((v) => !v);
            try {
              localStorage.setItem('devlab:theme', dark ? 'light' : 'dark');
            } catch {
              /* Theme still works in memory. */
            }
          },
          'btn-theme-toggle',
        )}
        <input
          ref={input}
          type="file"
          accept=".json,application/json"
          hidden
          data-testid="flow-import-input"
          onChange={(e) => {
            const file = e.target.files?.[0];
            e.target.value = '';
            if (!file) return;
            void action(async () => {
              if (file.size > 2 * 1024 * 1024)
                throw new Error('Flow file exceeds 2 MiB');
              const value = JSON.parse(await file.text()) as Record<
                string,
                unknown
              >;
              const next = CanvasGraphSchema.parse(value.graph ?? value);
              workspace?.update(next);
              workspace?.select(null);
            });
          }}
        />
      </div>
      {(state.error || error || projectState?.error) && (
        <div className="workspace-error" role="alert">
          {state.error || error || projectState?.error}
          <button
            onClick={() => {
              setError('');
              projectWorkspace?.clearError();
            }}
            aria-label="Dismiss notification"
          >
            <X size={12} />
          </button>
        </div>
      )}
      <div className="workspace-body" ref={workspaceBody} data-compact={compact}>
        <div className="workspace-projects" ref={projectsElement} id={projectsId} hidden={!projectsOpen} data-devlab-id="workspace.projects.drawer" data-devlab-source="plugins/ui-shell/src/view.tsx">
          {renderProjects ? renderProjects({view:'explorer', collapse:()=>setProjectsOpen(false)}) : <div className="project-explorer-container"><div className="project-explorer-empty">Project adapter is unavailable</div></div>}
        </div>
        <div className="project-explorer-collapsed" hidden={projectsOpen}>
          <button className="tree-action-btn" aria-label="Expand project explorer" aria-expanded={projectsOpen} aria-controls={projectsId} data-devlab-id="workspace.projects.open" data-devlab-source="plugins/ui-shell/src/view.tsx" onClick={()=>setProjectsOpen(true)}><FolderOpen size={14}/></button>
        </div>
      {renderPreview
          ? renderPreview({
              projectId: projectState?.projectId ?? 'default',
              workspaceFocused: !!previewFocus.mode,
            children: editingStage,
              onSourceSelect: (path) => void projectWorkspace?.openFile(path),
            })
          : editingStage}
      </div>
      <div className="execution-panel" role="region" aria-label="Workspace output" data-devlab-id="workspace.output.drawer" data-devlab-source="plugins/ui-shell/src/view.tsx" hidden={!execution || consoleOpen} style={{height:maximized?'72vh':'clamp(160px,28vh,320px)',maxHeight:maximized?'72vh':'36vh'}} >
        {terminalMounted && <div className="workspace-terminal-retained" hidden={!execution || !terminalTab || serverTab || planningOpen || consoleOpen}>{terminalDock.panel}</div>}
        {renderPlanning && <div id="workspace-planning-drawer" className="workspace-planning-drawer" hidden={!execution || !planningOpen}>{renderPlanning(execution && planningOpen)}</div>}
        {execution && !planningOpen &&
          (serverTab ? (
            <ServerSessions client={client} />
          ) : terminalTab ? (
            null
          ) : (
            <div className="execution-split">
              <div className="execution-log" data-testid="execution-log">
                {current ? (
                  <>
                    <div className="execution-log-line system">
                      {current.command.prompt}
                    </div>
                    {current.events.map((event) => (
                      <div
                        className={`execution-log-line ${event.input.type === 'run.failed' ? 'error' : event.input.type === 'operation.completed' ? 'tool' : 'system'}`}
                        key={event.eventId}
                      >
                        {event.input.type === 'run.completed'
                          ? event.input.data.output
                          : event.input.type === 'operation.completed'
                            ? event.input.data.result.output
                            : event.input.type}
                      </div>
                    ))}
                  </>
                ) : (
                  <div className="execution-empty">
                    <Terminal size={22} />
                    <div>Select an agent to view execution output</div>
                  </div>
                )}
              </div>
              {active && (
                <div className="agent-chat">
                  <div className="chat-provider">⚙ Offline · Echo model</div>
                  <div className="chat-title">
                    ♧ Chat · {label(active.id)}
                    <span>{current?.status ?? 'Ready'}</span>
                  </div>
                  <div className="chat-history">
                    {agentRuns.length ? (
                      agentRuns
                        .slice(0, 30)
                        .reverse()
                        .map((r) => (
                          <div className="chat-exchange" key={r.runId}>
                            <div>{r.command.prompt}</div>
                            <p data-testid="run-result">
                              {r.output ?? r.error ?? r.status}
                            </p>
                            {r.status === 'interrupted' && (
                              <button
                                onClick={() =>
                                  void action(async () => {
                                    await client.resume(r.runId);
                                    setRuns((await client.list()).reverse());
                                  })
                                }
                              >
                                Resume
                              </button>
                            )}
                          </div>
                        ))
                    ) : (
                      <div className="chat-empty">
                        <Bot size={18} />
                        <p>Chat with {label(active.id)}</p>
                      </div>
                    )}
                  </div>
                  <form
                    className="chat-input"
                    onSubmit={(e) => {
                      e.preventDefault();
                      run();
                    }}
                  >
                    <textarea
                      aria-label="Agent message"
                      maxLength={2000}
                      placeholder={`Ask ${label(active.id)}…`}
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          if (draft.trim() && !running && !busy) run();
                        }
                      }}
                    />
                    {running ? (
                      <button
                        type="button"
                        aria-label="Cancel run"
                        onClick={() =>
                          void action(async () => {
                            if (current) await client.cancel(current.runId);
                            setRuns((await client.list()).reverse());
                          })
                        }
                      >
                        <X size={14} />
                      </button>
                    ) : (
                      <button
                        type="submit"
                        aria-label="Run agent"
                        disabled={busy || !draft.trim()}
                      >
                        <Send size={14} />
                      </button>
                    )}
                  </form>
                </div>
              )}
            </div>
          ))}
      </div>
      {consoleOpen ? (
        <div className="console-panel" data-testid="console-panel">
          <div className="console-header">
            <Terminal size={12} />
            <strong>Console</strong>
            <select
              className="console-filter-select"
              aria-label="Console filter"
              value={logFilter}
              onChange={(e) => setLogFilter(e.target.value)}
            >
              <option value="all">All events</option>
              <option value="run">Runs</option>
              <option value="operation">Tools</option>
            </select>
            <span className="toolbar-spacer" />
            {icon('Close console', <X size={12} />, closeOutput)}
          </div>
          <div className="console-scroll">
            {runs.slice(0, 20).flatMap((r) =>
              r.events
                .filter(
                  (event) =>
                    logFilter === 'all' ||
                    event.input.type.startsWith(logFilter + '.'),
                )
                .map((event) => (
                  <div className="console-log-line" key={event.eventId}>
                    <span className="console-log-timestamp">
                      {new Date(event.at).toLocaleTimeString()}
                    </span>
                    <span className="console-log-badge">
                      {event.input.type}
                    </span>
                    <span className="console-log-message">
                      {r.command.prompt}
                    </span>
                  </div>
                )),
            )}
          </div>
        </div>
      ) : (
        null
      )}
      <div className="execution-tabs workspace-rail" data-testid="workspace-rail" data-devlab-id="workspace.rail" data-devlab-source="plugins/ui-shell/src/view.tsx">
        {renderPreview && <>
          <button type="button" aria-label={previewFocus.mode ? 'Exit preview focus' : 'Focus previews'} aria-pressed={!!previewFocus.mode} data-devlab-id="workspace.preview.focus" data-devlab-source="plugins/ui-shell/src/view.tsx" onClick={event=>{if(previewFocus.mode)void previewFocus.exit();else previewFocus.maximize(event.currentTarget);}}><LayoutGrid size={12}/><span>{previewFocus.mode?'Exit focus':'Previews'}</span></button>
          <button type="button" hidden={!!previewFocus.mode} aria-label="Fullscreen preview workspace" disabled={previewFocus.pending} data-devlab-id="workspace.preview.fullscreen" data-devlab-source="plugins/ui-shell/src/view.tsx" onClick={event=>void previewFocus.enter(event.currentTarget)}><Maximize2 size={12}/></button>
          {previewFocus.error && <small role="status" className="workspace-focus-error">{previewFocus.error}</small>}
        </>}

          <Terminal size={12} />
          <div
            className="agent-tabs"
            role={terminalTab && !serverTab && !planningOpen ? 'tablist' : undefined}
            aria-label={
              terminalTab && !serverTab && !planningOpen ? 'Terminal sessions' : undefined
            }
            data-devlab-id="workspace.output.tabs"
            data-devlab-source="plugins/ui-shell/src/view.tsx"
          >
            {terminalTab && !serverTab && !planningOpen
              ? terminalDock.tabs
              : !serverTab && !planningOpen &&
                agents.map((node) => (
                  <button
                    className={`agent-tab${active?.id === node.id ? ' active-tab' : ''}`}
                    key={node.id}
                    onClick={() => {
                      workspace?.select(node.id);
                    openOutput('agents');
                    }}
                  >
                    ○ {label(node.id)}{' '}
                    <span
                      className="agent-play"
                      onClick={(e) => {
                        e.stopPropagation();
                      workspace?.select(node.id);
                      openOutput('agents');
                      }}
                    >
                      ▸
                    </span>
                  </button>
                ))}
          </div>
          <button
            className={!terminalTab && !serverTab && !planningOpen ? 'active-tab' : ''}
            aria-pressed={!terminalTab && !serverTab && !planningOpen}
            data-devlab-id="workspace.output.agents"
            data-devlab-source="plugins/ui-shell/src/view.tsx"
            onClick={() => {
              selectOutput('agents');
            }}
          >
            <Bot size={9} /> Agents
          </button>
          <button
            className={terminalTab && !serverTab && !planningOpen ? 'active-tab' : ''}
            aria-pressed={terminalTab && !serverTab && !planningOpen}
            data-devlab-id="workspace.output.terminal"
            data-devlab-source="plugins/ui-shell/src/view.tsx"
            onClick={() => {
              selectOutput('terminal');
            }}
          >
            <TerminalSquare size={9} /> Terminal
          </button>
          <button
            className={serverTab && !planningOpen ? 'active-tab' : ''}
            aria-pressed={serverTab && !planningOpen}
            data-devlab-id="workspace.output.servers"
            data-devlab-source="plugins/ui-shell/src/view.tsx"
            onClick={() => {
              selectOutput('servers');
            }}
          >
            Servers
          </button>
          {renderPlanning && <button type="button" className={planningOpen && execution?'active-tab':''} aria-expanded={planningOpen && execution} aria-controls="workspace-planning-drawer" data-devlab-id="workspace.drawer.planning" data-devlab-source="plugins/ui-shell/src/view.tsx" onClick={()=>selectOutput('planning')}>Planning</button>}
          {icon(
            execution ? 'Hide output' : 'Show output',
            <ChevronDown size={13} />,
            () => { if (execution || consoleOpen) closeOutput(); else { outputTrigger.current=document.activeElement as HTMLElement; setExecution(true); } },
            'execution-toggle',
          )}
          {execution && (
            <>
              {icon(
                maximized ? 'Restore console size' : 'Enlarge console',
                maximized ? <Minimize2 size={13} /> : <Maximize2 size={13} />,
                () => setMaximized((v) => !v),
              )}
              {icon('Close lower panel', <X size={13} />, () =>
                closeOutput(),
              )}
            </>
          )}
        <button type="button" data-testid="console-toggle" data-devlab-id="workspace.output.console" data-devlab-source="plugins/ui-shell/src/view.tsx" aria-expanded={consoleOpen} onClick={toggleConsole}>Console <span>{runs.reduce((n,r)=>n+r.events.length,0)}</span></button>
<span className="toolbar-spacer" />
        <button
          className="footer-save"
          data-testid="save-graph"
          onClick={() => void workspace?.save()}
          disabled={!workspace || state.loading || state.saving}
        >
          <Save size={11} />
          <span data-testid="save-state">
            {state.loading
              ? 'Loading…'
              : state.saving
                ? 'Saving…'
                : state.dirty
                  ? 'Unsaved changes'
                  : state.revision
                    ? 'Saved'
                    : 'New flow'}
          </span>
        </button>
        <IconButton
          title="Undo"
          onClick={() => workspace?.undo()}
          disabled={!state.canUndo}
        >
          <Undo2 size={11} />
        </IconButton>
        <IconButton
          title="Redo"
          onClick={() => workspace?.redo()}
          disabled={!state.canRedo}
        >
          <Redo2 size={11} />
        </IconButton>
      </div>
      {(settings || health) && (
        <div
          className="modal-backdrop"
          onClick={() => {
            setSettings(false);
            setHealth(null);
          }}
        >
          <div
            className="settings-panel"
            data-testid="settings-panel"
            role="dialog"
            aria-modal="true"
            aria-label={health ? 'Kernel diagnostics' : 'API Keys & Settings'}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="settings-header">
              <span className="settings-key">⚿</span>
              <strong>{health ? 'Kernel diagnostics' : 'API Keys'}</strong>
              <span className="toolbar-spacer" />
              {!health && (
                <>
                  <button
                    className={settingsTab === 'keys' ? 'active-tab' : ''}
                    onClick={() => setSettingsTab('keys')}
                  >
                    API Keys
                  </button>
                  <button
                    className={settingsTab === 'shortcuts' ? 'active-tab' : ''}
                    onClick={() => setSettingsTab('shortcuts')}
                  >
                    Shortcuts
                  </button>
                </>
              )}
              {icon('Close settings', <X size={14} />, () => {
                setSettings(false);
                setHealth(null);
              })}
            </div>
            <div className="settings-body">
              {health ? (
                <>
                  {health.map((p) => (
                    <div className="provider-row" key={p.id}>
                      <strong>{p.id}</strong>
                      <span>
                        {p.state} · generation {p.generation} · {p.leases}{' '}
                        leases
                      </span>
                    </div>
                  ))}
                  <a href="/?view=kernel">Open Kernel Lab</a>
                </>
              ) : settingsTab === 'shortcuts' ? (
                <div className="shortcuts">
                  <p>Ctrl / ⌘ S — Save graph</p>
                  <p>Ctrl / ⌘ Z — Undo</p>
                  <p>Ctrl / ⌘ Shift Z — Redo</p>
                  <p>Ctrl / ⌘ L — Layout nodes</p>
                  <p>Ctrl / ⌘ ` — Toggle console</p>
                  <p>Delete — Remove selected nodes</p>
                  <p>Escape — Close selection or dialog</p>
                </div>
              ) : (
                <>
                  {[
                    'Anthropic',
                    'OpenAI',
                    'Google (Gemini)',
                    'Mistral AI',
                    'Groq',
                    'xAI (Grok)',
                    'ZAI (GLM)',
                    'Cerebras',
                  ].map((provider) => (
                    <div className="provider-row" key={provider}>
                      <div>
                        <strong>● {provider}</strong>
                        <small>Not connected</small>
                      </div>
                      <div>
                        <input
                          aria-label={`${provider} API key`}
                          type="password"
                          placeholder="API key…"
                          disabled
                        />
                        <button disabled>Test</button>
                        <button className="provider-save" disabled>
                          Save
                        </button>
                      </div>
                    </div>
                  ))}
                </>
              )}
            </div>
            <div className="settings-footer">
              {!health && settingsTab === 'keys' && (
                <>
                  External providers are not connected yet. The local echo model
                  is available.
                  <button
                    disabled={busy || running}
                    onClick={() =>
                      void action(async () => {
                        await client.replaceModel(!uppercase);
                        setUppercase((v) => !v);
                      })
                    }
                  >
                    {uppercase ? 'Use original model' : 'Use uppercase model'}
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
      {hoodOpen &&
        renderHood?.({
          onClose: () => setHoodOpen(false),
          projectId:
            state.projectId === 'default' ? 'workspace' : state.projectId,
        })}
    </div>
  );
}
