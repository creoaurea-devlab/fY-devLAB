import { useEffect, useRef, useState } from 'react';

/** Presentation only: the shell element and its domain owners never move. */
export function useWorkspaceFocus() {
  const root = useRef<HTMLDivElement>(null);
  const opener = useRef<HTMLElement | null>(null);
  const alive = useRef(true);
  const epoch = useRef(0);
  const requesting = useRef(false);
  const current = useRef<'native' | 'maximized' | null>(null);
  const [mode, setMode] = useState<typeof current.current>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const apply = (next: typeof current.current) => { current.current = next; setMode(next); };
  const restore = () => requestAnimationFrame(() => { if (opener.current?.isConnected) opener.current.focus(); });
  useEffect(() => {
    alive.current = true;
    requesting.current = false; setPending(false);
    const changed = () => {
      if (document.fullscreenElement === root.current) apply('native');
      else if (current.current === 'native') { apply(null); restore(); }
    };
    document.addEventListener('fullscreenchange', changed);
    return () => { alive.current = false; ++epoch.current; document.removeEventListener('fullscreenchange', changed); };
  }, []);
  const enter = async (trigger: HTMLElement) => {
    const element = root.current;
    if (!element || requesting.current) return;
    if (document.fullscreenElement && document.fullscreenElement !== element) {
      setError('Exit the current fullscreen element first.'); return;
    }
    opener.current = trigger;
    const token = ++epoch.current;
    requesting.current = true; setPending(true); setError('');
    try {
      if (!element.requestFullscreen) throw new Error('Unavailable');
      await element.requestFullscreen();
      if (!alive.current || token !== epoch.current) {
        if (document.fullscreenElement === element) await document.exitFullscreen();
        return;
      }
      if (document.fullscreenElement !== element) throw new Error('Not entered');
      apply('native');
    } catch {
      if (alive.current && token === epoch.current) setError('Fullscreen unavailable. Use Focus previews instead.');
    } finally {
      if (alive.current && token === epoch.current) { requesting.current=false; setPending(false); }
    }
  };
  const maximize = (trigger: HTMLElement) => {
    if (requesting.current || current.current === 'native') return;
    if (document.fullscreenElement && document.fullscreenElement !== root.current) {
      setError('Exit the current fullscreen element first.'); return;
    }
    opener.current = trigger; setError(''); apply('maximized');
  };
  const exit = async () => {
    ++epoch.current; requesting.current=false; setPending(false);
    if (document.fullscreenElement === root.current) {
      try { await document.exitFullscreen(); }
      catch { setError('Fullscreen could not exit. Press Escape to leave fullscreen.'); return; }
    }
    if (alive.current) { apply(null); setError(''); restore(); }
  };
  return { root, mode, pending, error, enter, maximize, exit };
}
