import {
  useEffect,
  useId,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import type { TerminalSession } from '@devlab/contracts';
import type { CanvasWorkspaceState, UIPluginProps } from '@devlab/ui-contracts';

type Selection = { nodeId: string; sessionId?: string };
type Tab = Selection & {
  label: string;
  status: 'running' | 'exited' | 'stopped' | 'unavailable';
  session?: TerminalSession;
};
const STORAGE = 'devlab:terminal-dock:selection';
const EMPTY: CanvasWorkspaceState = {
  projectId: 'default',
  graph: { name: '', nodes: [], edges: [] },
  revision: 0,
  selectedNodeId: null,
  dirty: false,
  loading: false,
  saving: false,
  error: '',
  canUndo: false,
  canRedo: false,
};
const emptySnapshot = () => EMPTY;
const emptySubscribe = () => () => {};
const keyOf = (value: Selection) =>
  value.sessionId ? `session:${value.sessionId}` : `node:${value.nodeId}`;
function savedSelections(): Record<string, Selection> {
  try {
    const value: unknown = JSON.parse(sessionStorage.getItem(STORAGE) ?? '{}');
    if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
    return Object.fromEntries(
      Object.entries(value).filter((entry): entry is [string, Selection] => {
        const v: unknown = entry[1];
        return (
          !!v &&
          typeof v === 'object' &&
          'nodeId' in v &&
          typeof v.nodeId === 'string' &&
          (!('sessionId' in v) || typeof v.sessionId === 'string')
        );
      }),
    );
  } catch {
    return {};
  }
}

/** UI owns tab selection and observers; TerminalService remains the sole PTY owner. */
export function useTerminalDock({
  client,
  workspace,
  renderTerminal,
  active,
  show,
}: Pick<UIPluginProps, 'client' | 'workspace' | 'renderTerminal'> & {
  active: boolean;
  show?: () => void;
}) {
  const state = useSyncExternalStore(
    workspace?.subscribe ?? emptySubscribe,
    workspace?.snapshot ?? emptySnapshot,
  );
  const projectId = state.projectId,
    api = client.terminals;
  const [listed, setListed] = useState<{
    projectId: string;
    sessions: TerminalSession[];
    loading: boolean;
    error: string;
  }>({ projectId, sessions: [], loading: true, error: '' });
  const [selections, setSelections] =
    useState<Record<string, Selection>>(savedSelections);
  const revision = useRef(0);
  const context = useRef({ projectId, active, key: '' });
  const tabRefs = useRef(new Map<string, HTMLButtonElement>());
  const instance = useId().replace(/:/g, '');
  const panelId = `terminal-dock-panel-${instance}`;
  const buttonId = (tab: Selection) =>
    `terminal-dock-tab-${instance}-${encodeURIComponent(keyOf(tab))}`;
  const currentList =
    listed.projectId === projectId
      ? listed
      : { projectId, sessions: [], loading: true, error: '' };
  const nodes = state.graph.nodes.filter((n) => n.type === 'terminal');
  const label = (nodeId: string) =>
    String(nodes.find((n) => n.id === nodeId)?.data.label ?? nodeId);
  const tabs: Tab[] = currentList.sessions.map((s) => ({
    nodeId: s.nodeId,
    sessionId: s.id,
    session: s,
    status: s.status,
    label: `${label(s.nodeId)} · ${s.id.slice(0, 8)}`,
  }));
  for (const node of nodes)
    if (!currentList.sessions.some((s) => s.nodeId === node.id))
      tabs.push({
        nodeId: node.id,
        label: String(node.data.label ?? node.id),
        status: 'stopped',
      });
  const selected = selections[projectId];
  if (
    selected?.sessionId &&
    !tabs.some((t) => t.sessionId === selected.sessionId)
  )
    tabs.push({
      ...selected,
      label: `${label(selected.nodeId)} · ${selected.sessionId.slice(0, 8)}`,
      status: 'unavailable',
    });
  const preferred =
    tabs.find(
      (t) => t.nodeId === state.selectedNodeId && t.status === 'running',
    ) ?? tabs.find((t) => t.nodeId === state.selectedNodeId);
  const current =
    (selected && tabs.find((t) => keyOf(t) === keyOf(selected))) ??
    preferred ??
    tabs.find((t) => t.status === 'running') ??
    tabs[0];
  context.current = { projectId, active, key: current ? keyOf(current) : '' };

  useEffect(() => {
    try {
      sessionStorage.setItem(STORAGE, JSON.stringify(selections));
    } catch {
      /* Tab selection remains usable without browser storage. */
    }
  }, [selections]);
  useEffect(() => {
    if (!active || !api) return;
    let alive = true,
      first = true;
    let timer: ReturnType<typeof setTimeout>;
    const initialRevision = revision.current;
    const preferredNode = workspace?.snapshot().selectedNodeId;
    setListed((value) =>
      value.projectId === projectId
        ? { ...value, loading: true, error: '' }
        : { projectId, sessions: [], loading: true, error: '' },
    );
    const load = async () => {
      const request = revision.current;
      try {
        const sessions = (await api.list(projectId)).filter(
          (s) => s.projectId === projectId,
        );
        if (
          !alive ||
          context.current.projectId !== projectId ||
          !context.current.active ||
          request !== revision.current
        )
          return;
        setListed({ projectId, sessions, loading: false, error: '' });
        const preferredSession =
          sessions.find(
            (s) => s.nodeId === preferredNode && s.status === 'running',
          ) ?? sessions.filter((s) => s.nodeId === preferredNode).at(-1);
        const preferredGraphNode = workspace
          ?.snapshot()
          .graph.nodes.find(
            (n) => n.type === 'terminal' && n.id === preferredNode,
          );
        const preferCanvas =
          first && request === initialRevision && preferredGraphNode;
        setSelections((values) => {
          if (request !== revision.current) return values;
          let chosen = values[projectId];
          if (preferCanvas && chosen?.nodeId !== preferredGraphNode.id)
            chosen = {
              nodeId: preferredGraphNode.id,
              ...(preferredSession ? { sessionId: preferredSession.id } : {}),
            };
          // A stopped node can discover a shell; an exact history ID remains exact.
          if (chosen && !chosen.sessionId) {
            const chosenNodeId = chosen.nodeId;
            const discovered =
              sessions.find(
                (s) => s.nodeId === chosenNodeId && s.status === 'running',
              ) ?? sessions.filter((s) => s.nodeId === chosenNodeId).at(-1);
            if (discovered)
              chosen = { nodeId: discovered.nodeId, sessionId: discovered.id };
          }
          if (!chosen) {
            const fallback =
              sessions.find((s) => s.status === 'running') ?? sessions[0];
            if (fallback)
              chosen = { nodeId: fallback.nodeId, sessionId: fallback.id };
          }
          return chosen &&
            (!values[projectId] || keyOf(chosen) !== keyOf(values[projectId]))
            ? { ...values, [projectId]: chosen }
            : values;
        });
        first = false;
      } catch (error) {
        if (
          alive &&
          context.current.projectId === projectId &&
          request === revision.current
        )
          setListed((value) => ({
            projectId,
            sessions: value.projectId === projectId ? value.sessions : [],
            loading: false,
            error: error instanceof Error ? error.message : String(error),
          }));
      } finally {
        if (alive) timer = setTimeout(() => void load(), 1000);
      }
    };
    void load();
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [active, api, projectId, workspace]);
  const choose = (tab: Selection) => {
    show?.();
    ++revision.current;
    setSelections((values) => ({
      ...values,
      [projectId]: {
        nodeId: tab.nodeId,
        ...(tab.sessionId ? { sessionId: tab.sessionId } : {}),
      },
    }));
  };
  const selectedKey = current ? keyOf(current) : '';
  const source = 'plugins/ui-shell/src/terminals.tsx';
  const tabButtons = tabs.map((tab, index) => (
    <button
      key={keyOf(tab)}
      ref={(element) => {
        if (element) tabRefs.current.set(keyOf(tab), element);
        else tabRefs.current.delete(keyOf(tab));
      }}
      id={buttonId(tab)}
      role="tab"
      aria-selected={keyOf(tab) === selectedKey}
      aria-controls={panelId}
      tabIndex={keyOf(tab) === selectedKey ? 0 : -1}
      className={`terminal-tab${keyOf(tab) === selectedKey ? ' terminal-tab--active' : ''}`}
      title={`${tab.label} · ${tab.status}${tab.session ? ` · ${tab.session.cwd}` : ''}`}
      data-terminal-session-id={tab.sessionId ?? ''}
      data-terminal-node-id={tab.nodeId}
      data-devlab-id={`terminal-dock.${projectId}.tab.${keyOf(tab)}`}
      data-devlab-source={source}
      onClick={() => choose(tab)}
      onKeyDown={(event) => {
        const nextIndex =
          event.key === 'ArrowRight'
            ? (index + 1) % tabs.length
            : event.key === 'ArrowLeft'
              ? (index + tabs.length - 1) % tabs.length
              : event.key === 'Home'
                ? 0
                : event.key === 'End'
                  ? tabs.length - 1
                  : null;
        if (nextIndex === null) return;
        event.preventDefault();
        const next = tabs[nextIndex];
        if (next) {
          choose(next);
          tabRefs.current.get(keyOf(next))?.focus();
        }
      }}
    >
      <span
        aria-hidden="true"
        className={`terminal-tab-status-dot terminal-tab-status-dot--${tab.status === 'running' ? 'running' : 'stopped'}`}
      />
      {tab.label}
      <span className="terminal-tab-state">{tab.status}</span>
    </button>
  ));
  const node = nodes.find((n) => n.id === current?.nodeId);
  const cwd =
    typeof node?.data.cwd === 'string' &&
    !/^(?:[\\/]|[A-Za-z]:)/.test(node.data.cwd)
      ? node.data.cwd
      : '.';
  const viewKey = selectedKey;
  const dockedTerminal =
    active && current?.status === 'running' && current.sessionId
      ? { nodeId: current.nodeId, sessionId: current.sessionId }
      : undefined;
  const panel = (
    <div
      id={panelId}
      role="tabpanel"
      aria-labelledby={current ? buttonId(current) : undefined}
      aria-label={current ? undefined : 'Terminal sessions'}
      className="terminal-dock"
      data-testid="terminal-sessions"
      data-devlab-id={`terminal-dock.${projectId}.panel`}
      data-devlab-source={source}
    >
      {!api || !renderTerminal ? (
        <p className="terminal-dock-empty" role="status">
          Terminal renderer is unavailable.
        </p>
      ) : current ? (
        renderTerminal({
          projectId,
          nodeId: current.nodeId,
          sessionId: current.sessionId,
          cwd,
          shell: node
            ? node.data.shell === 'sh'
              ? 'sh'
              : 'bash'
            : (current.session?.shell ?? 'bash'),
          instanceId: `dock-${projectId}-${current.sessionId ?? current.nodeId}`,
          resizeOwner: !!dockedTerminal,
          onStarted: (session) => {
            if (
              !context.current.active ||
              context.current.projectId !== projectId ||
              context.current.key !== viewKey ||
              session.projectId !== projectId ||
              session.nodeId !== current.nodeId
            )
              return;
            ++revision.current;
            setListed((value) => ({
              projectId,
              loading: false,
              error: '',
              sessions: [
                ...(value.projectId === projectId
                  ? value.sessions.filter((s) => s.id !== session.id)
                  : []),
                session,
              ],
            }));
            setSelections((values) => ({
              ...values,
              [projectId]: { nodeId: session.nodeId, sessionId: session.id },
            }));
          },
        })
      ) : (
        <p className="terminal-dock-empty" role="status">
          {currentList.loading
            ? 'Checking terminal sessions…'
            : 'Add a terminal canvas node to start a shell.'}
        </p>
      )}
      {currentList.error && (
        <p className="terminal-dock-error" role="alert">
          {currentList.error}
        </p>
      )}
    </div>
  );
  return {
    tabs: tabButtons,
    panel,
    dockedTerminal,
  };
}
