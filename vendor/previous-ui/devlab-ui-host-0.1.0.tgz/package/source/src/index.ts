import type { UIPlugin } from '@devlab/ui-contracts';
const slots = new Set(['panel', 'workspace', 'canvas', 'terminal', 'browser', 'hood', 'project', 'preview', 'planning']);
/** Stable contribution IDs and registration generations leave domain ownership external. */
export class UIRegistry {
  #plugins = new Map<string, { plugin: UIPlugin; token: symbol }>();
  #listeners = new Set<() => void>();
  #snapshot: readonly UIPlugin[] = [];
  #catalog: readonly UIPlugin[] = [];
  #disabled = new Set<string>();
  #revision = 0;
  subscribe = (listener: () => void) => {
    this.#listeners.add(listener);
    return () => { this.#listeners.delete(listener); };
  };
  snapshot = () => this.#snapshot;
  catalog = () => this.#catalog;
  revision = () => this.#revision;
  register(plugin: UIPlugin): () => void {
    if (this.#plugins.has(plugin.id)) throw new Error(`Duplicate UI plugin '${plugin.id}'`);
    this.#validate(plugin);
    const token = Symbol(plugin.id);
    this.#plugins.set(plugin.id, { plugin, token });
    this.#notify();
    return () => {
      if (this.#plugins.get(plugin.id)?.token === token) {
        this.#plugins.delete(plugin.id);
        this.#notify();
      }
    };
  }
  replace(plugin: UIPlugin): void {
    this.#validate(plugin);
    if (this.#catalog.some(current => current.id === plugin.id)) {
      this.reconcile(this.#catalog.map(current => current.id === plugin.id ? plugin : current));
      return;
    }
    if (!this.#plugins.has(plugin.id)) return;
    this.#plugins.set(plugin.id, { plugin, token: Symbol(plugin.id) });
    this.#notify();
  }
  /** Validate the complete candidate before one atomic full-catalog publication. */
  reconcile(candidate: readonly UIPlugin[]): void {
    if (!Array.isArray(candidate) || candidate.length > 256) throw new Error('Invalid UI catalog');
    const ids = new Set<string>(), occupied = new Set<string>();
    for (const plugin of candidate) {
      this.#validate(plugin);
      if (ids.has(plugin.id)) throw new Error(`Duplicate UI plugin '${plugin.id}'`);
      ids.add(plugin.id);
      if (plugin.slot && plugin.slot !== 'panel') {
        if (occupied.has(plugin.slot)) throw new Error(`Duplicate UI slot '${plugin.slot}'`);
        occupied.add(plugin.slot);
      }
    }
    this.#catalog = [...candidate];
    this.#plugins = new Map(candidate.filter(plugin => !this.#disabled.has(plugin.id))
      .map(plugin => [plugin.id, { plugin, token: Symbol(plugin.id) }]));
    this.#notify();
  }
  toggle(id: string): void {
    const plugin = this.#catalog.find(plugin => plugin.id === id);
    if (!plugin) throw new Error(`Unknown UI contribution '${id}'`);
    if (this.#disabled.has(id)) {
      this.#disabled.delete(id);
      this.#plugins.set(id, { plugin, token: Symbol(id) });
    } else {
      this.#disabled.add(id);
      this.#plugins.delete(id);
    }
    this.#notify();
  }
  #validate(plugin: UIPlugin) {
    if (!plugin || plugin.apiVersion !== 1 || typeof plugin.id !== 'string' ||
        !/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(plugin.id) ||
        typeof plugin.title !== 'string' || !plugin.title.trim() || plugin.title.length > 160 ||
        (plugin.slot !== undefined && !slots.has(plugin.slot)) || typeof plugin.Component !== 'function')
      throw new Error('Incompatible UI contribution');
  }
  #notify() {
    this.#snapshot = [...this.#plugins.values()].map(entry => entry.plugin);
    this.#revision++;
    for (const listener of this.#listeners) listener();
  }
}
