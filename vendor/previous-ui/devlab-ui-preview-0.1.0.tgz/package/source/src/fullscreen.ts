export interface PreviewFullscreenState {
  paneId: string | null;
  mode: 'native' | 'maximized' | null;
  error: string;
}
export interface FullscreenElement {
  isConnected?: boolean;
  requestFullscreen?: () => Promise<void>;
}
export interface FullscreenDocument {
  fullscreenElement: FullscreenElement | null;
  exitFullscreen?: () => Promise<void>;
  addEventListener(type: 'fullscreenchange', listener: () => void): void;
  removeEventListener(type: 'fullscreenchange', listener: () => void): void;
}
export interface PreviewFullscreen {
  snapshot(): PreviewFullscreenState;
  subscribe(listener: () => void): () => void;
  enter(
    paneId: string,
    opener?: { isConnected: boolean; focus(): void },
  ): Promise<boolean>;
  maximize(
    paneId: string,
    opener?: { isConnected: boolean; focus(): void },
  ): void;
  exit(): Promise<void>;
  dispose(): void;
}
/** Uses the existing pane element. No portal/reparent/duplicate iframe is created. */
export function createPreviewFullscreen(options: {
  document: FullscreenDocument;
  getElement: (paneId: string) => FullscreenElement | null;
  onChange?: (state: PreviewFullscreenState) => void;
}): PreviewFullscreen {
  let state: PreviewFullscreenState = Object.freeze({
      paneId: null,
      mode: null,
      error: '',
    }),
    closed = false,
    epoch = 0,
    requesting = false;
  let opener: { isConnected: boolean; focus(): void } | undefined;
  const listeners = new Set<() => void>();
  const emit = (next: PreviewFullscreenState) => {
    if (closed) return;
    state = Object.freeze(next);
    options.onChange?.(state);
    for (const listener of listeners) listener();
  };
  const restore = () => {
    if (opener?.isConnected) opener.focus();
    opener = undefined;
  };
  function changed() {
    if (
      state.mode === 'native' &&
      options.document.fullscreenElement !== options.getElement(state.paneId!)
    ) {
      epoch++;
      emit({ paneId: null, mode: null, error: '' });
      restore();
    }
  }
  options.document.addEventListener('fullscreenchange', changed);
  const api: PreviewFullscreen = {
    snapshot: () => state,
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    async enter(paneId, trigger) {
      if (closed) return false;
      if (requesting) {
        emit({ ...state, error: 'A fullscreen request is still pending.' });
        return false;
      }
      if (state.paneId && state.paneId !== paneId) {
        emit({ ...state, error: 'Exit the current fullscreen pane first.' });
        return false;
      }
      const element = options.getElement(paneId);
      if (!element?.requestFullscreen) {
        emit({
          paneId: null,
          mode: null,
          error:
            'Fullscreen is unavailable. Choose Maximize in app to enlarge this pane.',
        });
        return false;
      }
      if (
        options.document.fullscreenElement &&
        options.document.fullscreenElement !== element
      ) {
        emit({
          paneId: null,
          mode: null,
          error:
            'Another element is fullscreen. Exit it before enlarging this preview.',
        });
        return false;
      }
      const token = ++epoch;
      opener = trigger;
      requesting = true;
      try {
        await element.requestFullscreen();
        if (closed || token !== epoch) {
          if (options.document.fullscreenElement === element)
            await options.document.exitFullscreen?.();
          return false;
        }
        if (options.document.fullscreenElement !== element)
          throw new Error('The browser did not enter fullscreen.');
        emit({ paneId, mode: 'native', error: '' });
        return true;
      } catch {
        if (!closed && token === epoch)
          emit({
            paneId: null,
            mode: null,
            error:
              'Fullscreen was denied. Choose Maximize in app to enlarge this pane.',
          });
        opener = undefined;
        return false;
      } finally {
        requesting = false;
      }
    },
    maximize(paneId, trigger) {
      if (closed) return;
      if (state.mode) {
        emit({ ...state, error: 'Exit the current enlarged pane first.' });
        return;
      }
      if (!options.getElement(paneId)) {
        emit({
          paneId: null,
          mode: null,
          error: 'The preview pane is no longer available.',
        });
        return;
      }
      epoch++;
      opener = trigger;
      emit({ paneId, mode: 'maximized', error: '' });
    },
    async exit() {
      if (closed) return;
      epoch++;
      const element = state.paneId ? options.getElement(state.paneId) : null;
      const owned =
        state.mode === 'native' &&
        element &&
        options.document.fullscreenElement === element;
      if (owned) {
        try {
          await options.document.exitFullscreen?.();
        } catch {
          emit({
            ...state,
            error: 'Fullscreen could not exit. Use the browser Escape control.',
          });
          return;
        }
        if (options.document.fullscreenElement === element) {
          emit({
            ...state,
            error: 'Use the browser Escape control to exit fullscreen.',
          });
          return;
        }
      }
      emit({ paneId: null, mode: null, error: '' });
      restore();
    },
    dispose() {
      if (closed) return;
      const owned =
        state.mode === 'native' &&
        options.document.fullscreenElement ===
          options.getElement(state.paneId!);
      epoch++;
      options.document.removeEventListener('fullscreenchange', changed);
      if (owned) void options.document.exitFullscreen?.().catch(() => {});
      closed = true;
      listeners.clear();
    },
  };
  return api;
}
