import type { UIPlugin } from '@devlab/ui-contracts';
import { DiagnosticsPanel } from './view.tsx';
export const diagnosticsPanel: UIPlugin = {
  id: 'ui-diagnostics',
  apiVersion: 1,
  title: 'Plugin health',
  Component: DiagnosticsPanel,
};
