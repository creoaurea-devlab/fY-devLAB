import { useEffect, useState } from 'react';
import type { PluginHealth } from '@devlab/contracts';
import type { UIPluginProps } from '@devlab/ui-contracts';
export function DiagnosticsPanel({ client }: UIPluginProps) {
  const [plugins, setPlugins] = useState<PluginHealth[]>([]),
    [phase, setPhase] = useState('connecting'),
    [error, setError] = useState(''),
    [uppercase, setUppercase] = useState(false);
  useEffect(() => {
    let live = true;
    const refresh = async () => {
      try {
        const h = await client.health();
        if (live) {
          setPlugins(h.plugins);
          setPhase(h.phase);
          setUppercase(
            h.plugins.find((p) => p.id === 'model-fake')?.version === '1.0.1',
          );
        }
      } catch (e) {
        if (live) setError(String(e));
      }
    };
    void refresh();
    const timer = setInterval(() => void refresh(), 1000);
    return () => {
      live = false;
      clearInterval(timer);
    };
  }, [client]);
  const swap = async () => {
    setError('');
    try {
      await client.replaceModel(!uppercase);
      setUppercase(!uppercase);
      const h = await client.health();
      setPlugins(h.plugins);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  };
  return (
    <section className="panel diagnostics">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">PLUGIN LIFECYCLES</p>
          <h2>Small core. Clear ownership.</h2>
        </div>
        <span className="tag">{phase}</span>
      </div>
      <div className="plugin-list">
        {plugins.map((plugin) => (
          <div className="plugin-row" key={plugin.id}>
            <span className={`dot ${plugin.state}`} />
            <div>
              <strong>{plugin.id}</strong>
              <span>
                {plugin.state} · generation {plugin.generation}
              </span>
            </div>
            <span className="lease">{plugin.leases} active</span>
          </div>
        ))}
      </div>
      <div className="experiment">
        <p className="eyebrow">LIVE REPLACEMENT</p>
        <h3>Change the model, keep the host.</h3>
        <p className="muted">
          Switch the offline model to {uppercase ? 'original' : 'uppercase'}{' '}
          text. Active work must finish first.
        </p>
        <button onClick={() => void swap()}>
          Use {uppercase ? 'original' : 'uppercase'} model{' '}
          <span aria-hidden>↔</span>
        </button>
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
      </div>
    </section>
  );
}
