import { graphlib, layout } from '@dagrejs/dagre';
import type { HoodProjection } from './graph.ts';
export const NODE_WIDTH = 248,
  NODE_HEIGHT = 100;
/** Flat visible projection avoids Dagre's compound-subgraph/external-edge caveat. */
export function layoutRegistry(
  projection: Pick<HoodProjection, 'items' | 'wires'>,
  direction: 'LR' | 'TB',
) {
  const graph = new graphlib.Graph();
  graph.setGraph({
    rankdir: direction,
    nodesep: 28,
    ranksep: 82,
    marginx: 32,
    marginy: 32,
  });
  graph.setDefaultEdgeLabel(() => ({}));
  for (const item of projection.items)
    graph.setNode(item.id, { width: NODE_WIDTH, height: NODE_HEIGHT });
  // Layout needs adjacency only. Parallel edges can break Dagre's rectangle
  // intersection pass; renderer/provenance still retain every projected wire.
  for (const wire of projection.wires)
    graph.setEdge(wire.source, wire.target, {});
  layout(graph);
  return new Map(
    projection.items.map((item) => {
      const position = graph.node(item.id);
      return [
        item.id,
        { x: position.x - NODE_WIDTH / 2, y: position.y - NODE_HEIGHT / 2 },
      ];
    }),
  );
}
