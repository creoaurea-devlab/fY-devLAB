import {
  createContext,
  useId,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
  type FocusEvent,
  type ReactNode,
} from 'react';
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  BackgroundVariant,
  MiniMap,
  Handle,
  Position,
  MarkerType,
  applyNodeChanges,
  useReactFlow,
  type Node,
  type Edge,
  type NodeProps,
} from '@xyflow/react';
import {
  ArrowLeft,
  ChevronRight,
  ChevronDown,
  Search,
  RefreshCw,
  Maximize,
  Focus,
  PanelLeft,
  PanelRight,
  Download,
  Network,
  FileCode2,
  Boxes,
  Wrench,
  Folder,
  Braces,
  X,
} from 'lucide-react';
import type { RegistryClient } from './contracts.ts';

function revealDrawerFocus(event: FocusEvent<HTMLElement>) {
  const drawer = event.currentTarget,
    target = event.target as HTMLElement;
  if (target.closest('.hood-drawer-close')) return;
  // Native focus scrolling does not account for the sticky close button.
  queueMicrotask(() => {
    if (
      drawer.hidden ||
      !drawer.isConnected ||
      drawer.ownerDocument.activeElement !== target
    )
      return;
    const close = drawer.querySelector<HTMLElement>('.hood-drawer-close');
    if (!close) return;
    const bounds = drawer.getBoundingClientRect(),
      pinned = close.getBoundingClientRect();
    const rect = target.getBoundingClientRect(),
      style = getComputedStyle(drawer);
    const gap = parseFloat(style.columnGap) || 0;
    const left =
      style.direction === 'rtl'
        ? pinned.right + gap
        : bounds.left + parseFloat(style.paddingLeft);
    const right =
      style.direction === 'rtl'
        ? bounds.right - parseFloat(style.paddingRight)
        : pinned.left - gap;
    const delta =
      rect.right > right
        ? rect.right - right
        : rect.left < left
          ? rect.left - left
          : 0;
    if (delta) drawer.scrollBy({ left: delta, behavior: 'instant' });
  });
}

export interface HoodProps {
  client?: RegistryClient;
  onClose?: () => void;
  uiContributions?: { id: string; title: string; slot: string }[];
  theme?: 'inherit' | 'dark' | 'light';
  presentation?: 'overlay' | 'embedded';
  initialProjectId?: string;
  initialDepth?: number;
  hideFiles?: boolean;
  onSourceSelect?: (path: string) => void;
  /** Host-owned commands stay outside the portable implementation. */
  toolbarActions?: ReactNode;
  title?: string;
}
import type {
  RegistrySnapshot,
  RegistryItem,
  RegistryEdge,
  RegistrySource,
  RegistryProject,
} from './contracts.ts';
import {
  projectRegistry,
  ancestors,
  expansionAtDepth,
  wireColors,
  type RegistryGraph,
  type ProjectedWire,
} from './graph.ts';
import { layoutRegistry, NODE_WIDTH, NODE_HEIGHT } from './layout.ts';
import '@xyflow/react/dist/style.css';
import './hood.css';

type Mode = 'code' | 'wiring';
const NodeContext = createContext<{
  toggle: (id: string) => void;
  direction: 'LR' | 'TB';
}>({ toggle: () => {}, direction: 'LR' });
function ItemIcon({
  kind,
  size = 14,
}: {
  kind: RegistryItem['kind'];
  size?: number;
}) {
  const Icon =
    kind === 'file'
      ? FileCode2
      : kind === 'symbol'
        ? Braces
        : ['plugin', 'service', 'channel', 'client', 'worker', 'ui'].includes(
              kind,
            )
          ? Network
          : kind === 'module'
            ? Boxes
            : Folder;
  return <Icon size={size} />;
}
function RegistryNode({ data, selected }: NodeProps) {
  const { toggle, direction } = useContext(NodeContext),
    item = data.item as RegistryItem;
  return (
    <div
      className={`hood-node kind-${item.kind}${selected ? ' selected' : ''}`}
      data-testid="hood-graph-node"
    >
      <Handle
        type="target"
        position={direction === 'LR' ? Position.Left : Position.Top}
        isConnectable={false}
      />
      <div className="hood-node-kind">
        <ItemIcon kind={item.kind} size={11} />
        <span>{item.kind}</span>
        {Boolean(data.childCount) && (
          <button
            className="nodrag"
            aria-label={`${data.open ? 'Collapse' : 'Expand'} ${item.label}`}
            aria-expanded={Boolean(data.open)}
            onClick={() => toggle(item.id)}
          >
            {data.open ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          </button>
        )}
      </div>
      <strong className="hood-node-title" title={item.path ?? item.label}>
        {item.label}
      </strong>
      <p title={item.detail}>{item.detail}</p>
      <small>
        {Number(data.childCount) > 0
          ? `${data.childCount} children`
          : item.path
            ? `L${item.line ?? 1}`
            : 'contract'}
        {Number(data.internal) > 0 ? ` · ${data.internal} internal wires` : ''}
      </small>
      <Handle
        type="source"
        position={direction === 'LR' ? Position.Right : Position.Bottom}
        isConnectable={false}
      />
    </div>
  );
}
const nodeTypes = { registry: RegistryNode };
const codeLayers: RegistryEdge['kind'][] = ['import', 'reexport', 'contains'];
const wiringLayers: RegistryEdge['kind'][] = [
  'provides',
  'requires',
  'live',
  'ipc',
  'ui',
  'contains',
];
function filteredWiring(graph: RegistryGraph, filter: string): RegistryGraph {
  if (filter === 'all') return graph;
  const kinds = new Set(
    filter === 'services'
      ? ['plugin', 'service']
      : filter === 'ipc'
        ? ['plugin', 'service', 'channel', 'client', 'worker']
        : ['ui', 'client'],
  );
  const children = graph.items.filter((i) => kinds.has(i.kind));
  const groups = new Set(children.map((i) => i.parentId));
  const items = graph.items.filter(
      (i) => kinds.has(i.kind) || groups.has(i.id),
    ),
    ids = new Set(items.map((i) => i.id));
  return {
    items,
    edges: graph.edges.filter(
      (e) =>
        ids.has(e.source) &&
        ids.has(e.target) &&
        (filter === 'services'
          ? ['provides', 'requires', 'live'].includes(e.kind)
          : filter === 'ipc'
            ? ['ipc', 'contains'].includes(e.kind)
            : e.kind === 'ui'),
    ),
  };
}
function download(snapshot: RegistrySnapshot) {
  const href = URL.createObjectURL(
    new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' }),
  );
  const a = document.createElement('a');
  a.href = href;
  a.download = `devlab-registry-${snapshot.catalog.snapshotId.slice(0, 10)}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(href), 1000);
}

export function HoodView(props: HoodProps) {
  return (
    <ReactFlowProvider>
      <HoodScene {...props} />
    </ReactFlowProvider>
  );
}
function HoodScene({
  client: api,
  onClose,
  uiContributions = [],
  theme = 'dark',
  presentation = 'overlay',
  initialProjectId = 'workspace',
  initialDepth = 1,
  hideFiles: hideFilesProp,
  onSourceSelect,
  toolbarActions,
  title = 'Pop the Hood',
}: HoodProps) {
  const [localHideFiles, setLocalHideFiles] = useState(false);
  type Drawer = 'navigation' | 'layout' | 'wires' | 'project';
  const [drawer, setDrawer] = useState<Drawer | null>(null);
  const drawerId = useId();
  const drawerTriggers = useRef<
    Partial<Record<Drawer, HTMLButtonElement | null>>
  >({});
  const [minimap, setMinimap] = useState(false);
  const drawerNames: Record<Drawer, string> = {
    navigation: 'Navigation',
    layout: 'Layout',
    wires: 'Wires',
    project: 'Project',
  };
  const toggleDrawer = (next: Drawer) =>
    setDrawer((current) => (current === next ? null : next));
  function closeDrawer() {
    if (drawer) {
      const trigger = drawerTriggers.current[drawer];
      setDrawer(null);
      requestAnimationFrame(() => trigger?.focus());
    }
  }

  const hideFiles = hideFilesProp ?? localHideFiles;
  const flow = useReactFlow();
  const backgroundId = useId();
  const [projectId, setProjectId] = useState(initialProjectId),
    [projects, setProjects] = useState<RegistryProject[]>([]),
    [connection, setConnection] = useState('Connecting');
  const snapshotRef = useRef<RegistrySnapshot | null>(null);
  const projectsVersion = useRef(0);
  const sourceClient = useMemo(
    () =>
      api
        ? { ...api, source: (path: string) => api.source(path, projectId) }
        : undefined,
    [api, projectId],
  );
  const project = projects.find((p) => p.id === projectId);
  const [snapshot, setSnapshot] = useState<RegistrySnapshot | null>(null),
    [loading, setLoading] = useState(true),
    [error, setError] = useState('');
  const [mode, setMode] = useState<Mode>('code'),
    [filter, setFilter] = useState('services'),
    [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState(new Set<string>()),
    [direction, setDirection] = useState<'LR' | 'TB'>('LR'),
    [external, setExternal] = useState(false),
    [neighbors, setNeighbors] = useState(false);
  const [codeEnabled, setCodeEnabled] = useState(new Set(codeLayers)),
    [wiringEnabled, setWiringEnabled] = useState<Set<RegistryEdge['kind']>>(
      new Set(wiringLayers.filter((k) => k !== 'contains')),
    );
  const [selected, setSelected] = useState<string | null>(null),
    [selectedWire, setSelectedWire] = useState<string | null>(null),
    [focusId, setFocusId] = useState<string | null>(null);
  const [explorer, setExplorer] = useState(false),
    [inspector, setInspector] = useState(false),
    [layoutTick, setLayoutTick] = useState(0),
    [nodes, setNodes] = useState<Node[]>([]);
  const [depth, setDepth] = useState(String(initialDepth));
  const viewPrefs = useRef({ mode, depth, filter });
  viewPrefs.current = { mode, depth, filter };
  const [sourceLine, setSourceLine] = useState<number | null>(null);
  const root = useRef<HTMLDivElement>(null),
    search = useRef<HTMLInputElement>(null),
    manual = useRef(new Map<string, { x: number; y: number }>()),
    requestVersion = useRef(0),
    mounted = useRef(true);
  const graph = useMemo<RegistryGraph>(
    () =>
      snapshot
        ? mode === 'code'
          ? snapshot.catalog.graph
          : filteredWiring(snapshot.wiring, filter)
        : { items: [], edges: [] },
    [snapshot, mode, filter],
  );
  const layers = mode === 'code' ? codeEnabled : wiringEnabled,
    focusSelection = neighbors ? selected : null;
  const projection = useMemo(
    () =>
      projectRegistry(graph, {
        expanded,
        query,
        external,
        layers,
        selected: focusSelection,
        neighbors,
        hideFiles,
      }),
    [
      graph,
      expanded,
      query,
      external,
      layers,
      focusSelection,
      neighbors,
      hideFiles,
    ],
  );
  const positions = useMemo(
    () => layoutRegistry(projection, direction),
    [projection, direction, layoutTick],
  );
  const selectedItem = graph.items.find((i) => i.id === selected);
  const chosenWire =
    projection.wires.find(
      (e) =>
        e.id === selectedWire || e.originals.some((o) => o.id === selectedWire),
    ) ??
    (graph.edges.find((e) => e.id === selectedWire)
      ? {
          ...graph.edges.find((e) => e.id === selectedWire)!,
          originals: [graph.edges.find((e) => e.id === selectedWire)!],
        }
      : undefined);
  const edges = useMemo<Edge[]>(
    () =>
      projection.wires.map((w) => ({
        id: w.id,
        source: w.source,
        target: w.target,
        label: w.originals.length > 1 ? String(w.originals.length) : w.kind,
        style: {
          stroke: wireColors[w.kind],
          strokeWidth: w.kind === 'contains' ? 1 : 1.5,
          strokeDasharray:
            w.typeOnly || w.kind === 'contains' ? '5 4' : undefined,
        },
        labelStyle: { fontSize: 9, fill: 'var(--hood-text)' },
        labelBgStyle: { fill: 'var(--hood-surface)', fillOpacity: 0.94 },
        markerEnd: { type: MarkerType.ArrowClosed, color: wireColors[w.kind] },
        selected: w.id === chosenWire?.id,
        interactionWidth: 24,
      })),
    [projection, chosenWire?.id],
  );
  async function load(silent = false) {
    const version = ++requestVersion.current;
    if (!silent) setLoading(true);
    setError('');
    try {
      if (!api) throw new Error('Registry adapter is not enabled');
      const value = await api.snapshot(projectId);
      if (!mounted.current || version !== requestVersion.current) return;
      const previous = snapshotRef.current;
      snapshotRef.current = value;
      setSnapshot(value);
      const prefs = viewPrefs.current;
      const items =
        prefs.mode === 'code'
          ? value.catalog.graph.items
          : filteredWiring(value.wiring, prefs.filter).items;
      if (!previous)
        setExpanded(expansionAtDepth(items, Number(prefs.depth) || 1));
      else if (prefs.depth !== 'custom') {
        const beforeIds = new Set(
          (prefs.mode === 'code'
            ? previous.catalog.graph.items
            : previous.wiring.items
          ).map((i) => i.id),
        );
        const added = [
          ...expansionAtDepth(items, Number(prefs.depth) || 1),
        ].filter((id) => !beforeIds.has(id));
        if (added.length)
          setExpanded((current) => new Set([...current, ...added]));
      }
      setSelected((current) => {
        const all = [...value.catalog.graph.items, ...value.wiring.items];
        if (!current || all.some((i) => i.id === current)) return current;
        const before = [
          ...(previous?.catalog.graph.items ?? []),
          ...(previous?.wiring.items ?? []),
        ].find((i) => i.id === current);
        return (
          all.find(
            (i) =>
              before &&
              i.path === before.path &&
              i.label === before.label &&
              i.kind === before.kind,
          )?.id ?? null
        );
      });
    } catch (e) {
      if (mounted.current && version === requestVersion.current)
        setError(String(e));
    } finally {
      if (mounted.current && version === requestVersion.current)
        setLoading(false);
    }
  }
  async function loadProjects() {
    const version = ++projectsVersion.current;
    try {
      const list = (await api?.projects?.()) ?? [
        { id: 'workspace', label: 'Workspace' },
      ];
      if (mounted.current && version === projectsVersion.current)
        setProjects(list);
    } catch {
      /* The snapshot remains useful if catalog refresh fails. */
    }
  }
  useEffect(() => {
    mounted.current = true;
    const previous = document.activeElement as HTMLElement | null;
    root.current?.focus({ preventScroll: true });
    snapshotRef.current = null;
    setSnapshot(null);
    setSelected(null);
    setSelectedWire(null);
    setQuery('');
    manual.current.clear();
    setConnection(api?.listen ? 'Connecting' : 'Snapshot');
    void load();
    void loadProjects();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const unsubscribe = api?.listen?.(
      projectId,
      (event) => {
        if (!mounted.current) return;
        if (event.kind === 'projects') {
          void loadProjects();
          return;
        }
        setConnection('Live');
        if (event.revision === snapshotRef.current?.observation?.revision)
          return;
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => void load(true), 40);
      },
      () => {
        if (mounted.current) setConnection('Reconnecting');
      },
    );
    return () => {
      mounted.current = false;
      requestVersion.current++;
      projectsVersion.current++;
      if (timer) clearTimeout(timer);
      unsubscribe?.();
      previous?.focus({ preventScroll: true });
    };
  }, [api, projectId]);
  useEffect(() => {
    const media = matchMedia('(max-width:760px)');
    const adapt = () => {
      if (media.matches) {
        setExplorer(false);
        setInspector(false);
      }
    };
    adapt();
    media.addEventListener('change', adapt);
    return () => media.removeEventListener('change', adapt);
  }, []);
  useEffect(() => {
    setNodes(
      projection.items.map((item) => ({
        id: item.id,
        type: 'registry',
        position:
          manual.current.get(mode + ':' + item.id) ?? positions.get(item.id)!,
        selected: item.id === selected,
        style: { width: NODE_WIDTH, height: NODE_HEIGHT },
        data: {
          item,
          childCount: projection.children.get(item.id)?.length ?? 0,
          open: expanded.has(item.id) || Boolean(query),
          internal: projection.internal.get(item.id) ?? 0,
        },
      })),
    );
  }, [positions, mode]);
  useEffect(() => {
    setNodes((current) =>
      current.map((n) => ({ ...n, selected: n.id === selected })),
    );
  }, [selected]);
  useEffect(() => {
    const timer = setTimeout(
      () => void flow.fitView({ padding: 0.12, maxZoom: 1, duration: 150 }),
      150,
    );
    return () => clearTimeout(timer);
  }, [mode, filter, Boolean(snapshot)]);
  useEffect(() => {
    if (!focusId) return;
    const id = projection.representative.get(focusId) ?? focusId;
    if (!positions.has(id)) return;
    const timer = setTimeout(() => {
      void flow.fitView({
        nodes: [{ id }],
        padding: 0.6,
        minZoom: 0.7,
        maxZoom: 1.4,
        duration: 200,
      });
      setFocusId(null);
    }, 80);
    return () => clearTimeout(timer);
  }, [focusId, positions]);
  function toggle(id: string) {
    setDepth('custom');
    setExpanded((current) => {
      const next = new Set(current);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }
  function select(id: string, focus = false) {
    setSelected(id);
    setSelectedWire(null);
    setSourceLine(null);
    const item = graph.items.find((i) => i.id === id);
    if (
      onSourceSelect &&
      item?.path &&
      ['file', 'symbol'].includes(item.kind)
    ) {
      setInspector(false);
      onSourceSelect(item.path);
    } else setInspector(true);
    setExpanded(
      (current) => new Set([...current, ...ancestors(graph.items, id)]),
    );
    if (focus) setFocusId(id);
  }
  function selectSource(path: string, line?: number) {
    setMode('code');
    setFilter('all');
    setQuery('');
    setNeighbors(false);
    const id = 'file:' + path;
    setExpanded(
      (current) =>
        new Set([...current, ...ancestors(snapshot!.catalog.graph.items, id)]),
    );
    setSelected(id);
    setSelectedWire(null);
    setSourceLine(line ?? null);
    setFocusId(id);
    setInspector(true);
  }
  function switchMode(next: Mode) {
    setDepth('1');
    setMode(next);
    setQuery('');
    setSelected(null);
    setSelectedWire(null);
    setNeighbors(false);
    setExpanded(
      expansionAtDepth(
        next === 'code'
          ? (snapshot?.catalog.graph.items ?? [])
          : (snapshot?.wiring.items ?? []),
        1,
      ),
    );
  }
  function keydown(event: KeyboardEvent<HTMLDivElement>) {
    event.stopPropagation();
    const target = event.target as HTMLElement;
    if (event.key === 'Escape') {
      event.preventDefault();
      if (drawer) closeDrawer();
      else onClose?.();
      return;
    }
    if (
      event.key === '/' &&
      !['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName)
    ) {
      event.preventDefault();
      setDrawer('navigation');
      requestAnimationFrame(() => search.current?.focus());
    }
    if ((event.ctrlKey || event.metaKey) && event.key === 's')
      event.preventDefault();
    if (event.key === 'Tab' && presentation !== 'embedded') {
      const controls = [
        ...root.current!.querySelectorAll<HTMLElement>(
          'button,input,select,a[href],[tabindex="0"]',
        ),
      ].filter((e) => !e.hasAttribute('disabled') && e.offsetParent !== null);
      const first = controls[0],
        last = controls.at(-1);
      if (
        event.shiftKey &&
        (!controls.includes(document.activeElement as HTMLElement) ||
          document.activeElement === first)
      ) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    }
  }
  const descendantIds = new Set<string>();
  const pendingIds = selected ? [selected] : [];
  for (let id = pendingIds.pop(); id; id = pendingIds.pop()) {
    if (descendantIds.has(id)) continue;
    descendantIds.add(id);
    pendingIds.push(...(projection.children.get(id) ?? []).map((i) => i.id));
  }
  const incoming = graph.edges.filter(
      (e) => descendantIds.has(e.target) && !descendantIds.has(e.source),
    ),
    outgoing = graph.edges.filter(
      (e) => descendantIds.has(e.source) && !descendantIds.has(e.target),
    );
  const protocol = selectedItem
    ? snapshot?.catalog.channels.find((c) => c.id === selectedItem.id)
    : undefined;
  const runtime =
    selectedItem?.kind === 'plugin'
      ? snapshot?.plugins.find((p) => 'plugin:' + p.id === selectedItem.id)
      : undefined;
  const browserContribution =
    selectedItem?.kind === 'ui'
      ? uiContributions.find((p) => 'ui:' + p.id === selectedItem.id)
      : undefined;
  const sourcePath =
    selectedItem?.path &&
    snapshot?.catalog.graph.items.some(
      (i) => i.kind === 'file' && i.path === selectedItem.path,
    )
      ? selectedItem.path
      : undefined;
  return (
    <div
      className={`hood-root hood-theme-${theme} hood-${presentation}`}
      data-testid={
        presentation === 'embedded' ? 'build-hood-root' : 'hood-root'
      }
      data-project-id={projectId}
      data-snapshot-id={snapshot?.catalog.snapshotId}
      data-revision={snapshot?.observation?.revision}
      role={presentation === 'embedded' ? 'region' : 'dialog'}
      aria-modal={presentation === 'embedded' ? undefined : true}
      aria-label="Pop the Hood"
      tabIndex={-1}
      ref={root}
      onKeyDown={keydown}
    >
      <header
        className="hood-header hood-compact-toolbar"
        data-devlab-source="packages/pop-the-hood/src/react.tsx"
        data-devlab-id="hood.toolbar"
        aria-label="Architecture controls"
      >
        {onClose && (
          <button
            className="hood-back"
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.back"
            onClick={onClose}
          >
            <ArrowLeft size={15} /> Back to canvas
          </button>
        )}
        <div className="hood-brand">
          <Wrench size={17} />
          <strong>{title}</strong>
        </div>
        <div
          className="hood-drawer-triggers"
          role="group"
          aria-label="Architecture control groups"
        >
          {(['navigation', 'layout', 'wires', 'project'] as Drawer[]).map(
            (group) => (
              <button
                key={group}
                type="button"
                ref={(node) => {
                  drawerTriggers.current[group] = node;
                }}
                id={`${drawerId}-${group}-trigger`}
                aria-expanded={drawer === group}
                aria-controls={`${drawerId}-${group}-drawer`}
                data-devlab-source="packages/pop-the-hood/src/react.tsx"
                data-devlab-id={`hood.drawer.${group}`}
                onClick={() => toggleDrawer(group)}
              >
                {drawerNames[group]}
                <ChevronDown size={12} aria-hidden="true" />
              </button>
            ),
          )}
        </div>
        <span className="hood-header-spacer" />
        <span className="hood-live">
          <i />
          {snapshot?.observation?.mode === 'live'
            ? snapshot.observation.status === 'stale'
              ? 'Stale'
              : connection
            : `${snapshot?.plugins.filter((p) => p.state === 'active').length ?? 0} active`}
        </span>
      </header>
      <section
        className="hood-drawer"
        onFocusCapture={revealDrawerFocus}
        role="region"
        hidden={drawer !== 'navigation'}
        id={`${drawerId}-navigation-drawer`}
        aria-labelledby={`${drawerId}-navigation-trigger`}
        data-devlab-source="packages/pop-the-hood/src/react.tsx"
        data-devlab-id="hood.panel.navigation"
      >
        <div className="hood-drawer-content">
          <nav role="tablist" aria-label="Architecture views">
            <button
              role="tab"
              data-devlab-source="packages/pop-the-hood/src/react.tsx"
              data-devlab-id="hood.mode.code"
              aria-selected={mode === 'code'}
              onClick={() => switchMode('code')}
            >
              <FileCode2 size={14} />
              Code
            </button>
            <button
              role="tab"
              data-devlab-source="packages/pop-the-hood/src/react.tsx"
              data-devlab-id="hood.mode.wiring"
              aria-selected={mode === 'wiring'}
              onClick={() => switchMode('wiring')}
            >
              <Network size={14} />
              Registry / IPC
            </button>
          </nav>

          <button
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.explorer"
            aria-label="Toggle architecture explorer"
            aria-pressed={explorer}
            onClick={() => {
              setExplorer((v) => !v);
              if (window.innerWidth <= 760) setInspector(false);
            }}
          >
            <PanelLeft size={15} />
          </button>
          <label className="hood-search">
            <Search size={14} />
            <input
              ref={search}
              data-devlab-source="packages/pop-the-hood/src/react.tsx"
              data-devlab-id="hood.search"
              aria-label="Search architecture"
              placeholder={
                mode === 'code'
                  ? 'Find a module, file or symbol…'
                  : 'Find a service or transport…'
              }
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <kbd>/</kbd>
          </label>
          <select
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.depth"
            aria-label="Expansion depth"
            value={depth}
            onChange={(e) => {
              setDepth(e.target.value);
              setExpanded(
                expansionAtDepth(graph.items, Number(e.target.value)),
              );
            }}
          >
            <option value="custom" disabled>
              Custom depth
            </option>
            <option value="0">Groups</option>
            <option value="1">Modules</option>
            <option value="2">Directories</option>
            <option value="3">Files</option>
            <option value="99">Symbols / all</option>
          </select>
          <button
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.expand-all"
            onClick={() => {
              setDepth('99');
              setExpanded(new Set(graph.items.map((i) => i.id)));
            }}
          >
            Expand all
          </button>
          <button
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.collapse-all"
            onClick={() => {
              setDepth('0');
              setExpanded(new Set());
            }}
          >
            Collapse all
          </button>
        </div>
        <button
          className="hood-drawer-close"
          title="Close architecture drawer"
          type="button"
          aria-label="Close architecture drawer"
          data-devlab-source="packages/pop-the-hood/src/react.tsx"
          data-devlab-id="hood.drawer.close.navigation"
          onClick={closeDrawer}
        >
          <X size={14} aria-hidden="true" />
        </button>
      </section>
      <section
        className="hood-drawer"
        onFocusCapture={revealDrawerFocus}
        role="region"
        hidden={drawer !== 'layout'}
        id={`${drawerId}-layout-drawer`}
        aria-labelledby={`${drawerId}-layout-trigger`}
        data-devlab-source="packages/pop-the-hood/src/react.tsx"
        data-devlab-id="hood.panel.layout"
      >
        <div className="hood-drawer-content">
          <select
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.direction"
            aria-label="Layout direction"
            value={direction}
            onChange={(e) => {
              manual.current.clear();
              setDirection(e.target.value as 'LR' | 'TB');
            }}
          >
            <option value="LR">Left → right</option>
            <option value="TB">Top → bottom</option>
          </select>
          <button
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.layout"
            onClick={() => {
              manual.current.clear();
              setLayoutTick((v) => v + 1);
            }}
          >
            Dagre layout
          </button>
          <button
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.fit"
            aria-label="Fit architecture"
            title="Fit all visible"
            onClick={() => {
              setFocusId(null);
              requestAnimationFrame(
                () =>
                  void flow.fitView({
                    padding: 0.12,
                    maxZoom: 1.2,
                    duration: 200,
                  }),
              );
            }}
          >
            <Maximize size={15} />
          </button>
          <button
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.focus"
            aria-label="Focus selected architecture item"
            disabled={!selected}
            onClick={() => selected && setFocusId(selected)}
          >
            <Focus size={15} />
          </button>
          <label className="hood-check">
            <input
              type="checkbox"
              data-devlab-source="packages/pop-the-hood/src/react.tsx"
              data-devlab-id="hood.neighbors"
              checked={neighbors}
              disabled={!selected}
              onChange={(e) => setNeighbors(e.target.checked)}
            />
            Neighbors
          </label>
          <button
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.inspector"
            aria-label="Toggle architecture inspector"
            aria-pressed={inspector}
            onClick={() => {
              setInspector((v) => !v);
              if (window.innerWidth <= 760) setExplorer(false);
            }}
          >
            <PanelRight size={15} />
          </button>
          <button
            aria-label="zoom in"
            onClick={() => void flow.zoomIn()}
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.zoom-in"
          >
            Zoom in
          </button>
          <button
            aria-label="zoom out"
            onClick={() => void flow.zoomOut()}
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.zoom-out"
          >
            Zoom out
          </button>
          <label>
            <input
              type="checkbox"
              aria-label="Show architecture minimap"
              data-devlab-source="packages/pop-the-hood/src/react.tsx"
              data-devlab-id="hood.minimap"
              checked={minimap}
              onChange={(event) => setMinimap(event.target.checked)}
            />
            Minimap
          </label>
        </div>
        <button
          className="hood-drawer-close"
          title="Close architecture drawer"
          type="button"
          aria-label="Close architecture drawer"
          data-devlab-source="packages/pop-the-hood/src/react.tsx"
          data-devlab-id="hood.drawer.close.layout"
          onClick={closeDrawer}
        >
          <X size={14} aria-hidden="true" />
        </button>
      </section>
      <section
        className="hood-drawer"
        onFocusCapture={revealDrawerFocus}
        role="region"
        hidden={drawer !== 'wires'}
        id={`${drawerId}-wires-drawer`}
        aria-labelledby={`${drawerId}-wires-trigger`}
        data-devlab-source="packages/pop-the-hood/src/react.tsx"
        data-devlab-id="hood.panel.wires"
      >
        <div className="hood-drawer-content">
          {presentation === 'overlay' && mode === 'code' && (
            <label>
              <input
                type="checkbox"
                data-devlab-source="packages/pop-the-hood/src/react.tsx"
                data-devlab-id="hood.files"
                aria-label="Show file nodes"
                checked={!hideFiles}
                onChange={(event) => setLocalHideFiles(!event.target.checked)}
              />{' '}
              File nodes
            </label>
          )}

          {mode === 'wiring' && (
            <div
              className="hood-filter-tabs"
              role="group"
              aria-label="Wiring focus"
            >
              {[
                ['services', 'Services'],
                ['ipc', 'IPC channels'],
                ['ui', 'UI registry'],
                ['all', 'All wiring'],
              ].map(([id, label]) => (
                <button
                  key={id}
                  data-devlab-source="packages/pop-the-hood/src/react.tsx"
                  data-devlab-id={`hood.filter.${id}`}
                  aria-pressed={filter === id}
                  onClick={() => {
                    setFilter(id!);
                    setQuery('');
                    setSelected(null);
                    setSelectedWire(null);
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
          )}
          <span className="hood-eyebrow">WIRES</span>
          {(mode === 'code' ? codeLayers : wiringLayers).map((kind) => (
            <label key={kind} className="hood-layer">
              <input
                type="checkbox"
                data-devlab-source="packages/pop-the-hood/src/react.tsx"
                data-devlab-id={`hood.wires.${kind}`}
                aria-label={`${kind} wires`}
                checked={layers.has(kind)}
                onChange={(e) => {
                  const update = (current: Set<RegistryEdge['kind']>) => {
                    const next = new Set(current);
                    e.target.checked ? next.add(kind) : next.delete(kind);
                    return next;
                  };
                  mode === 'code'
                    ? setCodeEnabled(update)
                    : setWiringEnabled(update);
                }}
              />
              <i style={{ background: wireColors[kind] }} />
              {kind}
            </label>
          ))}
          {mode === 'code' && (
            <label className="hood-check">
              <input
                type="checkbox"
                data-devlab-source="packages/pop-the-hood/src/react.tsx"
                data-devlab-id="hood.external"
                checked={external}
                onChange={(e) => setExternal(e.target.checked)}
              />
              External
            </label>
          )}
        </div>
        <button
          className="hood-drawer-close"
          title="Close architecture drawer"
          type="button"
          aria-label="Close architecture drawer"
          data-devlab-source="packages/pop-the-hood/src/react.tsx"
          data-devlab-id="hood.drawer.close.wires"
          onClick={closeDrawer}
        >
          <X size={14} aria-hidden="true" />
        </button>
      </section>
      <section
        className="hood-drawer"
        onFocusCapture={revealDrawerFocus}
        role="region"
        hidden={drawer !== 'project'}
        id={`${drawerId}-project-drawer`}
        aria-labelledby={`${drawerId}-project-trigger`}
        data-devlab-source="packages/pop-the-hood/src/react.tsx"
        data-devlab-id="hood.panel.project"
      >
        <div className="hood-drawer-content">
          {presentation !== 'embedded' && (
            <>
              {' '}
              <label className="hood-project-picker">
                <span>Project</span>
                <select
                  data-devlab-source="packages/pop-the-hood/src/react.tsx"
                  data-devlab-id="hood.project.select"
                  aria-label="Inspect project"
                  value={projectId}
                  onChange={(event) => setProjectId(event.target.value)}
                >
                  {!projects.some((p) => p.id === projectId) && (
                    <option value={projectId}>{projectId}</option>
                  )}
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.label ?? p.id}
                    </option>
                  ))}
                </select>
              </label>
            </>
          )}
          {project?.previewUrl && (
            <a
              className="hood-preview-link"
              data-devlab-source="packages/pop-the-hood/src/react.tsx"
              data-devlab-id="hood.preview.open"
              href={project.previewUrl}
              target="_blank"
              rel="noopener noreferrer"
            >
              Open live preview ↗
            </a>
          )}
          <button
            title="Download registry snapshot"
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.download"
            aria-label="Download registry snapshot"
            disabled={!snapshot}
            onClick={() => snapshot && download(snapshot)}
          >
            <Download size={15} />
          </button>
          <button
            title="Refresh runtime health"
            data-devlab-source="packages/pop-the-hood/src/react.tsx"
            data-devlab-id="hood.refresh"
            aria-label="Refresh runtime health"
            disabled={loading}
            onClick={() => void load()}
          >
            <RefreshCw size={15} className={loading ? 'hood-spin' : ''} />
          </button>
          {toolbarActions && (
            <div
              className="hood-project-actions"
              onClick={(event) => {
                if ((event.target as HTMLElement).closest('button'))
                  setDrawer(null);
              }}
            >
              {toolbarActions}
            </div>
          )}
          {!toolbarActions && presentation === 'embedded' && (
            <small>Project actions are provided by the host.</small>
          )}
        </div>
        <button
          className="hood-drawer-close"
          title="Close architecture drawer"
          type="button"
          aria-label="Close architecture drawer"
          data-devlab-source="packages/pop-the-hood/src/react.tsx"
          data-devlab-id="hood.drawer.close.project"
          onClick={closeDrawer}
        >
          <X size={14} aria-hidden="true" />
        </button>
      </section>
      <div className="hood-workspace">
        {explorer && (
          <aside
            className="hood-explorer"
            data-testid="hood-explorer"
            aria-label="Architecture explorer"
          >
            <div className="hood-panel-heading">
              <span>{mode === 'code' ? 'SOURCE TREE' : 'WIRING REGISTRY'}</span>
              <span>{graph.items.length}</span>
            </div>
            <Tree
              graph={graph}
              expanded={expanded}
              query={query}
              external={external}
              selected={selected}
              toggle={toggle}
              select={(id) => select(id, true)}
            />
          </aside>
        )}
        <main className="hood-canvas" aria-label="Architecture graph">
          <NodeContext.Provider value={{ toggle, direction }}>
            <ReactFlow
              id={`hood-${drawerId.replace(/[^a-zA-Z0-9_-]/g, '')}`}
              nodes={nodes}
              edges={edges}
              nodeTypes={nodeTypes}
              onNodesChange={(changes) =>
                setNodes((current) => applyNodeChanges(changes, current))
              }
              onNodeDragStop={(_e, n) =>
                manual.current.set(mode + ':' + n.id, n.position)
              }
              onNodeClick={(_e, n) => select(n.id)}
              onNodeDoubleClick={(_e, n) => toggle(n.id)}
              onEdgeClick={(_e, e) => {
                setSelectedWire(e.id);
                setSelected(null);
                setInspector(true);
              }}
              onPaneClick={() => {
                setSelected(null);
                setSelectedWire(null);
              }}
              nodesConnectable={false}
              edgesReconnectable={false}
              deleteKeyCode={null}
              minZoom={0.05}
              maxZoom={2.5}
              panOnDrag
              selectionOnDrag={false}
              onlyRenderVisibleElements
              proOptions={{ hideAttribution: true }}
            >
              <Background
                id={`hood-background-${backgroundId}`}
                variant={BackgroundVariant.Dots}
                gap={22}
                size={1}
                color="var(--hood-grid)"
              />
              {minimap && (
                <MiniMap
                  pannable
                  zoomable
                  nodeColor={(n) => {
                    const item = n.data.item as RegistryItem;
                    return item.kind === 'channel'
                      ? '#fbbf24'
                      : item.kind === 'service'
                        ? '#34d399'
                        : item.kind === 'plugin'
                          ? '#38bdf8'
                          : '#64748b';
                  }}
                />
              )}
            </ReactFlow>
          </NodeContext.Provider>
          <div className="hood-canvas-caption">
            <span>
              {mode === 'code' ? 'SOURCE RELATIONSHIPS' : 'DECLARED TOPOLOGY'}
            </span>
            <strong>
              {projection.items.length} boxes · {projection.wires.length}{' '}
              bundled wires
            </strong>
            <small>Drag to pan · scroll to zoom · double-click to expand</small>
          </div>
          {loading && !snapshot && (
            <div className="hood-empty" role="status">
              <RefreshCw size={24} />
              Loading architecture snapshot…
            </div>
          )}
          {error && (
            <div className="hood-empty" role="alert">
              <strong>Architecture unavailable</strong>
              <p>{error}</p>
              <button onClick={() => void load()}>Retry snapshot</button>
            </div>
          )}
          {!loading && !error && projection.items.length === 0 && (
            <div className="hood-empty">
              <Search size={24} />
              <strong>
                {mode === 'wiring' && !graph.items.length
                  ? 'No registry adapter registered'
                  : 'No architecture matches'}
              </strong>
              <p>
                {mode === 'wiring' && !graph.items.length
                  ? 'Add a runtime adapter or hood.registry.json to declare services and IPC.'
                  : 'Try a filename, symbol, service or route.'}
              </p>
              <button onClick={() => setQuery('')}>Clear search</button>
            </div>
          )}
        </main>
        {inspector && (
          <aside
            className="hood-inspector"
            data-testid="hood-inspector"
            aria-label="Architecture inspector"
          >
            <div className="hood-panel-heading">
              <span>INSPECTOR</span>
              <span>
                {chosenWire ? 'WIRE' : (selectedItem?.kind ?? 'OVERVIEW')}
              </span>
            </div>
            {chosenWire ? (
              <WireInspector wire={chosenWire} selectSource={selectSource} />
            ) : selectedItem ? (
              <>
                <div className="hood-selection-heading">
                  <ItemIcon kind={selectedItem.kind} size={22} />
                  <h2>{selectedItem.label}</h2>
                  <p>{selectedItem.detail}</p>
                  {selectedItem.path && (
                    <code>
                      {selectedItem.path}
                      {selectedItem.line ? `:${selectedItem.line}` : ''}
                    </code>
                  )}
                </div>
                <details open>
                  <summary>Structure & identity</summary>
                  <div className="hood-detail-body">
                    <p className="hood-mono">{selectedItem.id}</p>
                    <div className="hood-detail-actions">
                      <button onClick={() => setFocusId(selectedItem.id)}>
                        Focus on canvas
                      </button>
                      {Boolean(
                        projection.children.get(selectedItem.id)?.length,
                      ) && (
                        <button onClick={() => toggle(selectedItem.id)}>
                          {expanded.has(selectedItem.id)
                            ? 'Collapse'
                            : 'Expand'}{' '}
                          children
                        </button>
                      )}
                    </div>
                    {runtime && (
                      <>
                        <span className={`hood-health ${runtime.state}`}>
                          {runtime.state} · generation {runtime.generation} ·{' '}
                          {runtime.leases} leases
                        </span>
                        <dl>
                          <dt>Provides</dt>
                          <dd>{runtime.provides.join(', ') || 'none'}</dd>
                          <dt>Requires</dt>
                          <dd>{runtime.requires.join(', ') || 'none'}</dd>
                          <dt>Live refs</dt>
                          <dd>{runtime.live.join(', ') || 'none'}</dd>
                          <dt>Capabilities</dt>
                          <dd>{runtime.capabilities.join(', ') || 'none'}</dd>
                          <dt>Reload</dt>
                          <dd>{runtime.reload}</dd>
                        </dl>
                      </>
                    )}
                    {selectedItem.kind === 'ui' && (
                      <p>
                        {browserContribution
                          ? 'Mounted in this browser'
                          : 'Build declaration · not mounted in this browser'}
                      </p>
                    )}
                    {protocol && (
                      <>
                        <span className="hood-protocol">
                          {protocol.protocol} · {protocol.direction}
                        </span>
                        <dl>
                          <dt>Request</dt>
                          <dd>{protocol.request}</dd>
                          <dt>Response</dt>
                          <dd>{protocol.response}</dd>
                          <dt>From</dt>
                          <dd>{protocol.from}</dd>
                          <dt>To</dt>
                          <dd>{protocol.to}</dd>
                        </dl>
                        <p className="hood-muted">
                          Declared channel; no traffic or payload capture.
                        </p>
                      </>
                    )}
                  </div>
                </details>
                <ConnectionList
                  title="Incoming"
                  edges={incoming}
                  select={(id) => {
                    setSelectedWire(id);
                    setSelected(null);
                  }}
                />
                <ConnectionList
                  title="Outgoing"
                  edges={outgoing}
                  select={(id) => {
                    setSelectedWire(id);
                    setSelected(null);
                  }}
                />
                {sourcePath && api && (
                  <SourcePreview
                    api={sourceClient!}
                    path={sourcePath}
                    line={sourceLine ?? selectedItem.line ?? 1}
                    endLine={
                      sourceLine ??
                      selectedItem.endLine ??
                      selectedItem.line ??
                      1
                    }
                    snapshotId={snapshot!.catalog.snapshotId}
                    openCode={() => selectSource(sourcePath, selectedItem.line)}
                  />
                )}
                <details>
                  <summary>Registry record</summary>
                  <pre className="hood-json">
                    {JSON.stringify(
                      runtime ?? protocol ?? selectedItem,
                      null,
                      2,
                    )}
                  </pre>
                </details>
              </>
            ) : (
              <div className="hood-overview">
                <Network size={30} />
                <h2>Follow the wiring</h2>
                <p>
                  Select a module, file, service or wire. Expand containers to
                  reveal their contents.
                </p>
                <details open>
                  <summary>Snapshot</summary>
                  <dl>
                    <dt>Source files</dt>
                    <dd>
                      {snapshot?.catalog.graph.items.filter(
                        (i) => i.kind === 'file',
                      ).length ?? 0}
                    </dd>
                    <dt>Source imports</dt>
                    <dd>{snapshot?.catalog.graph.edges.length ?? 0}</dd>
                    <dt>Backend plugins</dt>
                    <dd>{snapshot?.plugins.length ?? 0}</dd>
                    <dt>Transport channels</dt>
                    <dd>{snapshot?.catalog.channels.length ?? 0}</dd>
                  </dl>
                </details>
                <details open>
                  <summary>Evidence guide</summary>
                  <p>
                    {snapshot?.observation?.mode === 'live'
                      ? 'Code updates automatically after file changes. '
                      : 'Code is a build snapshot. '}
                    Runtime wiring comes from adapters or explicit declarations.
                    Declarations alone do not prove an active service.
                  </p>
                  <p>
                    Opening Hood never changes the workflow or its running
                    terminals.
                  </p>
                </details>
              </div>
            )}
          </aside>
        )}
      </div>
      <footer className="hood-status">
        <span>
          <i />
          {loading
            ? 'Refreshing…'
            : snapshot?.observation?.status === 'stale'
              ? 'Stale · last good snapshot'
              : presentation === 'embedded'
                ? 'Live project files'
                : 'Read-only architecture'}
        </span>
        <span title={snapshot?.catalog.builtAt}>
          {snapshot?.observation?.mode === 'live'
            ? `Revision ${snapshot.observation.revision}`
            : 'Build'}{' '}
          {snapshot?.catalog.snapshotId.slice(0, 10) ?? '…'} ·{' '}
          {snapshot ? new Date(snapshot.catalog.builtAt).toLocaleString() : ''}
        </span>
        <span
          title={snapshot?.observation?.message ?? project?.warning}
          role={snapshot?.observation?.status === 'stale' ? 'alert' : undefined}
        >
          {snapshot?.observation?.message ??
            project?.warning ??
            (snapshot?.observation?.mode === 'live'
              ? `${connection} · source changes update automatically`
              : 'Source changes require rebuild · health refresh is live')}
        </span>
      </footer>
    </div>
  );
}

function Tree({
  graph,
  expanded,
  query,
  external,
  selected,
  toggle,
  select,
}: {
  graph: RegistryGraph;
  expanded: Set<string>;
  query: string;
  external: boolean;
  selected: string | null;
  toggle: (id: string) => void;
  select: (id: string) => void;
}) {
  const children = new Map<string | null, RegistryItem[]>();
  for (const item of graph.items) {
    const list = children.get(item.parentId) ?? [];
    list.push(item);
    children.set(item.parentId, list);
  }
  const q = query.trim().toLowerCase(),
    matching = new Set(
      graph.items
        .filter((i) =>
          [i.label, i.path ?? '', i.detail].some((s) =>
            s.toLowerCase().includes(q),
          ),
        )
        .map((i) => i.id),
    );
  const parents = new Set<string>();
  if (q)
    for (const id of matching)
      for (const parent of ancestors(graph.items, id)) parents.add(parent);
  function branch(parent: string | null, depth: number): React.ReactNode {
    return children
      .get(parent)
      ?.filter(
        (i) =>
          (external || (i.kind !== 'external' && i.id !== 'group:external')) &&
          (!q || matching.has(i.id) || parents.has(i.id)),
      )
      .map((item) => {
        const kids = children.get(item.id) ?? [],
          open = expanded.has(item.id) || parents.has(item.id);
        return (
          <div
            key={item.id}
            role="treeitem"
            aria-level={depth + 1}
            aria-selected={selected === item.id}
            aria-expanded={kids.length ? open : undefined}
          >
            <div
              className={`hood-tree-row${selected === item.id ? ' selected' : ''}`}
              style={{ paddingLeft: 8 + depth * 12 }}
            >
              {kids.length ? (
                <button
                  className="hood-tree-toggle"
                  aria-label={`${open ? 'Collapse' : 'Expand'} ${item.label}`}
                  onClick={() => toggle(item.id)}
                >
                  {open ? (
                    <ChevronDown size={13} />
                  ) : (
                    <ChevronRight size={13} />
                  )}
                </button>
              ) : (
                <span className="hood-tree-spacer" />
              )}
              <button
                className="hood-tree-select"
                title={item.path ?? item.detail}
                aria-label={`Select ${item.kind === 'symbol' ? item.path + '#' + item.label : ['file', 'directory', 'module'].includes(item.kind) ? (item.path ?? item.label) : item.label}`}
                onClick={() => select(item.id)}
              >
                <ItemIcon kind={item.kind} size={13} />
                <span>{item.label}</span>
                {kids.length > 0 && <small>{kids.length}</small>}
              </button>
            </div>
            {open && kids.length > 0 && (
              <div role="group">{branch(item.id, depth + 1)}</div>
            )}
          </div>
        );
      });
  }
  return (
    <div className="hood-tree" role="tree" aria-label="Architecture hierarchy">
      {branch(null, 0)}
    </div>
  );
}
function ConnectionList({
  title,
  edges,
  select,
}: {
  title: string;
  edges: RegistryEdge[];
  select: (id: string) => void;
}) {
  return (
    <details open>
      <summary>
        {title} <span>{edges.length}</span>
      </summary>
      <div className="hood-connections">
        {edges.length === 0 ? (
          <p className="hood-muted">No {title.toLowerCase()} connections.</p>
        ) : (
          edges.map((e) => (
            <button key={e.id} onClick={() => select(e.id)}>
              <i style={{ background: wireColors[e.kind] }} />
              <span>
                <b>{e.kind}</b>{' '}
                {e.source.replace(/^(file|plugin|service|ui):/, '')}
                <small>
                  → {e.target.replace(/^(file|plugin|service|ui):/, '')}
                </small>
              </span>
              <ChevronRight size={12} />
            </button>
          ))
        )}
      </div>
    </details>
  );
}
function WireInspector({
  wire,
  selectSource,
}: {
  wire: ProjectedWire;
  selectSource: (path: string, line?: number) => void;
}) {
  return (
    <div className="hood-wire-inspector">
      <span className="hood-protocol" style={{ color: wireColors[wire.kind] }}>
        {wire.kind} · {wire.originals.length} source wire
        {wire.originals.length === 1 ? '' : 's'}
      </span>
      <h2>Connection evidence</h2>
      <p className="hood-mono">
        {wire.source}
        <br />↓<br />
        {wire.target}
      </p>
      {wire.typeOnly && <p>Type-only import clause</p>}
      {wire.originals.map((original) => (
        <details open key={original.id}>
          <summary>{original.label}</summary>
          <div className="hood-detail-body">
            <code>
              {original.source} → {original.target}
            </code>
            {original.evidence.length ? (
              original.evidence.map((proof, index) => (
                <button
                  className="hood-evidence"
                  key={index}
                  onClick={() => selectSource(proof.path, proof.line)}
                >
                  <FileCode2 size={13} />
                  <span>
                    {proof.path}:{proof.line}
                    <small>{proof.text}</small>
                  </span>
                </button>
              ))
            ) : (
              <p className="hood-muted">
                Structural containment from the registry tree.
              </p>
            )}
          </div>
        </details>
      ))}
    </div>
  );
}
function SourcePreview({
  api,
  path,
  line,
  endLine,
  snapshotId,
  openCode,
}: {
  api: RegistryClient;
  path: string;
  line: number;
  endLine: number;
  snapshotId: string;
  openCode: () => void;
}) {
  const [source, setSource] = useState<RegistrySource | null>(null),
    [error, setError] = useState(''),
    [attempt, setAttempt] = useState(0);
  const code = useRef<HTMLPreElement>(null);
  useEffect(() => {
    let alive = true;
    setSource(null);
    setError('');
    void api
      .source(path)
      .then((value) => {
        if (alive) setSource(value);
      })
      .catch((e) => {
        if (alive) setError(String(e));
      });
    return () => {
      alive = false;
    };
  }, [api, path, snapshotId, attempt]);
  useEffect(() => {
    if (!source || !code.current) return;
    const target = code.current.querySelector<HTMLElement>(
      `[data-line="${line}"]`,
    );
    if (target) code.current.scrollTop = target.offsetTop - 80;
  }, [source, line]);
  return (
    <details open className="hood-source">
      <summary>
        Source preview <span>read-only</span>
      </summary>
      <div className="hood-source-heading">
        <code title={path}>{path}</code>
        <button onClick={openCode}>Open in code map</button>
      </div>
      {error ? (
        <div role="alert">
          {error}
          <button onClick={() => setAttempt((v) => v + 1)}>Retry source</button>
        </div>
      ) : !source ? (
        <p role="status">Loading built source…</p>
      ) : (
        <>
          <div className="hood-source-hash">
            SHA256 {source.sha256.slice(0, 16)} · built snapshot
          </div>
          <pre ref={code} data-testid="hood-source-code" tabIndex={0}>
            {source.text.split('\n').map((text, index) => (
              <span
                className={
                  index + 1 >= line && index + 1 <= endLine
                    ? 'hood-source-line in-range'
                    : 'hood-source-line'
                }
                key={index}
                data-line={index + 1}
              >
                <em>{index + 1}</em>
                <code>{text || ' '}</code>
              </span>
            ))}
          </pre>
        </>
      )}
    </details>
  );
}
