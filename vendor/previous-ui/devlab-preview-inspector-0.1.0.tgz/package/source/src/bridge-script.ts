export const BRIDGE_SCRIPT = String.raw`
/* Cooperative project preview inspection. No CDP or source-writing authority. */
(() => {
  'use strict';
  const channel = 'devlab-preview-v1';
  const key = '__devlabPreviewBridgeV1';
  window[key]?.dispose?.();
  let session = null, picking = false, selected = null, epoch = 0, refresh = 'unknown';
  const retired = new Set();
  const cut = (value, max = 256) => String(value ?? '').slice(0, max);
  const validId = value => typeof value === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(value);
  const validNonce = value => typeof value === 'string' && /^[a-zA-Z0-9_-]{16,128}$/.test(value);
  function parentOrigin(value) {
    try { const u = new URL(value); return !u.username && !u.password && ['http:', 'https:'].includes(u.protocol) && ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname) && u.origin === value; } catch { return false; }
  }
  function send(type, data = {}) {
    if (session) window.parent.postMessage({ channel, type, projectId: session.projectId, generation: session.generation, nonce: session.nonce, epoch, refresh, ...data }, session.origin);
  }
  function reset(reason) {
    send('reset', { reason });
    if (session) { retired.add(session.nonce); if (retired.size > 32) retired.delete(retired.values().next().value); }
    session = null; picking = false; selected = null; epoch++;
  }
  function matches(data) { return session && data.projectId === session.projectId && data.generation === session.generation && data.nonce === session.nonce; }
  function receive(event) {
    const d = event.data;
    if (event.source !== window.parent || window.parent === window || !parentOrigin(event.origin) || !d || d.channel !== channel) return;
    if (d.type === 'init') {
      if (!validId(d.projectId) || !validId(d.generation) || !validNonce(d.nonce) || retired.has(d.nonce)) return;
      if (session && matches(d)) { send('ready', { capabilities: ['cooperative-picker', 'semantic-css-evidence'] }); return; }
      reset('session-replaced'); session = { projectId: d.projectId, generation: d.generation, nonce: d.nonce, origin: event.origin };
      send('ready', { capabilities: ['cooperative-picker', 'semantic-css-evidence'] });
    } else if (event.origin === session?.origin && matches(d)) {
      if (d.type === 'pick') { picking = true; send('picking'); }
      if (d.type === 'cancel') { picking = false; send('cancelled'); }
    }
  }
  function source(raw) {
    if (typeof raw !== 'string' || raw.length > 512 || raw.startsWith('/') || raw.includes('\\') || raw.split('/').includes('..') || !/^[a-zA-Z0-9_./@ -]+(?::[1-9][0-9]{0,6}(?::[1-9][0-9]{0,6})?)?$/.test(raw)) return { status: 'unknown', reason: 'No valid project-relative source annotation' };
    return { status: 'annotated', value: raw, verified: false };
  }
  function tokenEvidence(element) {
    const refs = new Map(); let unreadableSheets = 0, ruleBudget = 2000;
    function declarations(style, via) {
      if (!style) return;
      for (const property of Array.from(style)) {
        const value = style.getPropertyValue(property);
        for (const match of value.matchAll(/var\(\s*(--[a-zA-Z0-9_-]{1,96})/g)) {
          if (refs.size >= 64 && !refs.has(match[1])) continue;
          if (!refs.has(match[1])) refs.set(match[1], { token: match[1], properties: [], evidence: via });
          const item = refs.get(match[1]); if (item.properties.length < 8 && !item.properties.includes(property)) item.properties.push(cut(property, 96));
        }
      }
    }
    function rules(list) {
      for (const rule of Array.from(list ?? []).slice(0, 2000)) {
        if (--ruleBudget < 0) return;
        if (rule.selectorText) { try { if (element.matches(rule.selectorText)) declarations(rule.style, 'matching-rule'); } catch {} }
        if (rule.cssRules) { if (rule.conditionText && rule.constructor.name === 'CSSMediaRule' && !matchMedia(rule.conditionText).matches) continue; rules(rule.cssRules); }
      }
    }
    declarations(element.style, 'inline');
    const root = element.getRootNode();
    for (const sheet of [...Array.from(root === document ? document.styleSheets : []), ...Array.from(root.adoptedStyleSheets ?? []), ...Array.from(root.querySelectorAll?.('style') ?? []).map(node => node.sheet).filter(Boolean)].slice(0, 64)) {
      try { rules(sheet.cssRules); } catch { unreadableSheets++; }
    }
    const computed = getComputedStyle(element);
    return { references: [...refs.values()].map(item => ({ ...item, computedValue: cut(computed.getPropertyValue(item.token)), propertyValues: Object.fromEntries(item.properties.map(p => [p, cut(computed.getPropertyValue(p))])) })), unreadableSheets, coverage: 'Accessible matching declarations only; inheritance, closed shadow roots and cascade provenance may be incomplete' };
  }
  function pick(event) {
    if (!picking || !session) return;
    const element = event.composedPath().find(node => node instanceof Element);
    if (!element) return;
    event.preventDefault(); event.stopImmediatePropagation(); picking = false; selected = element;
    const rect = element.getBoundingClientRect(), raw = element.getAttribute('data-devlab-id');
    const stableId = raw && /^[a-zA-Z0-9_.:-]{1,128}$/.test(raw) ? raw : null;
    const root = element.getRootNode();
    if (root instanceof ShadowRoot) observer.observe(root, { subtree: true, childList: true });
    const duplicates = stableId ? Array.from(root.querySelectorAll('[data-devlab-id]')).filter(n => n.getAttribute('data-devlab-id') === stableId).length : 0;
    send('selection', { selection: { stableId, identityStatus: !stableId ? 'missing' : duplicates > 1 ? 'duplicate' : 'annotated', tag: cut(element.localName, 64), role: cut(element.getAttribute('role'), 64) || ({button:'button',a:element.hasAttribute('href')?'link':null,input:element.getAttribute('type')==='checkbox'?'checkbox':'textbox',select:'combobox',textarea:'textbox',img:'img'}[element.localName] ?? null), name: cut(element.getAttribute('aria-label') || element.getAttribute('alt') || element.textContent, 256), source: source(element.getAttribute('data-devlab-source')), tokens: tokenEvidence(element), bounds: Object.fromEntries(['x','y','width','height'].map(k => [k, Number.isFinite(rect[k]) ? Math.round(rect[k] * 100) / 100 : 0])), shadow: root instanceof ShadowRoot ? 'open-shadow' : 'document' } });
  }
  function keydown(event) { if (picking && event.key === 'Escape') { event.preventDefault(); picking = false; send('cancelled'); } }
  const navigation = () => reset('navigation'); const hmr = () => { refresh = 'connected'; reset('hmr'); };
  const hmrState = event => { if (typeof event.detail?.connected !== 'boolean') return; refresh = event.detail.connected ? 'connected' : 'disconnected'; if (refresh === 'disconnected') reset('hmr-disconnected'); else send('refresh-state'); };
  const observer = new MutationObserver(() => { if (selected && !selected.isConnected) { selected = null; epoch++; send('invalidated', { reason: 'selected-element-removed' }); } });
  observer.observe(document.documentElement, { subtree: true, childList: true });
  window.addEventListener('message', receive); window.addEventListener('click', pick, true); window.addEventListener('keydown', keydown, true);
  window.addEventListener('pagehide', navigation); window.addEventListener('popstate', navigation); window.addEventListener('hashchange', navigation); window.addEventListener('devlab:hmr', hmr); window.addEventListener('devlab:hmr-state', hmrState);
  window[key] = { dispose() { reset('bridge-replaced'); observer.disconnect(); window.removeEventListener('message', receive); window.removeEventListener('click', pick, true); window.removeEventListener('keydown', keydown, true); window.removeEventListener('pagehide', navigation); window.removeEventListener('popstate', navigation); window.removeEventListener('hashchange', navigation); window.removeEventListener('devlab:hmr', hmr); window.removeEventListener('devlab:hmr-state', hmrState); delete window[key]; } };
})();
`;
