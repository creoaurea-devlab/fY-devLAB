import { randomUUID } from 'node:crypto';
import { mkdtemp, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { BrowserContext, Page } from 'playwright-core';
import type { ProjectServers,PreviewNativeTarget } from '@devlab/contracts';
import {parseNativeTarget,nativeViewURL,nativeFrameMatches} from './native-target.ts';
export interface NativeWorkspaceInspector {
  openWorkspace(
    ownHostUrl: string,
    projectId: string,
    target?:PreviewNativeTarget,
  ): Promise<{ sessionId: string }>;
  openDevTools(
    sessionId: string,
    projectId: string,
  ): Promise<{
    targetId: string;
    devToolsTargetId: string;
    projectId: string;
    generation: number;
  }>;
  close(sessionId: string): Promise<void>;
  dispose(): Promise<void>;
}
type Session = {
  id: string;
  projectId: string;
  target?:PreviewNativeTarget;
  context: BrowserContext;
  page?: Page;
  directory: string;
  closing?: Promise<void>;
};
function hostUrl(value: string) {
  const u = new URL(value);
  if (
    u.protocol !== 'http:' ||
    !['localhost', '127.0.0.1', '[::1]'].includes(u.hostname) ||
    u.username ||
    u.password ||
    u.hash ||
    u.search
  )
    throw new Error(
      'Owned workspace requires trusted credential-free loopback app URL',
    );
  return u;
}
function timeout<T>(
  promise: Promise<T>,
  ms: number,
  message: string,
): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  return Promise.race([
    promise,
    new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(message)), ms);
    }),
  ]).finally(() => clearTimeout(timer));
}
/** Owns a separate headed app page, never discovers or attaches arbitrary browser tabs. */
export function createNativeWorkspaceInspector(options: {
  ownHostUrl: string;
  servers: Pick<ProjectServers, 'inspect'>;
  display?: string;
  executablePath?: string;
  maxSessions?: number;
}): NativeWorkspaceInspector {
  const trusted = hostUrl(options.ownHostUrl),
    sessions = new Map<string, Session>(),
    pending = new Set<Promise<unknown>>();
  let closed = false;
  const available = () => {
    if (closed) throw new Error('Native workspace inspector is closed');
  };
  async function closeSession(s: Session) {
    if (s.closing) return s.closing;
    s.closing = (async () => {
      await timeout(
        s.context.close(),
        7000,
        'Chromium workspace close timed out; retained session ' + s.id,
      );
      await rm(s.directory, {
        recursive: true,
        force: true,
        maxRetries: 5,
        retryDelay: 100,
      });
      sessions.delete(s.id);
    })().catch((error) => {
      s.closing = undefined;
      throw error;
    });
    return s.closing;
  }
  const service: NativeWorkspaceInspector = {
    openWorkspace(value, projectId,requestedTarget) {
      const target=parseNativeTarget(requestedTarget);
      available();
      const requested = hostUrl(value);
      if (requested.href !== trusted.href)
        throw new Error('Workspace URL does not match its host');
      if (sessions.size + pending.size >= (options.maxSessions ?? 4))
        throw new Error('Native workspace limit reached');
      const operation = (async () => {
        const server = await options.servers.inspect(projectId);
        if (server.status !== 'ready' || !server.url)
          throw new Error('Project preview is not ready');
        if(target)nativeViewURL(server,target.viewId);
        available();
        const { chromium } = await import('playwright-core');
        const directory = await mkdtemp(
          join(tmpdir(), 'devlab-native-workspace-'),
        );
        let context: BrowserContext | undefined;
        let session: Session | undefined;
        try {
          const env: Record<string, string> = {};
          for (const key of [
            'PATH',
            'HOME',
            'USER',
            'LOGNAME',
            'LANG',
            'TZ',
            'TMPDIR',
            'XAUTHORITY',
            'XDG_RUNTIME_DIR',
          ])
            if (process.env[key]) env[key] = process.env[key]!;
          if (options.display) env.DISPLAY = options.display;
          else if (process.env.DISPLAY) env.DISPLAY = process.env.DISPLAY;
          for (const path of [
            '/opt/google/chrome/chrome-sandbox',
            '/usr/lib/chromium/chrome-sandbox',
          ]) {
            const info = await stat(path).catch(() => null);
            if (
              info?.isFile() &&
              info.uid === 0 &&
              (info.mode & 0o4000) !== 0 &&
              (info.mode & 0o022) === 0
            ) {
              env.CHROME_DEVEL_SANDBOX = path;
              break;
            }
          }
          context = await chromium.launchPersistentContext(directory, {
            headless: false,
            chromiumSandbox: true,
            executablePath: options.executablePath,
            env,
            acceptDownloads: false,
            viewport: null,
            timeout: 15000,
          });
          const id = randomUUID();
          session = { id, projectId, target, context, directory };
          sessions.set(id, session);
          const provisional = session;
          context.on('close', () => {
            if (!provisional.closing)
              void closeSession(provisional).catch(() => {});
          });
          context.setDefaultTimeout(3000);
          const page = context.pages()[0] ?? (await context.newPage());
          session.page = page;
          const url = new URL(trusted);
          url.searchParams.set('projectId', projectId);
          url.searchParams.set('nativeSession', id);
          if(target){url.searchParams.set('nativePane',target.paneId);url.searchParams.set('previewView',target.viewId);}
          page.on('dialog', (dialog) => void dialog.dismiss());
          page.on('download', (download) => void download.cancel());
          await page.goto(url.href, {
            waitUntil: 'domcontentloaded',
            timeout: 12000,
          });
          available();
          return { sessionId: id };
        } catch (error) {
          if (session) {
            try {
              await closeSession(session);
            } catch (cleanupError) {
              throw new AggregateError(
                [error, cleanupError],
                'Workspace launch failed; cleanup retained session ' +
                  session.id,
              );
            }
          } else {
            await rm(directory, {
              recursive: true,
              force: true,
              maxRetries: 5,
              retryDelay: 100,
            });
          }
          throw error;
        }
      })();
      pending.add(operation);
      void operation.finally(() => pending.delete(operation)).catch(() => {});
      return operation;
    },
    async openDevTools(sessionId, projectId) {
      available();
      const session = sessions.get(sessionId);
      if (
        !session ||
        session.closing ||
        session.projectId !== projectId ||
        !session.page
      )
        throw new Error('Unknown project workspace session');
      const page = session.page;
      const location = new URL(page.url());
      if (
        location.origin !== trusted.origin ||
        location.pathname !== trusted.pathname ||
        location.searchParams.get('nativeSession') !== sessionId ||
        location.searchParams.get('projectId') !== projectId ||
        session.target&&(location.searchParams.get('nativePane')!==session.target.paneId||location.searchParams.get('previewView')!==session.target.viewId)
      )
        throw new Error('Owned workspace navigated away');
      const server = await options.servers.inspect(projectId);
      if (server.status !== 'ready' || !server.url || !server.descriptor)
        throw new Error('Managed preview is not ready');
      const frames = page.locator('iframe[data-devlab-project-id]');
      const count = await frames.count();
      let selected: Awaited<ReturnType<typeof frames.elementHandle>> | null =
        null;
      for (let i = 0; i < count; i++) {
        const locator = frames.nth(i);
        const handle = await locator.elementHandle();
        const frame = await handle?.contentFrame();
        if (!handle || !frame) {await handle?.dispose();continue;}
        const attrs:Record<string,string|undefined>={};
        for(const name of ['data-devlab-project-id','data-devlab-generation','data-devlab-instance-id','data-pane-id','src'])attrs[name]=(await locator.getAttribute(name))??undefined;
        if (nativeFrameMatches(attrs,frame.url(),server,session.target)) {
          if(selected){await handle.dispose();await selected.dispose();throw new Error('Ambiguous displayed project frame');}
          selected=handle;
        }else await handle.dispose();
      }
      if (!selected)
        throw new Error(
          'Displayed preview does not match managed project generation',
        );
      const cdp = await session.context.newCDPSession(page);
      let browserCdp:
        | Awaited<
            ReturnType<
              NonNullable<
                ReturnType<BrowserContext['browser']>
              >['newBrowserCDPSession']
            >
          >
        | undefined;
      try {
        const { targetInfo } = await cdp.send('Target.getTargetInfo');
        const browser = session.context.browser();
        if (!browser) throw new Error('Browser CDP session unavailable');
        browserCdp = await browser.newBrowserCDPSession();
        const opened = await browserCdp.send('Target.openDevTools', {
          targetId: targetInfo.targetId,
          panelId: 'elements',
        });
        const confirmed = await browserCdp.send('Target.getDevToolsTarget', {
          targetId: targetInfo.targetId,
        });
        await browserCdp.detach();
        if (confirmed.targetId !== opened.targetId)
          throw new Error('DevTools target confirmation failed');
        // Select the verified iframe element in the actual outer page's Elements tree.
        await cdp.send('DOM.enable');
        const document = await cdp.send('DOM.getDocument', { depth: 1 });
        const nodes = await cdp.send('DOM.querySelectorAll', {
          nodeId: document.root.nodeId,
          selector: 'iframe[data-devlab-project-id]',
        });
        let inspected = false;
        for (const nodeId of nodes.nodeIds) {
          const { attributes } = await cdp.send('DOM.getAttributes', {
            nodeId,
          });
          const attrs = Object.fromEntries(
            Array.from({ length: attributes.length / 2 }, (_, i) => [
              attributes[i * 2]!,
              attributes[i * 2 + 1]!,
            ]),
          );
          // The outer CDP node must identify the same pane/source checked above.
          const selectedFrame=await selected.contentFrame();
          if (selectedFrame&&nativeFrameMatches(attrs,selectedFrame.url(),server,session.target)) {
            await cdp.send('DOM.setInspectedNode', { nodeId });
            inspected = true;
            break;
          }
        }
        if (!inspected)
          throw new Error('Preview frame changed during DevTools opening');
        const current = await options.servers.inspect(projectId);
        const frame = await selected.contentFrame();
        if (
          current.status !== 'ready' ||
          current.generation !== server.generation ||
          current.instanceId !== server.instanceId ||
          !frame ||
          !nativeFrameMatches(Object.fromEntries(await Promise.all(['data-devlab-project-id','data-devlab-generation','data-devlab-instance-id','data-pane-id','src'].map(async name=>[name,(await selected!.getAttribute(name))??undefined]))),frame.url(),current,session.target)
        )
          throw new Error('Preview changed during DevTools opening');
        return {
          targetId: targetInfo.targetId,
          devToolsTargetId: opened.targetId,
          projectId,
          generation: server.generation,
        };
      } finally {
        await browserCdp?.detach().catch(() => {});
        await cdp.detach().catch(() => {});
        await selected.dispose();
      }
    },
    async close(id) {
      const session = sessions.get(id);
      if (session) await closeSession(session);
    },
    async dispose() {
      closed = true;
      await Promise.allSettled([...pending]);
      const results = await Promise.allSettled(
        [...sessions.values()].map(closeSession),
      );
      const failed = results.find((r) => r.status === 'rejected');
      if (failed?.status === 'rejected') throw failed.reason;
    },
  };
  return service;
}
