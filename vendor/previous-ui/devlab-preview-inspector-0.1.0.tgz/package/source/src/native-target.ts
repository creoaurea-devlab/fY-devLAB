import {LoopbackPreviewUrlSchema} from '@devlab/contracts';
import type {PreviewNativeTarget,ProjectServerState} from '@devlab/contracts';
const pane=/^[a-zA-Z0-9_-]{1,128}$/;
const view=/^[a-z][a-z0-9-]{0,63}$/;
export function parseNativeTarget(value:PreviewNativeTarget|undefined):PreviewNativeTarget|undefined {
  if(value===undefined)return;
  if(!value||typeof value!=='object'||Object.keys(value).length!==2||Object.keys(value).some(key=>key!=='paneId'&&key!=='viewId')||typeof value.paneId!=='string'||typeof value.viewId!=='string'||!pane.test(value.paneId)||!view.test(value.viewId))throw new Error('Invalid native preview pane/view target.');
  return {paneId:value.paneId,viewId:value.viewId};
}
/** URLs come only from the managed descriptor; clients supply bounded identities. */
export function nativeViewURL(server:ProjectServerState,viewId:string):string {
  if(server.status!=='ready'||!server.url||!server.descriptor)throw new Error('Managed preview is not ready.');
  const entry=server.descriptor.views.find(item=>item.id===viewId);if(!entry)throw new Error('The requested preview view is unavailable.');
  const origin=new URL(LoopbackPreviewUrlSchema.parse(server.url));const resolved=new URL(entry.path,origin);
  if(resolved.origin!==origin.origin||resolved.username||resolved.password)throw new Error('Preview view escapes its managed origin.');
  return resolved.href;
}
/** Initial src is exact; SPA navigation is allowed only within the managed origin. */
export function nativeFrameMatches(attrs:Record<string,string|undefined>,frameURL:string,server:ProjectServerState,target?:PreviewNativeTarget):boolean {
  if(attrs['data-devlab-project-id']!==server.projectId||attrs['data-devlab-generation']!==String(server.generation)||server.instanceId&&attrs['data-devlab-instance-id']!==server.instanceId||target&&attrs['data-pane-id']!==target.paneId)return false;
  try{
    if(!server.descriptor||!server.url||server.status!=='ready'||!attrs.src)return false;
    const source=new URL(attrs.src),actual=new URL(frameURL),origin=new URL(LoopbackPreviewUrlSchema.parse(server.url));
    if(actual.origin!==origin.origin||source.origin!==origin.origin||actual.username||actual.password||source.username||source.password)return false;
    const candidates=target?[nativeViewURL(server,target.viewId)]:server.descriptor.views.map(item=>nativeViewURL(server,item.id));
    return candidates.includes(source.href);
  }catch{return false;}
}
