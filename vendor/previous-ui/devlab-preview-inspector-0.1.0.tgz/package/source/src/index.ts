import type { PluginDefinition, PreviewInspector,PreviewNativeTarget } from '@devlab/contracts';
import { BRIDGE_SCRIPT } from './bridge-script.ts';
import {
  createNativeWorkspaceInspector,
  type NativeWorkspaceInspector,
} from './devtools.ts';
export function previewInspector(): PluginDefinition {
  return {
    manifest: {
      id: 'preview-inspector',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['previewInspector'],
      requires: ['servers'],
      capabilities: ['browser:local'],
      reload: 'restart',
    },
    activate(scope) {
      const hosts = new Map<string, NativeWorkspaceInspector>();
      const service: PreviewInspector = {
        bridgeScript: () => BRIDGE_SCRIPT,
        openWorkspace(ownHostUrl:string, projectId:string,target?:PreviewNativeTarget) {
          const key = new URL(ownHostUrl).href;
          let host = hosts.get(key);
          if (!host) {
            host = createNativeWorkspaceInspector({
              ownHostUrl: key,
              servers: scope.get('servers'),
              executablePath:
                process.env.DEVLAB_CHROMIUM_EXECUTABLE ??
                '/opt/google/chrome/chrome',
            });
            hosts.set(key, host);
          }
          return host.openWorkspace(key, projectId,target);
        },
        async openDevTools(sessionId, projectId) {
          let error: unknown;
          for (const host of hosts.values()) {
            try {
              return await host.openDevTools(sessionId, projectId);
            } catch (e) {
              error = e;
            }
          }
          throw error ?? new Error('Unknown inspectable workspace');
        },
        async closeWorkspace(sessionId) {
          await Promise.all([...hosts.values()].map((h) => h.close(sessionId)));
        },
      };
      scope.onDispose(async () => {
        const results = await Promise.allSettled(
          [...hosts.values()].map((h) => h.dispose()),
        );
        const failed = results.find((r) => r.status === 'rejected');
        if (failed?.status === 'rejected') throw failed.reason;
      });
      scope.provide('previewInspector', service);
    },
  };
}
