import type { UIPluginProps } from '@devlab/ui-contracts';
import { HoodView as PortableHood } from '@creoaurea/pop-the-hood/react';
export function HoodView({
  client,
  hoodOptions,
  projectWorkspace,
}: UIPluginProps) {
  return (
    <PortableHood
      client={
        projectWorkspace && projectWorkspace.snapshot().projectId !== 'default'
          ? projectWorkspace.sourceClient()
          : client.registry
      }
      initialProjectId={
        projectWorkspace && projectWorkspace.snapshot().projectId !== 'default'
          ? 'workspace'
          : hoodOptions?.projectId
      }
      onClose={hoodOptions?.onClose}
      uiContributions={hoodOptions?.uiContributions}
      theme="inherit"
    />
  );
}
