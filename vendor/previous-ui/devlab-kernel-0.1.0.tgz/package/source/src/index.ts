import { Context, FiberState, type Fiber } from 'cordis';
import {
  ApplicationError,
  type PluginDefinition,
  type PluginHealth,
  type PluginScope,
  type ServiceKey,
  type ServiceMap,
} from '@devlab/contracts';

declare module 'cordis' {
  interface Context extends ServiceMap {}
}
interface Mounted {
  definition: PluginDefinition;
  fiber: Fiber;
  health: PluginHealth;
}

/** Cordis owns dependency lifetimes; this adapter enforces profiles and admission. */
export class Kernel {
  readonly #root = new Context();
  readonly #mounted = new Map<string, Mounted>();
  readonly #grants: Set<string>;
  readonly #cleanupErrors: unknown[] = [];
  readonly #timeoutMs: number;
  #phase: 'new' | 'starting' | 'ready' | 'reloading' | 'failed' | 'closed' =
    'new';
  constructor(grants: readonly string[] = [], timeoutMs = 10000) {
    this.#grants = new Set(grants);
    this.#timeoutMs = timeoutMs;
  }
  get phase() {
    return this.#phase;
  }
  health(): PluginHealth[] {
    return [...this.#mounted.values()].map((x) => ({ ...x.health }));
  }
  stats() {
    return {
      plugins: this.#mounted.size,
      cordisRuntimes: this.#root.registry.size,
      leases: this.health().reduce((sum, p) => sum + p.leases, 0),
    };
  }
  service<K extends ServiceKey>(key: K): ServiceMap[K] {
    if (this.#phase !== 'ready')
      throw new ApplicationError('NOT_READY', `Kernel is ${this.#phase}`);
    const value = this.#root.reflect.get(key, false) as
      | ServiceMap[K]
      | undefined;
    if (value === undefined)
      throw new ApplicationError(
        'SERVICE_UNAVAILABLE',
        `Service '${key}' is not in this profile`,
      );
    return value;
  }
  async start(definitions: readonly PluginDefinition[]): Promise<void> {
    if (this.#phase !== 'new')
      throw new ApplicationError('LIFECYCLE', 'Kernel can only start once');
    const ordered = this.#order(definitions);
    this.#phase = 'starting';
    try {
      for (const definition of ordered) await this.#mount(definition, 1);
      this.#phase = 'ready';
    } catch (error) {
      this.#phase = 'failed';
      await this.#settle(this.#root.fiber.dispose(), 'startup rollback');
      throw error;
    }
  }
  async replace(id: string, next: PluginDefinition): Promise<void> {
    if (this.#phase !== 'ready')
      throw new ApplicationError('NOT_READY', `Kernel is ${this.#phase}`);
    const old = this.#mounted.get(id);
    if (!old || old.definition.manifest.reload !== 'idle')
      throw new ApplicationError(
        'RESTART_REQUIRED',
        `Plugin '${id}' requires restart`,
      );
    const before = old.definition.manifest,
      after = next.manifest;
    if (
      after.id !== id ||
      JSON.stringify({ ...before, version: '' }) !==
        JSON.stringify({ ...after, version: '' })
    ) {
      throw new ApplicationError(
        'INCOMPATIBLE_PLUGIN',
        'Replacement must preserve its manifest contracts',
      );
    }
    this.#order(
      [...this.#mounted.values()].map((x) => (x === old ? next : x.definition)),
    );
    // Global admission closes synchronously: a new run cannot race this idle check.
    this.#phase = 'reloading';
    if ([...this.#mounted.values()].some((x) => x.health.leases > 0)) {
      this.#phase = 'ready';
      throw new ApplicationError(
        'PLUGIN_BUSY',
        'Active operations must finish before replacement',
      );
    }
    try {
      await this.#settle(old.fiber.dispose(), `dispose ${id}`);
      if (this.#cleanupErrors.length)
        throw new ApplicationError(
          'CLEANUP_FAILED',
          'Plugin cleanup failed; replacement admission remains closed',
        );
      old.health.state = 'disposed';
      this.#mounted.delete(id);
      await this.#mount(next, old.health.generation + 1);
      for (const mounted of this.#mounted.values()) {
        await this.#settle(
          mounted.fiber.await(),
          `activate ${mounted.health.id}`,
        );
        mounted.health.state = 'active';
      }
      this.#phase = 'ready';
    } catch (error) {
      this.#phase = 'failed';
      throw error;
    }
  }
  async close(): Promise<void> {
    if (this.#phase === 'closed') return;
    this.#phase = 'closed';
    await this.#settle(this.#root.fiber.dispose(), 'kernel shutdown');
    for (const mounted of this.#mounted.values())
      if (mounted.health.state !== 'failed') mounted.health.state = 'disposed';
    if (this.#cleanupErrors.length)
      throw new AggregateError(this.#cleanupErrors, 'Plugin cleanup failed');
  }
  #order(definitions: readonly PluginDefinition[]): PluginDefinition[] {
    const ids = new Set<string>(),
      providers = new Map<ServiceKey, PluginDefinition>();
    for (const definition of definitions) {
      const m = definition.manifest;
      if (m.apiVersion !== 1)
        throw new ApplicationError(
          'API_VERSION',
          `Unsupported API for '${m.id}'`,
        );
      if (ids.has(m.id))
        throw new ApplicationError(
          'DUPLICATE_PLUGIN',
          `Duplicate plugin '${m.id}'`,
        );
      ids.add(m.id);
      for (const capability of m.capabilities)
        if (!this.#grants.has(capability))
          throw new ApplicationError(
            'CAPABILITY_DENIED',
            `${m.id}: '${capability}' was not granted`,
          );
      for (const key of m.provides) {
        if (providers.has(key))
          throw new ApplicationError(
            'DUPLICATE_SERVICE',
            `Duplicate service '${key}'`,
          );
        providers.set(key, definition);
      }
    }
    const result: PluginDefinition[] = [],
      visited = new Set<string>(),
      visiting = new Set<string>();
    const visit = (definition: PluginDefinition) => {
      const m = definition.manifest;
      if (visited.has(m.id)) return;
      if (visiting.has(m.id))
        throw new ApplicationError(
          'DEPENDENCY_CYCLE',
          `Dependency cycle at '${m.id}'`,
        );
      visiting.add(m.id);
      for (const key of [...m.requires, ...(m.live ?? [])]) {
        const provider = providers.get(key);
        if (!provider)
          throw new ApplicationError(
            'MISSING_DEPENDENCY',
            `${m.id} -> missing service '${key}'`,
          );
        visit(provider);
      }
      visiting.delete(m.id);
      visited.add(m.id);
      result.push(definition);
    };
    definitions.forEach(visit);
    return result;
  }
  async #mount(
    definition: PluginDefinition,
    generation: number,
  ): Promise<void> {
    const m = definition.manifest;
    const health: PluginHealth = {
      id: m.id,
      version: m.version,
      state: 'active',
      generation,
      leases: 0,
    };
    let activations = 0;
    const plugin = {
      name: m.id,
      inject: [...m.requires],
      apply: async (ctx: Context) => {
        let alive = true;
        ctx.effect(() => () => {
          alive = false;
        });
        const provided = new Set<ServiceKey>();
        const scope: PluginScope = {
          get: (key) => {
            if (!m.requires.includes(key))
              throw new ApplicationError(
                'UNDECLARED_SERVICE',
                `${m.id} did not require '${key}'`,
              );
            return ctx[key];
          },
          ref: (key) => {
            if (!m.live?.includes(key))
              throw new ApplicationError(
                'UNDECLARED_SERVICE',
                `${m.id} did not declare live '${key}'`,
              );
            return () => this.service(key);
          },
          provide: (key, value) => {
            if (!m.provides.includes(key) || provided.has(key))
              throw new ApplicationError(
                'UNDECLARED_SERVICE',
                `${m.id} cannot provide '${key}'`,
              );
            provided.add(key);
            ctx.provide(key, value);
          },
          onDispose: (cleanup) => {
            ctx.effect(() => async () => {
              health.state = 'disposed';
              try {
                await cleanup();
              } catch (error) {
                health.state = 'failed';
                this.#cleanupErrors.push(error);
                throw error;
              }
            });
          },
          lease: () => {
            if (
              !alive ||
              ctx.fiber.state !== FiberState.ACTIVE ||
              this.#phase !== 'ready' ||
              health.state !== 'active'
            )
              throw new ApplicationError(
                'NOT_READY',
                'Plugin admission is closed or this handle belongs to a disposed generation',
              );
            health.leases++;
            let released = false;
            return () => {
              if (!released) {
                released = true;
                health.leases--;
              }
            };
          },
        };
        health.state = 'active';
        health.generation = generation + activations++;
        await definition.activate(scope);
        for (const key of m.provides)
          if (!provided.has(key))
            throw new ApplicationError(
              'MISSING_PROVISION',
              `${m.id} did not provide '${key}'`,
            );
      },
    };
    const fiber = this.#root.plugin(plugin);
    this.#mounted.set(m.id, { definition, fiber, health });
    try {
      await this.#settle(fiber.await(), `activate ${m.id}`);
      if (fiber.state !== FiberState.ACTIVE)
        throw new ApplicationError(
          'PLUGIN_NOT_READY',
          `${m.id} remained inactive`,
        );
    } catch (error) {
      health.state = 'failed';
      throw error;
    }
  }
  async #settle<T>(task: Promise<T>, label: string): Promise<T> {
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([
        task,
        new Promise<never>((_, reject) => {
          timer = setTimeout(
            () =>
              reject(
                new ApplicationError(
                  'LIFECYCLE_TIMEOUT',
                  `${label} exceeded ${this.#timeoutMs}ms; process restart may be required`,
                ),
              ),
            this.#timeoutMs,
          );
        }),
      ]);
    } finally {
      clearTimeout(timer);
    }
  }
}
