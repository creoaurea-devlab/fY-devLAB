import { DatabaseSync } from 'node:sqlite';
import { mkdir, realpath, lstat, chmod } from 'node:fs/promises';
import { join } from 'node:path';
import {
  ApplicationError,
  CanvasDocumentSchema,
  ProjectIdSchema,
  SaveCanvasSchema,
  canonicalJson,
  type CanvasDocument,
  type PluginDefinition,
} from '@devlab/contracts';

/** Local, transactional graph adapter; no renderer or run-store implementation import. */
export function canvasStore(directory: string): PluginDefinition {
  return {
    manifest: {
      id: 'canvas-store',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['canvas'],
      requires: [],
      capabilities: ['storage:local'],
      reload: 'restart',
    },
    async activate(scope) {
      await mkdir(directory, { recursive: true, mode: 0o700 });
      const file = join(await realpath(directory), 'canvas.sqlite');
      const info = await lstat(file).catch((error: NodeJS.ErrnoException) => {
        if (error.code !== 'ENOENT') throw error;
        return null;
      });
      if (info?.isSymbolicLink())
        throw new ApplicationError(
          'PATH_DENIED',
          'Canvas database cannot be a symlink',
        );
      const db = new DatabaseSync(file);
      let active = true;
      scope.onDispose(() => {
        active = false;
        db.close();
      });
      await chmod(file, 0o600);
      db.exec(
        'PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA busy_timeout=1000; CREATE TABLE IF NOT EXISTS graphs(project_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, graph TEXT NOT NULL)',
      );
      const read = db.prepare(
        'SELECT revision,graph FROM graphs WHERE project_id=?',
      );
      const write = db.prepare(
        'INSERT INTO graphs(project_id,revision,graph) VALUES(?,?,?) ON CONFLICT(project_id) DO UPDATE SET revision=excluded.revision,graph=excluded.graph',
      );
      const ready = () => {
        if (!active)
          throw new ApplicationError('NOT_READY', 'Canvas store is closed');
      };
      scope.provide('canvas', {
        async load(id) {
          ready();
          const projectId = ProjectIdSchema.parse(id);
          const row = read.get(projectId);
          return row
            ? CanvasDocumentSchema.parse({
                schemaVersion: 1,
                projectId,
                revision: row.revision,
                graph: JSON.parse(String(row.graph)),
              })
            : null;
        },
        async save(input) {
          ready();
          const command = SaveCanvasSchema.parse(input);
          const json = canonicalJson(command.graph);
          if (Buffer.byteLength(json) > 2 * 1024 * 1024)
            throw new ApplicationError(
              'PAYLOAD_TOO_LARGE',
              'Canvas graph exceeds 2 MiB',
            );
          db.exec('BEGIN IMMEDIATE');
          try {
            const row = read.get(command.projectId);
            const revision = Number(row?.revision ?? 0);
            if (revision !== command.expectedRevision)
              throw new ApplicationError(
                'REVISION_CONFLICT',
                'Canvas changed in another window. Reload the saved graph before saving again.',
              );
            const next: CanvasDocument = {
              schemaVersion: 1,
              projectId: command.projectId,
              revision: revision + 1,
              graph: command.graph,
            };
            write.run(command.projectId, next.revision, json);
            db.exec('COMMIT');
            return next;
          } catch (error) {
            db.exec('ROLLBACK');
            throw error;
          }
        },
      });
    },
  };
}
