import { z } from 'zod';
import {
  ApplicationError,
  CreateProjectSchema,
  OpenProjectSchema,
  ProjectIdSchema,
  WriteProjectFileSchema,
  type ProjectCatalog,
  type WisdomTool,
  type ProjectServers,
} from '@devlab/contracts';
/** Project commands share the catalog identity; preparation is an owned capability. */
export async function projectRequest(
  path: string,
  method: string | undefined,
  url: URL,
  body: (limit?: number) => Promise<unknown>,
  projects: ProjectCatalog | undefined,
  wisdom?: WisdomTool,
  servers?: ProjectServers,
): Promise<{ status: number; value: unknown }> {
  if (!projects)
    throw new ApplicationError(
      'SERVICE_UNAVAILABLE',
      'Projects are unavailable',
    );
  const parts = path.split('/').filter(Boolean),
    id = parts[2];
  if (parts.length === 2 && method === 'GET')
    return { status: 200, value: await projects.list() };
  if (parts.length === 2 && method === 'POST') {
    const created = await projects.create(
      CreateProjectSchema.parse(await body()),
    );
    if (wisdom)
      try {
        const proposal = await wisdom.plan(created.id);
        await wisdom.apply(created.id, proposal.sha256);
      } catch (error) {
        throw new ApplicationError(
          'PREPARATION_FAILED',
          `Project ${created.id} was created; preparation stopped: ${String(error)}`,
        );
      }
    if (servers && wisdom) void servers.start(created.id).catch(() => {});
    return { status: 201, value: created };
  }
  if (path === '/api/projects/open' && method === 'POST')
    return {
      status: 200,
      value: await projects.open(OpenProjectSchema.parse(await body())),
    };
  if (!id) throw new ApplicationError('NOT_FOUND', 'Project command not found');
  ProjectIdSchema.parse(id);
  if (parts.length === 4 && parts[3] === 'forget' && method === 'POST') {
    z.object({})
      .strict()
      .parse(await body());
    await projects.forget(id);
    return { status: 200, value: { ok: true } };
  }
  if (parts.length === 4 && parts[3] === 'files' && method === 'GET')
    return { status: 200, value: await projects.inspect(id) };
  if (parts.length === 4 && parts[3] === 'file' && method === 'GET')
    return {
      status: 200,
      value: await projects.read(
        id,
        z.string().min(1).max(512).parse(url.searchParams.get('path')),
      ),
    };
  if (parts.length === 4 && parts[3] === 'file' && method === 'POST')
    return {
      status: 200,
      value: await projects.write(
        WriteProjectFileSchema.parse({
          ...z
            .object({
              path: z.string(),
              text: z.string(),
              expectedHash: z.string().nullable(),
            })
            .strict()
            .parse(await body(300000)),
          projectId: id,
        }),
      ),
    };
  if (parts.length === 4 && parts[3] === 'module' && method === 'POST')
    return {
      status: 201,
      value: await projects.createModule(
        id,
        z
          .object({ path: z.string().min(1).max(512) })
          .strict()
          .parse(await body()).path,
      ),
    };
  if (parts[3] === 'wisdom') {
    if (!wisdom)
      throw new ApplicationError(
        'SERVICE_UNAVAILABLE',
        'Wisdom tool is unavailable',
      );
    if (parts.length === 4 && method === 'GET')
      return { status: 200, value: await wisdom.inspect(id) };
    if (parts.length === 5 && method === 'POST' && parts[4] === 'plan') {
      const input = z
        .object({ previewOnly: z.boolean().optional() })
        .strict()
        .parse(await body());
      return { status: 200, value: await wisdom.plan(id, input) };
    }
    if (parts.length === 5 && method === 'POST' && parts[4] === 'apply') {
      const input = z
        .object({ sha256: z.string().regex(/^[a-f0-9]{64}$/) })
        .strict()
        .parse(await body());
      return { status: 200, value: await wisdom.apply(id, input.sha256) };
    }
  }
  throw new ApplicationError('NOT_FOUND', 'Project command not found');
}
