import { projectRequest } from './projects.ts';
import { serverRequest } from './servers.ts';
import { browserRequest } from './browser.ts';
import { serveHoodRequest } from '@creoaurea/pop-the-hood/http';
import {
  createServer,
  type IncomingMessage,
  type ServerResponse,
} from 'node:http';
import { readFile, realpath } from 'node:fs/promises';
import { resolve, sep, extname } from 'node:path';
import { z } from 'zod';
import {
  ApplicationError,
  PlanCommandSchema,
  PreviewNativeTargetSchema,
  StartCommandSchema,
  SaveCanvasSchema,
  ProjectIdSchema,
  TerminalCreateSchema,
  TerminalInputSchema,
  TerminalSizeSchema,
  type PluginDefinition,
  type PluginHealth,
} from '@devlab/contracts';

interface Options {
  port: number;
  canvas?: boolean;
  projects?: boolean;
  wisdom?: boolean;
  planning?: boolean;
  servers?: boolean;
  terminals?: boolean;
  browsers?: boolean;
  architecture?: boolean;
  webRoot?: string;
  allowedOrigins?: string[];
  diagnostics: () => { phase: string; plugins: PluginHealth[] };
  replaceModel: (uppercase: boolean) => Promise<void>;
}
async function body(request: IncomingMessage, limit = 8192): Promise<unknown> {
  if (!request.headers['content-type']?.startsWith('application/json'))
    throw new ApplicationError('INVALID_INPUT', 'Expected application/json');
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of request) {
    const data = Buffer.from(chunk);
    size += data.length;
    if (size > limit)
      throw new ApplicationError(
        'PAYLOAD_TOO_LARGE',
        `Maximum body size is ${limit} bytes`,
      );
    chunks.push(data);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString());
  } catch {
    throw new ApplicationError('INVALID_INPUT', 'Invalid JSON');
  }
}
function json(response: ServerResponse, status: number, value: unknown) {
  response.writeHead(status, {
    'content-type': 'application/json',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  });
  response.end(JSON.stringify(value));
}

export function httpTransport(options: Options): PluginDefinition {
  return {
    manifest: {
      id: 'transport-http',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['http'],
      requires: [
        ...(options.canvas ? ['canvas' as const] : []),
        ...(options.projects ? ['projects' as const] : []),
        ...(options.wisdom ? ['wisdom' as const] : []),
        ...(options.planning ? ['planning' as const] : []),
        ...(options.servers ? ['servers' as const, 'previewInspector' as const] : []),
        ...(options.terminals ? ['terminals' as const] : []),
        ...(options.browsers ? ['browserControl' as const] : []),
        ...(options.architecture ? ['architecture' as const] : []),
      ],
      live: ['runs'],
      capabilities: ['network:loopback'],
      reload: 'restart',
    },
    async activate(scope) {
      const runs = scope.ref('runs');
      const inspector = options.servers ? scope.get('previewInspector') : undefined;
      const servers = options.servers ? scope.get('servers') : undefined;
      const wisdom = options.wisdom ? scope.get('wisdom') : undefined;
      const planning = options.planning ? scope.get('planning') : undefined;
      const projects = options.projects ? scope.get('projects') : undefined;
      const canvas = options.canvas ? scope.get('canvas') : undefined;
      const terminals = options.terminals ? scope.get('terminals') : undefined;
      const registry = options.architecture
        ? scope.get('architecture')
        : undefined;
      const browser = options.browsers ? scope.get('browserControl') : undefined;
      const streams = new Set<() => void>();
      const server = createServer((request, response) => {
        void (async () => {
          const origin = request.headers.origin;
          const address = server.address();
          const ownOrigin =
            typeof address === 'object' && address
              ? `http://127.0.0.1:${address.port}`
              : '';
          if (request.headers.host !== ownOrigin.slice('http://'.length))
            throw new ApplicationError('ORIGIN_DENIED', 'Host is not allowed');
          if (
            origin &&
            origin !== ownOrigin &&
            !options.allowedOrigins?.includes(origin)
          )
            throw new ApplicationError(
              'ORIGIN_DENIED',
              'Origin is not allowed',
            );
          const url = new URL(request.url ?? '/', 'http://127.0.0.1');
          if (request.method === 'GET' && url.pathname === '/api/health') {
            json(response, 200, options.diagnostics());
            return;
          }
          if (url.pathname === '/api/planning' || url.pathname === '/api/planning/command') {
            if (!planning) throw new ApplicationError('SERVICE_UNAVAILABLE','Planning capability is unavailable');
            if (url.pathname === '/api/planning' && request.method === 'GET') {
              const input = z.object({projectId:ProjectIdSchema}).strict().parse(Object.fromEntries(url.searchParams));
              json(response,200,await planning.snapshot(input.projectId)); return;
            }
            if (url.pathname === '/api/planning/command' && request.method === 'POST') { json(response,200,await planning.command(PlanCommandSchema.parse(await body(request))));return; }
            throw new ApplicationError('NOT_FOUND','Planning route not found');
          }
          if (url.pathname.startsWith('/api/preview/')) {
            if (!inspector || request.method !== 'POST') throw new ApplicationError('SERVICE_UNAVAILABLE','Native inspection is unavailable');
            if (url.pathname === '/api/preview/workspace') {
              const input=z.object({projectId:ProjectIdSchema,target:PreviewNativeTargetSchema.optional()}).strict().parse(await body(request));
              json(response,200,await inspector.openWorkspace(ownOrigin+'/',input.projectId,input.target));return;
            }
            const input=z.object({projectId:ProjectIdSchema,sessionId:z.string().uuid()}).strict().parse(await body(request));
            if(url.pathname === '/api/preview/devtools') { json(response,200,await inspector.openDevTools(input.sessionId,input.projectId));return; }
            if(url.pathname === '/api/preview/close') { await inspector.closeWorkspace(input.sessionId);json(response,200,{ok:true});return; }
            throw new ApplicationError('NOT_FOUND','Preview command not found');
          }
          if (url.pathname === '/api/servers' || url.pathname.startsWith('/api/servers/')) {
            json(response,200,await serverRequest(url.pathname,request.method,()=>body(request),servers));
            return;
          }
          if (url.pathname === '/api/browsers' || url.pathname.startsWith('/api/browsers/')) {
            json(response,200,await browserRequest(url.pathname,request.method,url,()=>body(request,100000),browser));
            return;
          }
          if (registry && await serveHoodRequest(request, response, registry, streams)) return;
          if (url.pathname === '/api/projects' || url.pathname.startsWith('/api/projects/')) {
            const result=await projectRequest(url.pathname,request.method,url,(limit)=>body(request,limit),projects,wisdom,servers);
            json(response,result.status,result.value);return;
          }

          if (
            url.pathname === '/api/terminals' ||
            url.pathname.startsWith('/api/terminals/')
          ) {
            if (!terminals)
              throw new ApplicationError(
                'SERVICE_UNAVAILABLE',
                'Terminal capability is not enabled',
              );
            if (url.pathname === '/api/terminals') {
              if (request.method === 'GET') {
                json(
                  response,
                  200,
                  terminals.list(
                    ProjectIdSchema.parse(url.searchParams.get('projectId')),
                  ),
                );
                return;
              }
              if (request.method === 'POST') {
                json(
                  response,
                  200,
                  await terminals.create(
                    TerminalCreateSchema.parse(await body(request)),
                  ),
                );
                return;
              }
            }
            const terminalMatch =
              /^\/api\/terminals\/([a-f0-9-]{36})(?:\/(input|resize|close|events))?$/.exec(
                url.pathname,
              );
            if (terminalMatch) {
              const id = z.string().uuid().parse(terminalMatch[1]);
              if (request.method === 'GET' && !terminalMatch[2]) {
                const after = z.coerce
                  .number()
                  .int()
                  .nonnegative()
                  .safe()
                  .parse(url.searchParams.get('after') ?? 0);
                json(response, 200, terminals.read(id, after));
                return;
              }
              if (request.method === 'GET' && terminalMatch[2] === 'events') {
                let after = z.coerce
                  .number()
                  .int()
                  .nonnegative()
                  .safe()
                  .parse(
                    request.headers['last-event-id'] ??
                      url.searchParams.get('after') ??
                      0,
                  );
                terminals.inspect(id);
                if (streams.size >= 64)
                  throw new ApplicationError(
                    'TERMINAL_LIMIT',
                    'Too many terminal streams',
                  );
                let disposed = false,
                  blocked = false;
                let blockTimer: ReturnType<typeof setTimeout> | undefined;
                let timer: ReturnType<typeof setInterval> | undefined;
                let unsubscribe = () => {};
                const cleanup = () => {
                  if (disposed) return;
                  disposed = true;
                  clearInterval(timer);
                  clearTimeout(blockTimer);
                  unsubscribe();
                  streams.delete(cleanup);
                  response.end();
                };
                const pump = () => {
                  if (disposed || blocked) return;
                  try {
                    const replay = terminals.read(id, after);
                    after = replay.session.cursor;
                    if (
                      !response.write(
                        `id: ${after}\nevent: terminal\ndata: ${JSON.stringify(replay)}\n\n`,
                      )
                    ) {
                      blocked = true;
                      blockTimer = setTimeout(() => {
                        response.destroy();
                        cleanup();
                      }, 5000);
                      response.once('drain', () => {
                        clearTimeout(blockTimer);
                        blocked = false;
                        pump();
                      });
                    }
                  } catch {
                    response.destroy();
                    cleanup();
                  }
                };
                // Subscribe before sending headers so observer-limit errors stay JSON.
                unsubscribe = terminals.subscribe(id, pump);
                response.writeHead(200, {
                  'content-type': 'text/event-stream',
                  'cache-control': 'no-store',
                  'x-accel-buffering': 'no',
                  'x-content-type-options': 'nosniff',
                });
                response.on('close', cleanup);
                streams.add(cleanup);
                timer = setInterval(() => {
                  if (blocked || disposed) return;
                  if (!response.write(': heartbeat\n\n')) {
                    response.destroy();
                    cleanup();
                  }
                }, 15000);
                timer.unref();
                pump();
                return;
              }
              if (request.method === 'POST') {
                if (terminalMatch[2] === 'input') {
                  terminals.write(
                    id,
                    TerminalInputSchema.parse(await body(request, 400000)).data,
                  );
                  json(response, 200, terminals.inspect(id));
                  return;
                }
                if (terminalMatch[2] === 'resize') {
                  terminals.resize(
                    id,
                    TerminalSizeSchema.parse(await body(request)),
                  );
                  json(response, 200, terminals.inspect(id));
                  return;
                }
                if (terminalMatch[2] === 'close') {
                  z.object({})
                    .strict()
                    .parse(await body(request));
                  json(response, 200, await terminals.close(id));
                  return;
                }
              }
            }
          }
          const graphMatch = /^\/api\/canvas\/([a-zA-Z0-9_-]+)$/.exec(
            url.pathname,
          );
          if (
            (request.method === 'GET' && graphMatch) ||
            (request.method === 'POST' && url.pathname === '/api/canvas')
          ) {
            if (!canvas)
              throw new ApplicationError(
                'SERVICE_UNAVAILABLE',
                'Canvas storage is not enabled in this profile',
              );
            if (request.method === 'GET')
              json(
                response,
                200,
                await canvas.load(ProjectIdSchema.parse(graphMatch![1])),
              );
            else
              json(
                response,
                200,
                await canvas.save(
                  SaveCanvasSchema.parse(await body(request, 2 * 1024 * 1024)),
                ),
              );
            return;
          }
          if (request.method === 'GET' && url.pathname === '/api/runs') {
            json(response, 200, await runs().list());
            return;
          }
          if (request.method === 'POST' && url.pathname === '/api/runs') {
            json(
              response,
              202,
              await runs().start(StartCommandSchema.parse(await body(request))),
            );
            return;
          }
          const match =
            /^\/api\/runs\/([a-f0-9-]{36})(?:\/(resume|cancel))?$/.exec(
              url.pathname,
            );
          if (match) {
            const id = z.string().uuid().parse(match[1]);
            if (request.method === 'GET' && !match[2]) {
              json(response, 200, await runs().inspect(id));
              return;
            }
            if (request.method === 'POST' && match[2]) {
              json(
                response,
                200,
                match[2] === 'resume'
                  ? await runs().resume(id)
                  : await runs().cancel(id),
              );
              return;
            }
          }
          if (request.method === 'POST' && url.pathname === '/api/model') {
            const input = z
              .object({ uppercase: z.boolean() })
              .strict()
              .parse(await body(request));
            await options.replaceModel(input.uppercase);
            json(response, 200, options.diagnostics());
            return;
          }
          if (
            request.method === 'GET' &&
            options.webRoot &&
            (url.pathname === '/' || url.pathname.startsWith('/assets/'))
          ) {
            const root = await realpath(options.webRoot);
            const candidate = resolve(
              root,
              url.pathname === '/'
                ? 'index.html'
                : `.${decodeURIComponent(url.pathname)}`,
            );
            if (!candidate.startsWith(root + sep))
              throw new ApplicationError('PATH_DENIED', 'Invalid asset path');
            const file = await realpath(candidate);
            if (!file.startsWith(root + sep))
              throw new ApplicationError(
                'PATH_DENIED',
                'Asset is outside web root',
              );
            const types: Record<string, string> = {
              '.html': 'text/html',
              '.js': 'text/javascript',
              '.css': 'text/css',
              '.svg': 'image/svg+xml',
            };
            response.writeHead(200, {
              'content-type':
                types[extname(file)] ?? 'application/octet-stream',
              'x-content-type-options': 'nosniff',
              'content-security-policy':
                "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-src 'self' http://127.0.0.1:* http://localhost:*; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
            });
            response.end(await readFile(file));
            return;
          }
          json(response, 404, {
            code: 'NOT_FOUND',
            message: 'Route not found',
          });
        })().catch((error: unknown) => {
          if (response.headersSent) {
            response.destroy();
            return;
          }
          const code =
            error instanceof ApplicationError
              ? error.code
              : error instanceof z.ZodError
                ? 'INVALID_INPUT'
                : typeof error === 'object' &&
                    error !== null &&
                    'code' in error &&
                    error.code === 'ENOENT'
                  ? 'NOT_FOUND'
                  : 'INTERNAL_ERROR';
          const status =
            code === 'RUN_NOT_FOUND' ||
            code === 'NOT_FOUND' ||
            code === 'TERMINAL_NOT_FOUND'
              ? 404
              : code === 'ORIGIN_DENIED' || code === 'PATH_DENIED'
                ? 403
                : code === 'PAYLOAD_TOO_LARGE'
                  ? 413
                  : code === 'INVALID_INPUT'
                    ? 400
                    : code === 'NOT_READY' || code === 'SERVICE_UNAVAILABLE'
                      ? 503
                      : code === 'INTERNAL_ERROR'
                        ? 500
                        : 409;
          json(response, status, {
            code,
            message: error instanceof Error ? error.message : 'Request failed',
          });
        });
      });
      scope.onDispose(
        () =>
          new Promise<void>((resolveClose, reject) => {
            for (const close of [...streams]) close();
            server.close((error) => (error ? reject(error) : resolveClose()));
            server.closeIdleConnections();
          }),
      );
      await new Promise<void>((ready, reject) => {
        server.once('error', reject);
        server.listen(options.port, '127.0.0.1', () => {
          server.removeListener('error', reject);
          ready();
        });
      });
      const address = server.address();
      if (!address || typeof address === 'string')
        throw new Error('Missing HTTP address');
      scope.provide('http', { url: `http://127.0.0.1:${address.port}` });
    },
  };
}
