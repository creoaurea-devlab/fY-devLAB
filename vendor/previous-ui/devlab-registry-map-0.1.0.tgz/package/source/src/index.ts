import { readFile, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import type { HoodHost } from '@creoaurea/pop-the-hood/node';
import {
  ApplicationError,
  RegistryArtifactSchema,
  RegistrySnapshotSchema,
  RegistryRuntimeSchema,
  canonicalJson,
  type PluginDefinition,
  type PluginManifest,
  type PluginHealth,
  type RegistryArtifact,
  type RegistryItem,
  type RegistryEdge,
} from '@devlab/contracts';

export function registryMap(options: {
  artifact: string;
  manifests: () => PluginManifest[];
  health: () => PluginHealth[];
  projectCatalog?: boolean;
  live?: { root: string; projectsRoot?: string };
}): PluginDefinition {
  return {
    manifest: {
      id: 'registry-map',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['architecture'],
      requires: options.projectCatalog ? ['projects'] : [],
      capabilities: options.live ? ['workspace:local'] : [],
      reload: 'restart',
    },
    async activate(scope) {
      if ((await stat(options.artifact)).size > 12 * 1024 * 1024)
        throw new Error('Architecture artifact exceeds 12 MiB');
      const artifact = RegistryArtifactSchema.parse(
        JSON.parse(await readFile(options.artifact, 'utf8')),
      );
      const { graph, channels, snapshotId } = artifact.catalog;
      const digest = createHash('sha256')
        .update(canonicalJson({ graph, channels, sources: artifact.sources }))
        .digest('hex');
      if (digest !== snapshotId)
        throw new Error('Architecture artifact digest mismatch');
      let alive = true;
      scope.onDispose(() => {
        alive = false;
      });
      const active = () => {
        if (!alive)
          throw new ApplicationError(
            'NOT_READY',
            'Registry snapshot is disposed',
          );
      };
      const runtime = (value: RegistryArtifact) => {
        const health = new Map(options.health().map(h => [h.id, h]));
        const plugins = options.manifests().map(m => ({
          id: m.id, version: m.version, provides: [...m.provides], requires: [...m.requires],
          live: [...(m.live ?? [])], capabilities: [...m.capabilities], reload: m.reload,
          state: health.get(m.id)?.state ?? 'unknown', generation: health.get(m.id)?.generation ?? 0, leases: health.get(m.id)?.leases ?? 0,
        }));
        return RegistryRuntimeSchema.parse({ plugins, wiring: buildWiring(value, plugins) });
      };
      let observer: HoodHost | undefined;
      if (options.live) {
        // Loading a compiler is an explicit live-mode choice; static releases skip this branch.
        const [{ createHood }, { analyzeProject }, { buildRegistry }] = await Promise.all([
          import('@creoaurea/pop-the-hood/node'), import('@creoaurea/pop-the-hood/analyzer'), import('../build/snapshot.ts'),
        ]);
        observer = await createHood({ ...options.live, label: 'devLAB',
          ...(options.projectCatalog ? { projectRoots: async () => {
            const service = scope.get('projects');
            const roots = [];
            for (const p of await service.list()) {
              if (p.available === false) continue;
              try { roots.push({ id: p.id === 'default' ? 'workspace' : p.id, root: await service.root(p.id), label: p.label }); }
              catch { /* Root may disappear during discovery; other projects remain usable. */ }
            }
            return roots;
          } } : {}),
          analyze: (root, id) => id === 'workspace' ? buildRegistry(root) : analyzeProject(root),
          runtime: (value, id) => id === 'workspace' ? runtime(value) : undefined,
        });
        scope.onDispose(() => observer!.close());
      }
      scope.provide('architecture', {
        snapshot(projectId = 'workspace') {
          active();
          if (observer) return observer.snapshot(projectId);
          if (projectId !== 'workspace') throw new ApplicationError('NOT_FOUND', 'Project has no built Hood');
          return RegistrySnapshotSchema.parse({ catalog: artifact.catalog, ...runtime(artifact) });
        },
        source(path, projectId = 'workspace') {
          active();
          if (observer) return observer.source(path, projectId).catch(error => { throw new ApplicationError('PATH_DENIED', String(error)); });
          if (projectId !== 'workspace') throw new ApplicationError('NOT_FOUND', 'Project has no built Hood');
          const file = graph.items.find(i => i.kind === 'file' && i.path === path);
          if (!file || !Object.hasOwn(artifact.sources, path)) throw new ApplicationError('PATH_DENIED', 'Source path is not in the built registry');
          return { path, sha256: file.sha256!, text: artifact.sources[path]! };
        },
        projects: () => { active(); return observer?.projects() ?? Promise.resolve([{ id: 'workspace', label: 'devLAB · built snapshot' }]); },
        ...(observer ? { subscribe: (id: string, receive: Parameters<HoodHost['subscribe']>[1]) => { active(); return observer!.subscribe(id, receive); } } : {}),
      });
    },
  };
}

function buildWiring(
  artifact: RegistryArtifact,
  plugins: {
    id: string;
    provides: string[];
    requires: string[];
    live: string[];
    state: string;
    version: string;
  }[],
) {
  const items: RegistryItem[] = [],
    edges: RegistryEdge[] = [],
    known = new Set<string>();
  const add = (i: RegistryItem) => {
    if (!known.has(i.id)) {
      known.add(i.id);
      items.push(i);
    }
  };
  for (const [id, label] of [
    ['plugins', 'Backend plugins'],
    ['services', 'Service contracts'],
    ['ipc', 'IPC / transport'],
    ['ui', 'UI registry'],
  ])
    add({
      id: 'wiring:' + id,
      label: label!,
      kind: 'group',
      parentId: null,
      detail: 'Expand to inspect declared wiring',
    });
  const proof = (path: string, needle: string) => {
    const text = artifact.sources[path];
    if (!text) return [];
    const index = text.indexOf(needle);
    if (index < 0) return [];
    const line = text.slice(0, index).split('\n').length;
    return [
      { path, line, text: text.split('\n')[line - 1]!.trim().slice(0, 500) },
    ];
  };
  const service = (name: string) =>
    add({
      id: 'service:' + name,
      label: name,
      kind: 'service',
      parentId: 'wiring:services',
      path: 'packages/contracts/src/index.ts',
      detail:
        name === 'kernel'
          ? 'Composition diagnostic callback'
          : plugins.some((p) => p.provides.includes(name))
            ? 'Provided in this profile'
            : 'Not provided in this profile',
    });
  const wire = (
    source: string,
    target: string,
    kind: RegistryEdge['kind'],
    label: string,
    evidence: RegistryEdge['evidence'],
  ) =>
    edges.push({
      id: `${kind}:${source}:${target}`,
      source,
      target,
      kind,
      label,
      evidence,
    });
  for (const p of plugins) {
    const path = `plugins/${p.id}/src/index.ts`;
    add({
      id: 'plugin:' + p.id,
      label: p.id,
      kind: 'plugin',
      parentId: 'wiring:plugins',
      ...(artifact.sources[path] ? { path } : {}),
      detail: `${p.state} · v${p.version}`,
    });
    for (const name of p.provides) {
      service(name);
      wire(
        'plugin:' + p.id,
        'service:' + name,
        'provides',
        `provides ${name}`,
        proof(path, 'provides:'),
      );
    }
    for (const name of p.requires) {
      service(name);
      wire(
        'service:' + name,
        'plugin:' + p.id,
        'requires',
        `requires ${name}`,
        proof(path, 'requires:'),
      );
    }
    for (const name of p.live) {
      service(name);
      wire(
        'service:' + name,
        'plugin:' + p.id,
        'live',
        `live ref ${name}`,
        proof(path, 'live:'),
      );
    }
  }
  add({
    id: 'client:web',
    label: 'Web command client',
    kind: 'client',
    parentId: 'wiring:ipc',
    path: 'apps/web/src/client.ts',
    detail: 'Validated fetch / EventSource adapters',
  });
  add({
    id: 'worker:store-sqlite',
    label: 'SQLite journal worker',
    kind: 'worker',
    parentId: 'wiring:ipc',
    path: 'plugins/store-sqlite/src/worker.ts',
    detail: 'Dedicated worker thread · request IDs',
  });
  for (const c of artifact.catalog.channels) {
    const name = c.service === 'registry' ? 'architecture' : c.service;
    if (name) service(name);
    if (!known.has(c.from) || !known.has(c.to)) continue;
    add({
      id: c.id,
      label: c.title,
      kind: 'channel',
      parentId: 'wiring:ipc',
      path: c.evidence[0]!.path,
      line: c.evidence[0]!.line,
      detail: `${c.protocol} · ${c.direction} · declared topology`,
    });
    wire(c.from, c.id, 'ipc', c.protocol + ' request', c.evidence);
    wire(
      c.id,
      c.direction === 'stream' ? c.to : name ? 'service:' + name : c.to,
      'ipc',
      c.direction === 'stream' ? 'output stream' : c.response,
      c.evidence,
    );
    if (c.protocol === 'HTTP')
      wire('plugin:transport-http', c.id, 'contains', 'handler', c.evidence);
  }
  for (const file of artifact.catalog.graph.items.filter(
    (i) =>
      i.kind === 'file' &&
      /^plugins\/ui-[^/]+\/src\/index\.ts$/.test(i.path ?? ''),
  )) {
    const source = artifact.sources[file.path!]!,
      id = /\bid:\s*['"]([^'"]+)['"]/.exec(source)?.[1],
      slot = /\bslot:\s*['"]([^'"]+)['"]/.exec(source)?.[1] ?? 'panel';
    if (!id) continue;
    add({
      id: 'ui:' + id,
      label: id,
      kind: 'ui',
      parentId: 'wiring:ui',
      path: file.path,
      detail: `${slot} slot · build declaration`,
    });
    wire(
      'client:web',
      'ui:' + id,
      'ui',
      slot + ' contribution',
      proof(file.path!, 'id:'),
    );
  }
  return { items, edges };
}
