import { randomUUID } from 'node:crypto';
import {
  ApplicationError,
  canonicalJson,
  ModelReplySchema,
  StartCommandSchema,
  ToolResultSchema,
  type EventInput,
  type Journal,
  type PluginDefinition,
  type RunController,
  type RunSnapshot,
  type ToolRequest,
  type ToolResult,
} from '@devlab/contracts';

interface Active {
  abort: AbortController;
  done: Promise<void>;
}
function snapshot(journal: Journal, active: boolean): RunSnapshot {
  const result: RunSnapshot = {
    ...journal,
    status: active ? 'running' : 'interrupted',
  };
  for (const { input } of journal.events) {
    if (input.type === 'run.completed') {
      result.status = 'completed';
      result.output = input.data.output;
    }
    if (input.type === 'run.failed') {
      result.status = 'failed';
      result.error = input.data.error;
    }
    if (input.type === 'run.cancelled') result.status = 'cancelled';
    if (input.type === 'run.reconciliation-required') {
      result.status = 'reconciliation-required';
      result.error = input.data.reason;
    }
  }
  return result;
}
function terminal(run: RunSnapshot) {
  return [
    'completed',
    'failed',
    'cancelled',
    'reconciliation-required',
  ].includes(run.status);
}

export function runController(): PluginDefinition {
  return {
    manifest: {
      id: 'run-controller',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['runs'],
      requires: ['store', 'model', 'tools', 'policy'],
      capabilities: [],
      reload: 'restart',
    },
    activate(scope) {
      const store = scope.get('store'),
        model = scope.get('model'),
        tools = scope.get('tools'),
        policy = scope.get('policy');
      const active = new Map<string, Active>();
      const inFlight = new Set<Promise<unknown>>();
      let closing = false;
      function tracked<T>(fn: () => Promise<T>): Promise<T> {
        if (closing)
          return Promise.reject(
            new ApplicationError(
              'NOT_READY',
              'Run controller is shutting down',
            ),
          );
        const task = fn();
        inFlight.add(task);
        void task.finally(() => inFlight.delete(task)).catch(() => {});
        return task;
      }
      const inspect = async (id: string) =>
        snapshot(await store.read(id), active.has(id));
      const leased = <T>(fn: () => Promise<T>) =>
        tracked(async () => {
          const release = scope.lease();
          try {
            return await fn();
          } finally {
            release();
          }
        });

      async function execute(
        initial: Journal,
        abort: AbortController,
      ): Promise<void> {
        let journal = initial;
        const commit = async (input: EventInput) => {
          journal = await store.append(
            journal.runId,
            journal.events.length,
            input,
          );
        };
        const signal = abort.signal;
        let dispatched: ToolRequest | undefined;
        try {
          const completed = new Set(
            journal.events.flatMap((e) =>
              e.input.type === 'operation.completed'
                ? [e.input.data.operationId]
                : [],
            ),
          );
          const unresolved = journal.events.find(
            (e) =>
              e.input.type === 'operation.dispatched' &&
              !completed.has(e.input.data.operationId),
          );
          if (unresolved?.input.type === 'operation.dispatched') {
            await commit({
              type: 'run.reconciliation-required',
              data: {
                operationId: unresolved.input.data.operationId,
                reason:
                  'Operation was dispatched without a durable outcome. It will not be repeated automatically.',
              },
            });
            return;
          }
          await commit({ type: 'run.started', data: {} });
          let previous: ToolResult | undefined;
          for (const event of journal.events)
            if (event.input.type === 'operation.completed')
              previous = event.input.data.result;
          // A persisted model proposal is replayed; token streaming is not authoritative.
          let reply = [...journal.events]
            .reverse()
            .find((e) => e.input.type === 'model.completed')?.input;
          if (
            !reply ||
            reply.type !== 'model.completed' ||
            (previous && reply.data.kind === 'tool')
          ) {
            const data = ModelReplySchema.parse(
              await model.complete({
                prompt: journal.command.prompt,
                previous,
                signal,
              }),
            );
            await commit({ type: 'model.completed', data });
            reply = { type: 'model.completed', data };
          }
          if (reply.type !== 'model.completed')
            throw new Error('Missing model reply');
          if (previous && reply.data.kind === 'tool')
            throw new ApplicationError(
              'MODEL_PROTOCOL',
              'Foundation model must finish after one tool',
            );
          if (reply.data.kind === 'tool') {
            signal.throwIfAborted();
            const existing = [...journal.events]
              .reverse()
              .find((e) => e.input.type === 'operation.intent');
            const request: ToolRequest =
              existing?.input.type === 'operation.intent'
                ? existing.input.data
                : {
                    operationId: randomUUID(),
                    attemptId: randomUUID(),
                    runId: journal.runId,
                    projectId: journal.command.projectId,
                    tool: reply.data.tool,
                    args: reply.data.args,
                  };
            const decision = await policy.authorize(request);
            if (!decision.allowed)
              throw new ApplicationError('POLICY_DENIED', decision.reason);
            if (
              canonicalJson(decision.authorized.request) !==
              canonicalJson(request)
            )
              throw new ApplicationError(
                'AUTHORIZATION_MISMATCH',
                'Policy changed the normalized tool request',
              );
            if (!existing)
              await commit({ type: 'operation.intent', data: request });
            signal.throwIfAborted();
            await commit({
              type: 'operation.dispatched',
              data: {
                operationId: request.operationId,
                attemptId: request.attemptId,
              },
            });
            dispatched = request;
            const result = ToolResultSchema.parse(
              await tools.execute(decision.authorized, signal),
            );
            await commit({
              type: 'operation.completed',
              data: { operationId: request.operationId, result },
            });
            dispatched = undefined;
            signal.throwIfAborted();
            const final = ModelReplySchema.parse(
              await model.complete({
                prompt: journal.command.prompt,
                previous: result,
                signal,
              }),
            );
            await commit({ type: 'model.completed', data: final });
            if (final.kind !== 'final')
              throw new ApplicationError(
                'MODEL_PROTOCOL',
                'Foundation model must finish after one tool',
              );
            await commit({
              type: 'run.completed',
              data: { output: final.text },
            });
          } else {
            signal.throwIfAborted();
            await commit({
              type: 'run.completed',
              data: { output: reply.data.text },
            });
          }
        } catch (error) {
          if (dispatched)
            await commit({
              type: 'run.reconciliation-required',
              data: {
                operationId: dispatched.operationId,
                reason:
                  'Tool outcome is unknown; explicit reconciliation is required.',
              },
            });
          else if (signal.aborted)
            await commit({
              type: 'run.cancelled',
              data: {
                reason: 'Cancellation acknowledged after owned work settled',
              },
            });
          else
            await commit({
              type: 'run.failed',
              data: {
                error: error instanceof Error ? error.message : String(error),
              },
            });
        }
      }
      function launch(journal: Journal, release: () => void): void {
        const abort = new AbortController();
        const entry: Active = { abort, done: Promise.resolve() };
        active.set(journal.runId, entry);
        entry.done = execute(journal, abort).finally(() => {
          active.delete(journal.runId);
          release();
        });
        // Retain failure for the waiter without an unhandled rejection; inspection still rejects store errors.
        void entry.done.catch((error) =>
          console.error('[run-controller] journal failure', error),
        );
      }
      const runs: RunController = {
        start: (raw) =>
          tracked(async () => {
            const release = scope.lease();
            try {
              const journal = await store.create(StartCommandSchema.parse(raw));
              if (closing)
                throw new ApplicationError(
                  'NOT_READY',
                  'Run controller is shutting down',
                );
              if (
                active.has(journal.runId) ||
                terminal(snapshot(journal, false))
              ) {
                release();
                return snapshot(journal, active.has(journal.runId));
              }
              launch(journal, release);
              return snapshot(journal, true);
            } catch (error) {
              release();
              throw error;
            }
          }),
        inspect: (id) => leased(() => inspect(id)),
        list: () =>
          leased(async () =>
            (await store.list()).map((j) => snapshot(j, active.has(j.runId))),
          ),
        resume: (id) =>
          tracked(async () => {
            const release = scope.lease();
            try {
              const journal = await store.read(id),
                state = snapshot(journal, active.has(id));
              if (closing)
                throw new ApplicationError(
                  'NOT_READY',
                  'Run controller is shutting down',
                );
              if (active.has(id) || state.status === 'completed') {
                release();
                return state;
              }
              if (terminal(state))
                throw new ApplicationError(
                  'RUN_NOT_RESUMABLE',
                  `Run is ${state.status}`,
                );
              launch(journal, release);
              return snapshot(journal, true);
            } catch (error) {
              release();
              throw error;
            }
          }),
        cancel: (id) =>
          leased(async () => {
            const task = active.get(id);
            if (task) {
              task.abort.abort();
              await task.done;
              return inspect(id);
            }
            const journal = await store.read(id);
            if (terminal(snapshot(journal, false)))
              return snapshot(journal, false);
            const done = new Set(
              journal.events.flatMap((e) =>
                e.input.type === 'operation.completed'
                  ? [e.input.data.operationId]
                  : [],
              ),
            );
            const unknown = journal.events.find(
              (e) =>
                e.input.type === 'operation.dispatched' &&
                !done.has(e.input.data.operationId),
            );
            const input: EventInput =
              unknown?.input.type === 'operation.dispatched'
                ? {
                    type: 'run.reconciliation-required',
                    data: {
                      operationId: unknown.input.data.operationId,
                      reason: 'Cannot cancel away an unknown external outcome',
                    },
                  }
                : {
                    type: 'run.cancelled',
                    data: { reason: 'Cancelled while inactive' },
                  };
            return snapshot(
              await store.append(id, journal.events.length, input),
              false,
            );
          }),
      };
      scope.onDispose(async () => {
        closing = true;
        for (const task of active.values()) task.abort.abort();
        await Promise.allSettled([...inFlight]);
        for (const task of active.values()) task.abort.abort();
        await Promise.all([...active.values()].map((t) => t.done));
      });
      scope.provide('runs', runs);
    },
  };
}
