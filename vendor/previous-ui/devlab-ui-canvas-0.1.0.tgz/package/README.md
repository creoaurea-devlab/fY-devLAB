# @devlab/ui-canvas

Local reusable copy of `plugins/ui-canvas`. Node 24.18+; see the bundle README for Linux/native limits and composition.

Install through the containing bundle installer so all unpublished local dependencies resolve together.

Exports: `@devlab/ui-canvas`, `@devlab/ui-canvas/view`, `@devlab/ui-canvas/workspace`, `@devlab/ui-canvas/style.css`.

Import `@devlab/ui-canvas/style.css` once in your browser entry. Third-party stylesheet imports remain explicit.

Backend factories return the existing PluginDefinition; select them in your host profile and grant the required capabilities. React contributions need an ApplicationClient and their existing workspace owners. UI detach does not stop backend resources. Source and provenance are included; no additional license grant or new product behavior is implied.
