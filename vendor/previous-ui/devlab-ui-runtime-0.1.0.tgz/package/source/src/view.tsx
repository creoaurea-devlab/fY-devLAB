import { useEffect, useState } from 'react';
import type { RunSnapshot } from '@devlab/contracts';
import type { UIPluginProps } from '@devlab/ui-contracts';

export function RuntimePanel({ client, draft, setDraft }: UIPluginProps) {
  const [runs, setRuns] = useState<RunSnapshot[]>([]),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    let live = true,
      inFlight = false;
    const refresh = async () => {
      if (inFlight) return;
      inFlight = true;
      try {
        const result = await client.list();
        if (live) {
          setRuns(result);
          setError('');
        }
      } catch (e) {
        if (live) setError(e instanceof Error ? e.message : String(e));
      } finally {
        inFlight = false;
      }
    };
    void refresh();
    const timer = setInterval(() => void refresh(), 700);
    return () => {
      live = false;
      clearInterval(timer);
    };
  }, [client]);
  const action = async (fn: () => Promise<unknown>) => {
    setBusy(true);
    setError('');
    try {
      await fn();
      setRuns(await client.list());
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="panel runtime">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">OFFLINE EXECUTION</p>
          <h2>A run, from intent to result.</h2>
        </div>
        <span className="tag">No API key needed</span>
      </div>
      <p className="muted">
        A deterministic model calls one echo tool. Your run history stays
        available after a restart.
      </p>
      <form
        onSubmit={(event) => {
          event.preventDefault();
          void action(() =>
            client.start({
              commandId: crypto.randomUUID(),
              projectId: 'local',
              sessionId: 'workbench',
              prompt: draft,
            }),
          );
        }}
      >
        <label htmlFor="prompt">Give the echo agent a message</label>
        <textarea
          id="prompt"
          value={draft}
          maxLength={2000}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="What should this small agent echo?"
        />
        <div className="form-footer">
          <span className="muted small">Drafts belong to the shell.</span>
          <button className="primary" disabled={busy || !draft.trim()}>
            Run locally <span aria-hidden>↗</span>
          </button>
        </div>
      </form>
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}
      <div className="section-title">
        <h3>Recent runs</h3>
        <span>{runs.length.toString().padStart(2, '0')}</span>
      </div>
      {!runs.length ? (
        <div className="empty">
          Your first run starts here.
          <span>
            Write a message above to exercise the complete plugin chain.
          </span>
        </div>
      ) : (
        <div className="run-list">
          {runs.map((run) => (
            <article className="run-card" key={run.runId}>
              <div className="run-heading">
                <span className={`status ${run.status}`}>{run.status}</span>
                <span className="small muted">
                  {run.events.length} committed events
                </span>
              </div>
              <h4>{run.command.prompt}</h4>
              {run.output && <pre>{run.output}</pre>}
              {run.error && <p className="error">{run.error}</p>}
              <div className="run-footer">
                <code title={run.runId}>{run.runId.slice(0, 8)}</code>
                {run.status === 'running' && (
                  <button
                    disabled={busy}
                    onClick={() => void action(() => client.cancel(run.runId))}
                  >
                    Cancel
                  </button>
                )}
                {run.status === 'interrupted' && (
                  <button
                    disabled={busy}
                    onClick={() => void action(() => client.resume(run.runId))}
                  >
                    Resume
                  </button>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
