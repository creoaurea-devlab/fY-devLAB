import type { UIPlugin } from '@devlab/ui-contracts';
import { RuntimePanel } from './view.tsx';
export const runtimePanel: UIPlugin = {
  id: 'ui-runtime',
  apiVersion: 1,
  title: 'Run workbench',
  Component: RuntimePanel,
};
