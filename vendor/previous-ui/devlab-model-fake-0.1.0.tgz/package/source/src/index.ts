import { type PluginDefinition, type ModelProvider } from '@devlab/contracts';
import { setTimeout } from 'node:timers/promises';

export function fakeModel(
  options: { uppercase?: boolean; delayMs?: number } = {},
): PluginDefinition {
  return {
    manifest: {
      id: 'model-fake',
      version: options.uppercase ? '1.0.1' : '1.0.0',
      apiVersion: 1,
      provides: ['model'],
      requires: [],
      capabilities: [],
      reload: 'idle',
    },
    activate(scope) {
      const model: ModelProvider = {
        async complete({ prompt, previous, signal }) {
          await setTimeout(options.delayMs ?? 30, undefined, { signal });
          if (previous)
            return { kind: 'final', text: `Echo: ${previous.output}` };
          return {
            kind: 'tool',
            tool: 'echo',
            args: { text: options.uppercase ? prompt.toUpperCase() : prompt },
          };
        },
      };
      scope.provide('model', model);
    },
  };
}
