import { createHash } from 'node:crypto';
import {
  ApplicationError,
  canonicalJson,
  ToolRequestSchema,
  type PluginDefinition,
  type ToolExecutor,
} from '@devlab/contracts';

export function echoTools(): PluginDefinition {
  return {
    manifest: {
      id: 'tools-echo',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['tools'],
      requires: [],
      capabilities: [],
      reload: 'idle',
    },
    activate(scope) {
      const tools: ToolExecutor = {
        async execute(authorized, signal) {
          signal.throwIfAborted();
          const request = ToolRequestSchema.parse(authorized.request);
          const hash = createHash('sha256')
            .update(canonicalJson(request))
            .digest('hex');
          if (
            hash !== authorized.requestHash ||
            authorized.authorizationVersion !== 1
          )
            throw new ApplicationError(
              'AUTHORIZATION_MISMATCH',
              'Authorized request changed or uses an incompatible contract',
            );
          return { output: request.args.text };
        },
      };
      scope.provide('tools', tools);
    },
  };
}
