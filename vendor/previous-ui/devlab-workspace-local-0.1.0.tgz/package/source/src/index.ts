import { realpath, stat } from 'node:fs/promises';
import { isAbsolute, resolve, sep } from 'node:path';
import { ApplicationError, ProjectIdSchema, type PluginDefinition } from '@devlab/contracts';

export function workspaceRoots(projects: Record<string, string>): PluginDefinition {
  const roots = new Map(Object.entries(projects).map(([id, path]) => [ProjectIdSchema.parse(id), resolve(path)]));
  return {
    manifest: {id:'workspace-local',version:'1.0.0',apiVersion:1,provides:['workspace'],requires:[],capabilities:['workspace:local'],reload:'restart'},
    activate(scope) {
      scope.provide('workspace', {
        async resolve(projectId, cwd) {
          const configured = roots.get(ProjectIdSchema.parse(projectId));
          if (!configured || isAbsolute(cwd) || cwd.includes('\0'))
            throw new ApplicationError('PATH_DENIED', 'Choose a configured project and relative directory');
          try {
            const root = await realpath(configured);
            const target = await realpath(resolve(root, cwd));
            if (target !== root && !target.startsWith(root + sep))
              throw new ApplicationError('PATH_DENIED', 'Directory is outside the configured workspace');
            if (!(await stat(target)).isDirectory())
              throw new ApplicationError('PATH_DENIED', 'Working directory must be a directory');
            return target;
          } catch (error) {
            if (error instanceof ApplicationError) throw error;
            throw new ApplicationError('PATH_DENIED', 'Workspace directory is unavailable');
          }
        },
      });
    },
  };
}
