import { PlanSnapshotSchema,PlanCommandSchema } from '@devlab/contracts';
import { createHoodClient } from '@creoaurea/pop-the-hood/browser';
import type { ApplicationClient } from '@devlab/ui-contracts';
import { z } from 'zod';
import {
  WisdomInspectionSchema,
  WisdomProposalSchema,
  OpenProjectSchema,
  ProjectServerStateSchema,
  EventInputSchema,
  StartCommandSchema,
  CanvasDocumentSchema,
  SaveCanvasSchema,
  ApplicationError,
  TerminalSessionSchema,
  TerminalReplaySchema,
  TerminalCreateSchema,
  TerminalInputSchema,
  TerminalSizeSchema,
  type RunSnapshot,
  ProjectSchema,
  ProjectTreeSchema,
  ProjectTextSchema,
  CreateProjectSchema,
  WriteProjectFileSchema,
  BrowserEntrySchema,
  BrowserSessionSchema,
  BrowserLeaseSchema,
  BrowserResultSchema,
  BrowserFrameSchema,
  BrowserCommandSchema,
  type BrowserEntry,
} from '@devlab/contracts';
const SnapshotSchema = z.object({
  runId: z.string().uuid(),
  command: StartCommandSchema,
  status: z.enum([
    'queued',
    'running',
    'interrupted',
    'completed',
    'cancelled',
    'failed',
    'reconciliation-required',
  ]),
  output: z.string().optional(),
  error: z.string().optional(),
  events: z.array(
    z.object({
      seq: z.number().int(),
      eventId: z.string(),
      at: z.string(),
      schemaVersion: z.literal(1),
      input: EventInputSchema,
    }),
  ),
});
const HealthSchema = z.object({
  phase: z.string(),
  plugins: z.array(
    z.object({
      id: z.string(),
      version: z.string(),
      state: z.enum(['active', 'failed', 'disposed']),
      generation: z.number(),
      leases: z.number(),
    }),
  ),
});
async function request(path: string, body?: unknown, signal?: AbortSignal) {
  const response = await fetch(
    `/api${path}`,
    body === undefined
      ? { signal }
      : {
          signal,
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(body),
        },
  );
  const value: unknown = await response.json();
  if (!response.ok) {
    const e = z
      .object({ code: z.string(), message: z.string() })
      .safeParse(value);
    throw new ApplicationError(
      e.success ? e.data.code : 'HTTP_ERROR',
      e.success ? e.data.message : `Request failed (${response.status})`,
    );
  }
  return value;
}
const snapshot = (value: unknown): RunSnapshot => SnapshotSchema.parse(value);
// All visible browser nodes share this client. Share discovery, not control leases.
const browserDiscovery = new Map<
  string,
  { expiresAt: number; value: Promise<BrowserEntry[]> }
>();
function discoverBrowsers(projectId: string): Promise<BrowserEntry[]> {
  const cached = browserDiscovery.get(projectId);
  if (cached && cached.expiresAt > Date.now()) return cached.value;
  const entry = {
    expiresAt: Infinity,
    value: Promise.resolve([] as BrowserEntry[]),
  };
  entry.value = request(`/browsers?projectId=${encodeURIComponent(projectId)}`)
    .then((value) => {
      const result = BrowserEntrySchema.array().parse(value);
      entry.expiresAt = Date.now() + 250;
      return result;
    })
    .catch((error) => {
      if (browserDiscovery.get(projectId) === entry)
        browserDiscovery.delete(projectId);
      throw error;
    });
  browserDiscovery.set(projectId, entry);
  return entry.value;
}
async function mutateBrowser<T extends { projectId: string }>(
  path: string,
  body: T,
) {
  browserDiscovery.delete(body.projectId);
  try {
    return await request(path, body);
  } finally {
    browserDiscovery.delete(body.projectId);
  }
}
export const client: ApplicationClient = {
  planning: { snapshot: async (projectId) => PlanSnapshotSchema.parse(await request('/planning?'+new URLSearchParams({projectId}))), command: async (command) => PlanSnapshotSchema.parse(await request('/planning/command',PlanCommandSchema.parse(command))) },
  browsers: {
    discover: discoverBrowsers,
    start: async (identity, actor) =>
      BrowserSessionSchema.parse(
        await mutateBrowser('/browsers/start', { ...identity, actor }),
      ),
    acquire: async (target, actor, takeover = false) =>
      BrowserLeaseSchema.parse(
        await mutateBrowser('/browsers/acquire', {
          ...target,
          actor,
          takeover,
        }),
      ),
    command: async (input) =>
      BrowserResultSchema.parse(
        await mutateBrowser(
          '/browsers/command',
          BrowserCommandSchema.parse(input),
        ),
      ),
    release: async (lease) => {
      await mutateBrowser('/browsers/release', lease);
    },
    clearProfile: async (identity, actor) => {
      await mutateBrowser('/browsers/clear', { ...identity, actor });
    },
    frame: async (target, signal) =>
      BrowserFrameSchema.parse(
        await request(
          '/browsers/frame?' + new URLSearchParams(target),
          undefined,
          signal,
        ),
      ),
  },
  previewInspector: {
    openWorkspace: async (projectId,target) => z.object({sessionId:z.string().uuid()}).parse(await request('/preview/workspace',{projectId,...(target?{target}:{})})),
    openDevTools: async (sessionId,projectId) => request('/preview/devtools',{sessionId,projectId}),
    closeWorkspace: async (sessionId) => { await request('/preview/close',{sessionId,projectId:'default'}); },
  },
  wisdom: {
    inspect: async(id)=>WisdomInspectionSchema.parse(await request(`/projects/${encodeURIComponent(id)}/wisdom`)),
    plan: async(id,options)=>WisdomProposalSchema.parse(await request(`/projects/${encodeURIComponent(id)}/wisdom/plan`,options ?? {})),
    apply: async(id,sha256)=>z.object({inspection:WisdomInspectionSchema,added:z.array(z.string())}).parse(await request(`/projects/${encodeURIComponent(id)}/wisdom/apply`,{sha256})),
  },
  servers: {
    list: async () => ProjectServerStateSchema.array().parse(await request('/servers')),
    inspect: async (id) => ProjectServerStateSchema.parse(await request(`/servers/${encodeURIComponent(id)}`)),
    start: async (id) => ProjectServerStateSchema.parse(await request(`/servers/${encodeURIComponent(id)}/start`,{})),
    stop: async (id) => ProjectServerStateSchema.parse(await request(`/servers/${encodeURIComponent(id)}/stop`,{})),
  },
  projects: {
    open: async(input)=>ProjectSchema.parse(await request('/projects/open',OpenProjectSchema.parse(input))),
    forget: async(id)=>{await request(`/projects/${encodeURIComponent(id)}/forget`,{});},
    list: async () => ProjectSchema.array().parse(await request('/projects')),
    create: async (input) =>
      ProjectSchema.parse(
        await request('/projects', CreateProjectSchema.parse(input)),
      ),
    inspect: async (id) =>
      ProjectTreeSchema.parse(
        await request(`/projects/${encodeURIComponent(id)}/files`),
      ),
    read: async (id, path) =>
      ProjectTextSchema.parse(
        await request(
          `/projects/${encodeURIComponent(id)}/file?path=${encodeURIComponent(path)}`,
        ),
      ),
    write: async (input) => {
      const { projectId, ...body } = WriteProjectFileSchema.parse(input);
      return ProjectTextSchema.parse(
        await request(`/projects/${encodeURIComponent(projectId)}/file`, body),
      );
    },
    createModule: async (id, path) =>
      z
        .object({ paths: z.string().array() })
        .parse(
          await request(`/projects/${encodeURIComponent(id)}/module`, { path }),
        ),
  },
  registry: createHoodClient(),
  terminals: {
    list: async (projectId) =>
      z
        .array(TerminalSessionSchema)
        .parse(
          await request(
            `/terminals?projectId=${encodeURIComponent(projectId)}`,
          ),
        ),
    create: async (command) =>
      TerminalSessionSchema.parse(
        await request('/terminals', TerminalCreateSchema.parse(command)),
      ),
    inspect: async (id) =>
      TerminalReplaySchema.parse(
        await request(`/terminals/${encodeURIComponent(id)}`),
      ).session,
    write: async (id, data) => {
      await request(
        `/terminals/${encodeURIComponent(id)}/input`,
        TerminalInputSchema.parse({ data }),
      );
    },
    resize: async (id, cols, rows) => {
      await request(
        `/terminals/${encodeURIComponent(id)}/resize`,
        TerminalSizeSchema.parse({ cols, rows }),
      );
    },
    close: async (id) =>
      TerminalSessionSchema.parse(
        await request(`/terminals/${encodeURIComponent(id)}/close`, {}),
      ),
    listen(id, after, receive, error) {
      const stream = new EventSource(
        `/api/terminals/${encodeURIComponent(id)}/events?after=${after}`,
      );
      stream.addEventListener('terminal', (event) => {
        try {
          const value = TerminalReplaySchema.parse(
            JSON.parse((event as MessageEvent).data),
          );
          receive(value);
          if (value.session.status === 'exited') stream.close();
        } catch {
          stream.close();
          error();
        }
      });
      stream.onerror = error;
      return () => stream.close();
    },
  },
  canvas: {
    load: async (projectId) => {
      const value = await request(`/canvas/${encodeURIComponent(projectId)}`);
      return value === null ? null : CanvasDocumentSchema.parse(value);
    },
    save: async (command) =>
      CanvasDocumentSchema.parse(
        await request('/canvas', SaveCanvasSchema.parse(command)),
      ),
  },
  list: async () => z.array(SnapshotSchema).parse(await request('/runs')),
  start: async (command) => snapshot(await request('/runs', command)),
  cancel: async (id) =>
    snapshot(await request(`/runs/${encodeURIComponent(id)}/cancel`, {})),
  resume: async (id) =>
    snapshot(await request(`/runs/${encodeURIComponent(id)}/resume`, {})),
  health: async () => HealthSchema.parse(await request('/health')),
  replaceModel: async (uppercase) => {
    await request('/model', { uppercase });
  },
};
