import { spawn, type ChildProcess } from 'node:child_process';
import { constants } from 'node:fs';
import { createHash, randomUUID } from 'node:crypto';
import {
  readFile,
  realpath,
  lstat,
  readdir,
  readlink,
  mkdir,
  open,
  rename,
  unlink,
} from 'node:fs/promises';
import { resolve, sep } from 'node:path';
import { createServer } from 'node:net';
import {
  PreviewDescriptorSchema,
  type ProjectCatalog,
  type PreviewDescriptor,
  type PluginDefinition,
  type ProjectServers,
  type ProjectServerState,
} from '@devlab/contracts';

type RecordState = {
  state: ProjectServerState & { instanceId: string };
  controller: AbortController;
  child?: ChildProcess;
  pending?: Promise<ProjectServerState>;
  stopping?: Promise<ProjectServerState>;
  cleanup?: Promise<void>;
  installed?: string;
  managerVersion?: string;
  sessionId?: number;
};
const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
const cancelled = (r: RecordState) => {
  if (r.controller.signal.aborted)
    throw new Error('Server operation cancelled');
};
async function scoped(root: string, path: string) {
  const target = resolve(root, path);
  if (target !== root && !target.startsWith(root + sep))
    throw new Error('Path escapes selected project');
  if (
    (await realpath(target)) !== target ||
    !(await lstat(target)).isDirectory()
  )
    throw new Error('Preview directory is unavailable or symbolic');
  return target;
}
async function fingerprint(
  root: string,
  descriptor: PreviewDescriptor,
  cwd: string,
  managerVersion: string,
) {
  const hash = createHash('sha256')
    .update(process.version)
    .update(managerVersion)
    .update(JSON.stringify(descriptor));
  for (const folder of new Set([root, cwd]))
    for (const name of [
      'package.json',
      'pnpm-lock.yaml',
      'pnpm-workspace.yaml',
      'package-lock.json',
      'yarn.lock',
      'bun.lock',
    ]) {
      const file = resolve(folder, name);
      try {
        const stat = await lstat(file);
        if (
          !stat.isFile() ||
          stat.isSymbolicLink() ||
          stat.size > 16 * 1024 * 1024 ||
          (await realpath(file)) !== file
        )
          throw new Error('Unsafe dependency input: ' + name);
        hash.update(file).update(await readFile(file));
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
        hash.update(file + ':absent');
      }
    }
  return hash.digest('hex');
}
async function sessionMembers(sessionId: number): Promise<number[]> {
  const members: number[] = [];
  for (const name of await readdir('/proc'))
    if (/^\d+$/.test(name)) {
      try {
        const stat = await readFile('/proc/' + name + '/stat', 'utf8');
        const fields = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
        if (fields[0] !== 'Z' && Number(fields[3]) === sessionId)
          members.push(Number(name));
      } catch {
        /* exited */
      }
    }
  return members;
}
/** Detached launches own a POSIX session; pnpm may create several groups inside it. */
async function signalSession(sessionId: number, signal: NodeJS.Signals) {
  const groups = new Set<number>();
  for (const pid of await sessionMembers(sessionId)) {
    try {
      const text = await readFile('/proc/' + pid + '/stat', 'utf8');
      const fields = text.slice(text.lastIndexOf(')') + 2).split(' ');
      if (Number(fields[3]) === sessionId) groups.add(Number(fields[2]));
    } catch {
      /* exited */
    }
  }
  for (const group of groups)
    try {
      process.kill(-group, signal);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ESRCH') throw error;
    }
}
async function terminate(r: RecordState) {
  const sessionId = r.sessionId;
  if (!sessionId) return;
  await signalSession(sessionId, 'SIGTERM');
  for (let i = 0; i < 20; i++) {
    if (!(await sessionMembers(sessionId)).length) {
      if (r.sessionId === sessionId) r.sessionId = undefined;
      return;
    }
    await delay(25);
  }
  await signalSession(sessionId, 'SIGKILL');
  for (let i = 0; i < 40; i++) {
    if (!(await sessionMembers(sessionId)).length) break;
    await delay(25);
  }
  if ((await sessionMembers(sessionId)).length)
    throw new Error('Owned server session did not stop');
  if (r.sessionId === sessionId) r.sessionId = undefined;
}
async function freePort(port: number) {
  await new Promise<void>((done, reject) => {
    const s = createServer();
    s.once('error', () =>
      reject(new Error('Preview port is already occupied')),
    );
    s.listen({ host: '127.0.0.1', port, exclusive: true }, () =>
      s.close((error) => (error ? reject(error) : done())),
    );
  });
}
async function choosePort(port: number, retry: boolean, maxPort = port + 4) {
  for (let attempt = 0; attempt < (retry ? 5 : 1); attempt++) {
    const candidate = port + attempt;
    if (candidate > 65535 || candidate > maxPort) break;
    try {
      await freePort(candidate);
      return candidate;
    } catch (error) {
      if (!retry) throw error;
    }
  }
  throw new Error('Preview ports are occupied after bounded retry');
}
async function hasDependencies(
  workspace: string,
  descriptor: PreviewDescriptor,
) {
  if (!descriptor.packageManager) return true;
  const path = resolve(workspace, 'node_modules');
  try {
    const info = await lstat(path);
    return (
      info.isDirectory() &&
      !info.isSymbolicLink() &&
      (await realpath(path)) === path
    );
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false;
    throw error;
  }
}
async function ownedListener(port: number, group: number) {
  const inodes = new Set<string>();
  for (const table of ['tcp', 'tcp6']) {
    const text = await readFile('/proc/net/' + table, 'utf8');
    for (const line of text.trim().split('\n').slice(1)) {
      const f = line.trim().split(/\s+/);
      if (f[3] === '0A' && parseInt(f[1]!.split(':')[1]!, 16) === port)
        inodes.add(f[9]!);
    }
  }
  if (!inodes.size) return false;
  for (const pid of await sessionMembers(group)) {
    for (const fd of await readdir('/proc/' + pid + '/fd').catch(() => [])) {
      const target = await readlink('/proc/' + pid + '/fd/' + fd).catch(
        () => '',
      );
      const match = /^socket:\[(\d+)\]$/.exec(target);
      if (match && inodes.has(match[1]!)) return true;
    }
  }
  return false;
}
function environment(descriptor: PreviewDescriptor) {
  // Never copy the agent process environment or read project .env files.
  const env: NodeJS.ProcessEnv = {
    PATH: process.env.PATH,
    HOME: process.env.HOME,
    LANG: process.env.LANG,
    TERM: 'dumb',
    NO_COLOR: '1',
  };
  for (const key of descriptor.environment) {
    if (!['NODE_ENV', 'CI', 'TZ', 'LANG', 'LC_ALL'].includes(key))
      throw new Error(
        'Environment variable is not an approved non-secret setting: ' + key,
      );
    if (process.env[key] !== undefined) env[key] = process.env[key];
  }
  return env;
}
function launch(
  r: RecordState,
  argv: string[],
  cwd: string,
  env: NodeJS.ProcessEnv,
  port: number,
) {
  cancelled(r);
  const args = argv.map((v) => v.replaceAll('{port}', String(port)));
  const child = spawn(args[0]!, args.slice(1), {
    cwd,
    env,
    shell: false,
    detached: true,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  r.child = child;
  r.sessionId = child.pid;
  const append = (data: Buffer) => {
    r.state.logs.push(data.toString('utf8').slice(-4096));
    while (r.state.logs.reduce((n, s) => n + s.length, 0) > 32768)
      r.state.logs.shift();
  };
  child.stdout?.on('data', append);
  child.stderr?.on('data', append);
  const exited = new Promise<void>((done, reject) => {
    child.once('error', reject);
    child.once('exit', (code, signal) =>
      code === 0
        ? done()
        : reject(new Error('Process exited ' + (signal ?? code))),
    );
  });
  // Keep rejection observed while readiness probes run.
  void exited.catch(() => {});
  return { child, exited };
}
/** Linux process ownership is checked through /proc; project code only runs after explicit descriptor start. */
export function createProjectServers(
  projects: Pick<ProjectCatalog, 'root' | 'read' | 'list'>,
  options: { cacheDirectory?: string } = {},
): ProjectServers & { dispose(): Promise<void> } {
  if (process.platform !== 'linux')
    throw new Error('Owned project servers currently require Linux');
  const instanceId = randomUUID();
  const records = new Map<string, RecordState>();
  let alive = true,
    disposing = false;
  const assertAlive = () => {
    if (!alive || disposing) throw new Error('Project server host is closed');
  };
  const record = (id: string) => {
    let r = records.get(id);
    if (!r) {
      r = {
        state: {
          instanceId,
          projectId: id,
          generation: 0,
          status: 'stopped',
          logs: [],
        },
        controller: new AbortController(),
      };
      records.set(id, r);
    }
    return r;
  };
  const copy = (r: RecordState) => ({ ...r.state, logs: [...r.state.logs] });
  async function config(
    id: string,
    managerVersion = records.get(id)?.managerVersion ?? 'unqueried',
  ) {
    const root = await projects.root(id);
    const text = await projects
      .read(id, 'devlab.preview.json')
      .catch((error) => {
        if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
        throw Object.assign(
          new Error(
            'Preview is not configured. Choose Prepare project, review and apply the preview setup, then Start preview.',
          ),
          { code: 'ENOENT' },
        );
      });
    const descriptor = PreviewDescriptorSchema.parse(JSON.parse(text.text));
    const cwd = await scoped(root, descriptor.cwd),
      workspace = await scoped(root, descriptor.workspaceRoot);
    if (cwd !== workspace && !cwd.startsWith(workspace + sep))
      throw new Error('Preview cwd must be inside workspaceRoot');
    return {
      root,
      cwd,
      workspace,
      descriptor,
      fingerprint: await fingerprint(
        workspace,
        descriptor,
        cwd,
        managerVersion,
      ),
    };
  }
  async function cachePath(id: string, workspace: string) {
    if (!options.cacheDirectory) return undefined;
    const directory = resolve(options.cacheDirectory);
    await mkdir(directory, { recursive: true, mode: 0o700 });
    const stat = await lstat(directory);
    if (
      !stat.isDirectory() ||
      stat.isSymbolicLink() ||
      (await realpath(directory)) !== directory ||
      (stat.mode & 0o077) !== 0
    )
      throw new Error('Dependency cache directory is not private and physical');
    return resolve(
      directory,
      createHash('sha256').update(id).update(workspace).digest('hex') + '.json',
    );
  }
  async function readCache(
    id: string,
    workspace: string,
    expected: string,
    managerVersion: string,
  ) {
    const path = await cachePath(id, workspace);
    if (!path) return false;
    let fd;
    try {
      fd = await open(
        path,
        constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK,
      );
      const stat = await fd.stat();
      if (
        !stat.isFile() ||
        stat.size > 4096 ||
        (stat.mode & 0o077) !== 0 ||
        (await realpath('/proc/self/fd/' + fd.fd)) !== path
      )
        throw new Error('Unsafe dependency cache marker');
      const bytes = Buffer.alloc(4097);
      const result = await fd.read(bytes, 0, 4097, 0);
      if (result.bytesRead > 4096)
        throw new Error('Dependency cache marker exceeds budget');
      const marker = JSON.parse(
        bytes.subarray(0, result.bytesRead).toString('utf8'),
      );
      return (
        marker.schemaVersion === 1 &&
        marker.fingerprint === expected &&
        marker.managerVersion === managerVersion
      );
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false;
      throw error;
    } finally {
      await fd?.close();
    }
  }
  async function writeCache(
    id: string,
    workspace: string,
    fp: string,
    managerVersion: string,
  ) {
    const path = await cachePath(id, workspace);
    if (!path) return;
    const temporary = path + '.' + randomUUID() + '.tmp';
    let fd;
    try {
      fd = await open(temporary, 'wx', 0o600);
      await fd.writeFile(
        JSON.stringify({ schemaVersion: 1, fingerprint: fp, managerVersion }) +
          '\n',
      );
      await fd.sync();
      await fd.close();
      fd = undefined;
      await rename(temporary, path);
    } finally {
      await fd?.close();
      await unlink(temporary).catch(() => {});
    }
  }
  const service: ProjectServers & { dispose(): Promise<void> } = {
    async inspect(id) {
      assertAlive();
      const r = record(id);
      if (r.pending || r.stopping || r.cleanup) return copy(r);
      const generation = r.state.generation,
        controller = r.controller;
      const current = () =>
        alive &&
        !disposing &&
        !r.pending &&
        !r.stopping &&
        !r.cleanup &&
        r.state.generation === generation &&
        r.controller === controller;
      try {
        const c = await config(id);
        if (!current()) return copy(r);
        if (r.state.status === 'ready' && r.state.fingerprint !== c.fingerprint)
          await service.stop(id);
        if (!current()) return copy(r);
        r.state = {
          ...r.state,
          status:
            c.descriptor.adapter === 'none'
              ? 'unconfigured'
              : r.state.status === 'failed'
                ? 'failed'
                : r.state.status === 'ready'
                  ? 'ready'
                  : 'stopped',
          fingerprint: c.fingerprint,
          descriptor: c.descriptor,
        };
      } catch (error) {
        if (!current()) return copy(r);
        if (r.state.status === 'ready') await service.stop(id);
        if (!current()) return copy(r);
        r.state = {
          ...r.state,
          status:
            (error as NodeJS.ErrnoException).code === 'ENOENT'
              ? 'unconfigured'
              : 'invalid',
          error: String(error),
        };
      }
      return copy(r);
    },
    async list() {
      assertAlive();
      return Promise.all(
        (await projects.list()).map((p) => service.inspect(p.id)),
      );
    },
    start(id) {
      assertAlive();
      const r = record(id);
      if (r.stopping) return r.stopping.then(() => service.start(id));
      if (r.cleanup) return r.cleanup.then(() => service.start(id));
      if (r.pending) return r.pending;
      if (r.state.status === 'ready')
        return service
          .inspect(id)
          .then((s) => (s.status === 'ready' ? s : service.start(id)));
      if (
        [...records.values()].filter((v) =>
          ['installing', 'starting', 'ready'].includes(v.state.status),
        ).length >= 8
      )
        return Promise.reject(new Error('Active server limit reached (8)'));
      r.controller = new AbortController();
      r.state = {
        instanceId,
        projectId: id,
        generation: r.state.generation + 1,
        status: 'starting',
        logs: [],
      };
      r.pending = (async () => {
        try {
          // A failed cleanup retains ownership and must settle before any new spawn.
          if (r.sessionId) await terminate(r);
          const c = await config(id);
          cancelled(r);
          if (c.descriptor.adapter === 'none' || !c.descriptor.start)
            throw new Error('Project has no UI server');
          r.state.descriptor = c.descriptor;
          const env = environment(c.descriptor);
          let managerVersion = 'none';
          if (
            c.descriptor.packageManagerVersion &&
            !c.descriptor.packageManager
          )
            throw new Error(
              'Pinned package-manager version requires a manager',
            );
          if (c.descriptor.packageManager) {
            const before = r.state.logs.length;
            const check = launch(
              r,
              [c.descriptor.packageManager, '--version'],
              c.workspace,
              env,
              c.descriptor.port,
            );
            await Promise.race([
              check.exited,
              new Promise<never>((_, reject) => {
                const timer = setTimeout(
                  () =>
                    reject(
                      new Error('Package-manager version check timed out'),
                    ),
                  3000,
                );
                void check.exited
                  .finally(() => clearTimeout(timer))
                  .catch(() => {});
              }),
            ]);
            cancelled(r);
            await terminate(r);
            managerVersion = r.state.logs.slice(before).join('').trim();
            if (!/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(managerVersion))
              throw new Error('Package manager returned an invalid version');
            if (
              c.descriptor.packageManagerVersion &&
              managerVersion !== c.descriptor.packageManagerVersion
            )
              throw new Error(
                'Package-manager version mismatch: expected ' +
                  c.descriptor.packageManagerVersion +
                  ', received ' +
                  managerVersion,
              );
          }
          r.managerVersion = managerVersion;
          c.fingerprint = await fingerprint(
            c.workspace,
            c.descriptor,
            c.cwd,
            managerVersion,
          );
          r.state.fingerprint = c.fingerprint;
          let port = await choosePort(
            c.descriptor.port,
            c.descriptor.start.some((v) => v.includes('{port}')),
          );
          cancelled(r);
          const dependenciesPresent = await hasDependencies(
            c.workspace,
            c.descriptor,
          );
          const cached =
            dependenciesPresent &&
            (await readCache(id, c.workspace, c.fingerprint, managerVersion));
          if (
            c.descriptor.install &&
            (r.installed !== c.fingerprint || !dependenciesPresent) &&
            !cached
          ) {
            r.state.status = 'installing';
            r.installed = undefined;
            const staleCache = await cachePath(id, c.workspace);
            if (staleCache)
              await unlink(staleCache).catch((error) => {
                if (error.code !== 'ENOENT') throw error;
              });
            const install = launch(
              r,
              c.descriptor.install,
              c.workspace,
              env,
              c.descriptor.port,
            );
            await Promise.race([
              install.exited,
              new Promise<never>((_, reject) => {
                const timeout = setTimeout(
                  () => reject(new Error('Dependency installation timed out')),
                  c.descriptor.timeoutMs,
                );
                install.exited
                  .finally(() => clearTimeout(timeout))
                  .catch(() => {});
              }),
            ]);
            cancelled(r);
            await terminate(r);
            const installed = await config(id, managerVersion);
            cancelled(r);
            if (
              installed.root !== c.root ||
              installed.cwd !== c.cwd ||
              installed.workspace !== c.workspace ||
              JSON.stringify(installed.descriptor) !==
                JSON.stringify(c.descriptor)
            )
              throw new Error(
                'Preview configuration changed during dependency installation',
              );
            // Install may legitimately create/update its lockfile; cache the resulting inputs.
            c.fingerprint = installed.fingerprint;
            r.installed = installed.fingerprint;
            r.state.fingerprint = installed.fingerprint;
            if (await hasDependencies(c.workspace, c.descriptor))
              await writeCache(
                id,
                c.workspace,
                installed.fingerprint,
                managerVersion,
              );
          }
          cancelled(r);
          port = await choosePort(
            c.descriptor.port,
            c.descriptor.start.some((v) => v.includes('{port}')),
          );
          cancelled(r);
          r.state.status = 'starting';
          const deadline = Date.now() + c.descriptor.timeoutMs;
          serverStart: for (
            let launchAttempt = 0;
            launchAttempt < 5;
            launchAttempt++
          ) {
            const run = launch(r, c.descriptor.start, c.cwd, env, port);
            let exited = false;
            run.exited.then(
              () => {
                exited = true;
              },
              () => {
                exited = true;
              },
            );
            const url = 'http://127.0.0.1:' + port + c.descriptor.readinessPath;
            while (Date.now() < deadline) {
              cancelled(r);
              if (exited) {
                await terminate(r);
                let occupied = false;
                try {
                  await freePort(port);
                } catch {
                  occupied = true;
                }
                if (
                  occupied &&
                  c.descriptor.start.some((v) => v.includes('{port}')) &&
                  launchAttempt < 4 &&
                  Date.now() < deadline
                ) {
                  port = await choosePort(
                    port + 1,
                    true,
                    c.descriptor.port + 4,
                  );
                  continue serverStart;
                }
                throw new Error('Server exited before readiness');
              }
              if (r.sessionId && (await ownedListener(port, r.sessionId))) {
                try {
                  const response = await fetch(url, {
                    signal: AbortSignal.timeout(400),
                    redirect: 'manual',
                  });
                  await response.body?.cancel();
                  if (response.status >= 200 && response.status < 400) {
                    cancelled(r);
                    if (exited)
                      throw new Error('Server exited before readiness');
                    r.state.status = 'ready';
                    r.state.url = 'http://127.0.0.1:' + port + '/';
                    run.exited
                      .finally(() => {
                        if (
                          r.child === run.child &&
                          r.state.status === 'ready' &&
                          !r.controller.signal.aborted
                        ) {
                          r.state.status = 'failed';
                          r.state.error = 'Server exited';
                          r.state.url = undefined;
                          const cleanup = terminate(r)
                            .catch((error) => {
                              r.state.error = String(error);
                              throw error;
                            })
                            .finally(() => {
                              if (r.cleanup === cleanup) r.cleanup = undefined;
                            });
                          r.cleanup = cleanup;
                          void cleanup.catch(() => {});
                        }
                      })
                      .catch(() => {});
                    return copy(r);
                  }
                } catch {
                  /* retry */
                }
              }
              await delay(50);
            }
            throw new Error('Server readiness timed out');
          }
          throw new Error('Server port conflict retries exhausted');
        } catch (error) {
          await terminate(r);
          r.state.status = r.controller.signal.aborted ? 'stopped' : 'failed';
          r.state.error = r.controller.signal.aborted
            ? undefined
            : String(error);
          r.state.url = undefined;
          return copy(r);
        } finally {
          r.pending = undefined;
        }
      })();
      return r.pending;
    },
    async stop(id) {
      if (!alive) throw new Error('Project server host is closed');
      const r = record(id);
      if (r.stopping) return r.stopping;
      r.controller.abort();
      r.state.status = 'stopped';
      r.stopping = (async () => {
        await r.cleanup;
        await terminate(r);
        await r.pending;
        r.state.status = 'stopped';
        r.state.url = undefined;
        r.state.error = undefined;
        return copy(r);
      })().finally(() => {
        r.stopping = undefined;
      });
      return r.stopping;
    },
    async dispose() {
      if (!alive) return;
      disposing = true;
      await Promise.all([...records.keys()].map((id) => service.stop(id)));
      alive = false;
    },
  };
  return service;
}

export function projectServer(
  options: { cacheDirectory?: string; autoStart?: boolean } = {},
): PluginDefinition {
  return {
    manifest: {
      id: 'project-server',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['servers'],
      requires: ['projects'],
      capabilities: [
        'process:local',
        ...(options.cacheDirectory ? ['storage:local'] : []),
      ],
      reload: 'restart',
    },
    activate(scope) {
      const projects = scope.get('projects');
      const service = createProjectServers(projects, options);
      scope.provide('servers', service);
      let stopped = false;
      let startup: Promise<void> = Promise.resolve();
      scope.onDispose(async () => {
        stopped = true;
        await service.dispose();
        await startup;
      });
      if (options.autoStart)
        startup = projects
          .list()
          .then(async (list) => {
            for (const project of list) {
              if (stopped) return;
              try {
                const state = await service.inspect(project.id);
                if (stopped) return;
                if (state.descriptor?.autoStart)
                  void service.start(project.id).catch(() => {});
              } catch {
                /* closed/unavailable; owned service retains diagnostics */
              }
            }
          })
          .catch(() => {});
    },
  };
}
