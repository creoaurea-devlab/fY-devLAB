import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { homedir, userInfo } from 'node:os';
import type { IPty } from 'node-pty';
import {
  ApplicationError,
  TerminalCreateSchema,
  TerminalInputSchema,
  TerminalSizeSchema,
  type PluginDefinition,
  type TerminalSession,
  type TerminalReplay,
} from '@devlab/contracts';

type RecordState = {
  session: TerminalSession;
  pty: IPty;
  chunks: TerminalReplay['chunks'];
  bytes: number;
  listeners: Set<() => void>;
  exited: Promise<void>;
  resolveExit: () => void;
  closing?: Promise<TerminalSession>;
};
// Linux identity checks avoid signalling an unrelated process after PID reuse.
async function processIdentity(pid: number): Promise<string | null> {
  try {
    const stat = await readFile(`/proc/${pid}/stat`, 'utf8');
    return stat.slice(stat.lastIndexOf(')') + 2).split(' ')[19] ?? null;
  } catch {
    return null;
  }
}
async function descendants(pid: number): Promise<Map<number, string>> {
  const found = new Map<number, string>();
  async function visit(parent: number) {
    let children: string;
    try {
      children = await readFile(
        `/proc/${parent}/task/${parent}/children`,
        'utf8',
      );
    } catch {
      return;
    }
    for (const value of children.trim().split(/\s+/)) {
      const child = Number(value);
      if (!child || found.has(child)) continue;
      const identity = await processIdentity(child);
      if (!identity) continue;
      found.set(child, identity);
      await visit(child);
    }
  }
  await visit(pid);
  return found;
}
async function signalChildren(
  children: Map<number, string>,
  signal: NodeJS.Signals,
) {
  for (const [pid, identity] of [...children].reverse()) {
    if ((await processIdentity(pid)) !== identity) continue;
    try {
      process.kill(pid, signal);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ESRCH') throw error;
    }
  }
}
function delay(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

export function terminalPty(
  options: { maxSessions?: number; replayBytes?: number } = {},
): PluginDefinition {
  const maxSessions = options.maxSessions ?? 8,
    replayBytes = options.replayBytes ?? 1024 * 1024;
  if (
    !Number.isInteger(maxSessions) ||
    maxSessions < 1 ||
    maxSessions > 32 ||
    replayBytes < 1024 ||
    replayBytes > 4 * 1024 * 1024
  )
    throw new Error('Invalid terminal limits');
  return {
    manifest: {
      id: 'terminal-pty',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['terminals'],
      requires: ['workspace'],
      capabilities: ['terminal:local'],
      reload: 'restart',
    },
    activate(scope) {
      const workspace = scope.get('workspace'),
        records = new Map<string, RecordState>();
      let alive = true,
        queue: Promise<unknown> = Promise.resolve();
      const active = () => {
        if (!alive)
          throw new ApplicationError('NOT_READY', 'Terminal host is closed');
      };
      const record = (id: string) => {
        active();
        const r = records.get(id);
        if (!r)
          throw new ApplicationError(
            'TERMINAL_NOT_FOUND',
            'Terminal session not found',
          );
        return r;
      };
      const snapshot = (r: RecordState) => ({ ...r.session });
      const notify = (r: RecordState) => {
        for (const listener of r.listeners) {
          try {
            listener();
          } catch {
            /* observer failure cannot break PTY ownership */
          }
        }
      };
      const running = (r: RecordState) => {
        if (r.session.status !== 'running' || r.closing)
          throw new ApplicationError('TERMINAL_EXITED', 'Terminal is stopped');
      };
      async function stop(r: RecordState): Promise<TerminalSession> {
        if (r.closing) return r.closing;
        if (r.session.status === 'exited') return snapshot(r);
        r.closing = (async () => {
          const children = await descendants(r.session.pid);
          await signalChildren(children, 'SIGTERM');
          try {
            r.pty.kill('SIGTERM');
          } catch (error) {
            if (r.session.status === 'running') throw error;
          }
          await Promise.race([r.exited, delay(750)]);
          await signalChildren(children, 'SIGKILL');
          if (r.session.status === 'running') {
            r.pty.kill('SIGKILL');
            await Promise.race([r.exited, delay(1500)]);
          }
          if (r.session.status !== 'exited')
            throw new ApplicationError(
              'TERMINAL_CLEANUP_FAILED',
              'Terminal exit was not observed',
            );
          return snapshot(r);
        })();
        return r.closing;
      }
      scope.onDispose(async () => {
        alive = false;
        await queue.catch(() => {});
        const results = await Promise.allSettled(
          [...records.values()].map(stop),
        );
        for (const r of records.values()) r.listeners.clear();
        const failures = results.filter(
          (r): r is PromiseRejectedResult => r.status === 'rejected',
        );
        if (failures.length)
          throw new AggregateError(
            failures.map((r) => r.reason),
            'PTY cleanup failed',
          );
      });
      scope.provide('terminals', {
        create(input) {
          const command = TerminalCreateSchema.parse(input);
          const pending = queue.then(async () => {
            active();
            const release = scope.lease();
            try {
              const existing = [...records.values()].find(
                (r) =>
                  r.session.projectId === command.projectId &&
                  r.session.nodeId === command.nodeId &&
                  r.session.status === 'running' &&
                  !r.closing,
              );
              if (existing) return snapshot(existing);
              if (
                [...records.values()].filter(
                  (r) => r.session.status === 'running',
                ).length >= maxSessions
              )
                throw new ApplicationError(
                  'TERMINAL_LIMIT',
                  `Maximum ${maxSessions} active terminals`,
                );
              // Retain a bounded set of stopped summaries for reconnects.
              if (records.size >= 64) {
                const oldest = [...records].find(
                  ([, v]) =>
                    v.session.status === 'exited' && v.listeners.size === 0,
                );
                if (oldest) records.delete(oldest[0]);
                else {
                  throw new ApplicationError(
                    'TERMINAL_LIMIT',
                    'Terminal history is full',
                  );
                }
              }
              const cwd = await workspace.resolve(
                command.projectId,
                command.cwd,
              );
              const { spawn } = await import('node-pty');
              active();
              // Never inherit provider credentials or graph-supplied startup commands.
              const env: Record<string, string> = {
                PATH: process.env.PATH ?? '/usr/local/bin:/usr/bin:/bin',
                HOME: homedir(),
                USER: userInfo().username,
                LANG: 'C.UTF-8',
                TERM: 'xterm-256color',
                COLORTERM: 'truecolor',
              };
              // Audio clients need the desktop user's socket discovery settings.
              // Keep this allowlist narrow; never inherit the whole host environment.
              for (const key of [
                'XDG_RUNTIME_DIR',
                'PULSE_SERVER',
                'PULSE_SINK',
                'PULSE_SOURCE',
                'PIPEWIRE_REMOTE',
              ]) {
                const value = process.env[key];
                if (value) env[key] = value;
              }
              const pty = spawn(
                command.shell === 'bash' ? '/bin/bash' : '/bin/sh',
                command.shell === 'bash'
                  ? ['--noprofile', '--norc', '-i']
                  : ['-i'],
                {
                  name: 'xterm-256color',
                  cols: command.cols,
                  rows: command.rows,
                  cwd,
                  env,
                },
              );
              let resolveExit!: () => void;
              const exited = new Promise<void>((resolve) => {
                resolveExit = resolve;
              });
              const r: RecordState = {
                pty,
                session: {
                  ...command,
                  id: randomUUID(),
                  pid: pty.pid,
                  cwd,
                  status: 'running',
                  exitCode: null,
                  cursor: 0,
                },
                chunks: [],
                bytes: 0,
                listeners: new Set(),
                exited,
                resolveExit,
              };
              records.set(r.session.id, r);
              pty.onData((data) => {
                for (let i = 0; i < data.length; ) {
                  let end = Math.min(
                    data.length,
                    i + Math.min(16384, Math.floor(replayBytes / 4)),
                  );
                  if (
                    end < data.length &&
                    data.charCodeAt(end - 1) >= 0xd800 &&
                    data.charCodeAt(end - 1) <= 0xdbff
                  )
                    end--;
                  const text = data.slice(i, end);
                  i = end;
                  r.chunks.push({ seq: ++r.session.cursor, data: text });
                  r.bytes += Buffer.byteLength(text);
                  while (r.bytes > replayBytes && r.chunks.length) {
                    r.bytes -= Buffer.byteLength(r.chunks.shift()!.data);
                  }
                }
                notify(r);
              });
              pty.onExit(({ exitCode }) => {
                r.session.status = 'exited';
                r.session.exitCode = exitCode;
                r.resolveExit();
                notify(r);
              });
              return snapshot(r);
            } finally {
              release();
            }
          });
          queue = pending.catch(() => {});
          return pending;
        },
        list(projectId) {
          active();
          return [...records.values()]
            .filter((r) => r.session.projectId === projectId)
            .map(snapshot);
        },
        inspect(id) {
          return snapshot(record(id));
        },
        read(id, after) {
          if (!Number.isSafeInteger(after) || after < 0)
            throw new ApplicationError(
              'INVALID_INPUT',
              'Invalid output cursor',
            );
          const r = record(id),
            earliest = r.chunks[0]?.seq ?? r.session.cursor + 1;
          const reset = after < earliest - 1 || after > r.session.cursor;
          return {
            session: snapshot(r),
            reset,
            chunks: r.chunks
              .filter((c) => reset || c.seq > after)
              .map((c) => ({ ...c })),
          };
        },
        subscribe(id, listener) {
          const r = record(id);
          if (r.listeners.size >= 16)
            throw new ApplicationError(
              'TERMINAL_LIMIT',
              'Too many terminal observers',
            );
          r.listeners.add(listener);
          return () => {
            r.listeners.delete(listener);
          };
        },
        write(id, input) {
          const r = record(id);
          running(r);
          const { data } = TerminalInputSchema.parse({ data: input });
          if (Buffer.byteLength(data) > 65536)
            throw new ApplicationError(
              'INVALID_INPUT',
              'Terminal input exceeds 64 KiB',
            );
          const release = scope.lease();
          try {
            r.pty.write(data);
          } finally {
            release();
          }
        },
        resize(id, input) {
          const r = record(id);
          running(r);
          const size = TerminalSizeSchema.parse(input);
          const release = scope.lease();
          try {
            r.pty.resize(size.cols, size.rows);
            Object.assign(r.session, size);
          } finally {
            release();
          }
          notify(r);
        },
        close(id) {
          return stop(record(id));
        },
      });
    },
  };
}
