import { PreviewGroups } from './preview-groups.tsx';
import { lazy, Suspense, useId, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import {
  Plus,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  FileCode2,
  Folder,
  X,
} from 'lucide-react';
import type { UIPluginProps, ProjectWorkspace } from '@devlab/ui-contracts';
import './projects.css';
import { ProjectAdoption } from './adoption.tsx';
const Build = lazy(() =>
  import('./build.tsx').then((module) => ({ default: module.ProjectBuild })),
);
export function ProjectsView({
  client,
  projectWorkspace,
  projectOptions,
  previewWorkspace,
}: UIPluginProps) {
  if (!projectWorkspace) return null;
  return projectOptions?.view === 'canvas' ? (
    <Suspense
      fallback={<div className="projects-loading">Opening build canvas…</div>}
    >
      <Build owner={projectWorkspace} />
    </Suspense>
  ) : (
    <Explorer
      client={client}
      owner={projectWorkspace}
      previewWorkspace={previewWorkspace}
      collapse={projectOptions?.collapse}
    />
  );
}
function Explorer({
  client,
  owner,
  collapse,
  previewWorkspace,
}: {
  client: UIPluginProps['client'];
  owner: ProjectWorkspace;
  collapse?: () => void;
  previewWorkspace?: UIPluginProps['previewWorkspace'];
}) {
  const state = useSyncExternalStore(owner.subscribe, owner.snapshot);
  const [actionsExpanded, setActionsExpanded] = useState(false);
  const actionsId = useId();
  const actionsToggle = useRef<HTMLButtonElement>(null);
  const [opening, setOpening] = useState(false),
    [folderPath, setFolderPath] = useState('');
  const [creating, setCreating] = useState(false),
    [name, setName] = useState(''),
    [slug, setSlug] = useState(''),
    [error, setError] = useState('');
  const [expanded, setExpanded] = useState(
    new Set(['src', 'plugins', 'packages', 'apps']),
  );
  const children = useMemo(() => {
    const result = new Map<string, NonNullable<typeof state.tree>['entries']>();
    for (const entry of state.tree?.entries ?? []) {
      const parent = entry.path.split('/').slice(0, -1).join('/');
      const group = result.get(parent) ?? [];
      group.push(entry);
      result.set(parent, group);
    }
    return result;
  }, [state.tree]);
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    try {
      await owner.create(slug, name);
      setCreating(false);
      setName('');
      setSlug('');
    } catch (e) {
      setError(String(e));
    }
  };
  function tree(path: string, depth = 0): React.ReactNode {
    return (children.get(path) ?? []).map((entry) =>
      entry.kind === 'directory' ? (
        <div key={entry.path}>
          <button
            className="project-tree-row"
            style={{ paddingLeft: 10 + depth * 12 }}
            aria-label={`${expanded.has(entry.path) ? 'Collapse' : 'Expand'} folder ${entry.path}`}
            aria-expanded={expanded.has(entry.path)}
            onClick={() =>
              setExpanded((current) => {
                const next = new Set(current);
                next.has(entry.path)
                  ? next.delete(entry.path)
                  : next.add(entry.path);
                return next;
              })
            }
          >
            {expanded.has(entry.path) ? (
              <ChevronDown size={11} />
            ) : (
              <ChevronRight size={11} />
            )}
            <Folder size={12} />
            <span>{entry.path.split('/').at(-1)}</span>
          </button>
          {expanded.has(entry.path) && tree(entry.path, depth + 1)}
        </div>
      ) : (
        <button
          key={entry.path}
          className={`project-tree-row${state.editor?.path === entry.path ? ' selected' : ''}`}
          style={{ paddingLeft: 24 + depth * 12 }}
          title={entry.path}
          aria-label={`Open ${entry.path}`}
          onClick={() => void owner.openFile(entry.path)}
        >
          <FileCode2 size={12} />
          <span>{entry.path.split('/').at(-1)}</span>
        </button>
      ),
    );
  }
  return (
    <aside
      className="project-explorer-container"
      aria-label="Project explorer"
      data-testid="project-explorer"
    >
      <div
        className={`project-explorer-header${actionsExpanded ? ' project-actions-expanded' : ''}`}
        onKeyDown={(event) => {
          if (event.key === 'Escape' && actionsExpanded) {
            event.preventDefault();
            event.stopPropagation();
            setActionsExpanded(false);
            actionsToggle.current?.focus();
          }
        }}
      >
        <button
          ref={actionsToggle}
          type="button"
          className="project-actions-toggle"
          aria-label={actionsExpanded ? 'Minimize project actions' : 'Expand project actions'}
          aria-expanded={actionsExpanded}
          aria-controls={actionsId}
          data-devlab-id="project.actions.toggle"
          data-devlab-source="plugins/ui-projects/src/view.tsx"
          onClick={() => setActionsExpanded(!actionsExpanded)}
        >
        <span className="project-explorer-header-icon">◈</span>
        <span className="project-explorer-header-title">Projects</span>
        <span aria-hidden="true">{actionsExpanded ? '▴' : '•'}</span>
        </button>
        <div
          id={actionsId}
          className="project-header-actions"
          hidden={!actionsExpanded}
          data-devlab-id="project.actions"
          data-devlab-source="plugins/ui-projects/src/view.tsx"
        >
        <button
          className="tree-action-btn"
          aria-label="New project"
          data-devlab-id="project.new"
          onClick={() => {
            setCreating(true);
            setOpening(false);
            setError('');
          }}
        >
          <Plus size={13} />
        </button>
        <button
          className="tree-action-btn"
          aria-label="Open Folder"
          data-devlab-id="project.open-folder"
          disabled={state.busy}
          onClick={() => {
            setOpening(true);
            setCreating(false);
            setError('');
          }}
        >
          <Folder size={13} />
        </button>

        </div>
        {collapse && <button type="button" className="project-explorer-close" aria-label="Collapse project explorer" data-devlab-id="workspace.projects.close" data-devlab-source="plugins/ui-projects/src/view.tsx" onClick={collapse}><ChevronLeft size={12}/></button>}
      </div>
      {creating && (
        <form
          className="project-create-form"
          aria-label="Create project"
          onSubmit={submit}
        >
          <div>
            <strong>New project</strong>
            <button
              type="button"
              aria-label="Cancel new project"
              onClick={() => setCreating(false)}
            >
              <X size={12} />
            </button>
          </div>
          <label>
            Name
            <input
              aria-label="Project name"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                setSlug(
                  e.target.value
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-|-$/g, '')
                    .slice(0, 64),
                );
              }}
              required
              autoFocus
            />
          </label>
          <label>
            Directory
            <input
              aria-label="Project directory"
              pattern="[a-z][a-z0-9-]{0,63}"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
              required
            />
          </label>
          <small>projects/{slug || 'project-name'}/</small>
          {error && <p role="alert">{error}</p>}
          <button className="project-primary" disabled={state.busy || !slug}>
            Create project
          </button>
        </form>
      )}
      {opening && (
        <form
          className="project-create-form"
          aria-label="Open existing folder"
          onSubmit={async (event) => {
            event.preventDefault();
            setError('');
            try {
              await owner.openFolder(folderPath);
              setOpening(false);
              setFolderPath('');
            } catch (reason) {
              setError(
                reason instanceof Error ? reason.message : String(reason),
              );
            }
          }}
        >
          <div>
            <strong>Open Folder</strong>
            <button
              type="button"
              aria-label="Cancel open folder"
              data-devlab-id="project.open.cancel"
              onClick={() => setOpening(false)}
            >
              <X size={12} />
            </button>
          </div>
          <label>
            Absolute folder path
            <input
              aria-label="Existing project folder"
              data-devlab-id="project.open.path"
              value={folderPath}
              onChange={(event) => setFolderPath(event.target.value)}
              placeholder="/home/you/projects/app"
              required
              pattern="/.*"
              autoFocus
            />
          </label>
          <small>
            Existing files stay in this folder. Preparation is reviewed
            separately.
          </small>
          {error && <p role="alert">{error}</p>}
          <button
            className="project-primary"
            data-devlab-id="project.open.submit"
            disabled={state.busy || !folderPath.startsWith('/')}
          >
            Open Folder
          </button>
        </form>
      )}
      <nav className="project-list" aria-label="Workspace projects">
        {state.projects.map((project) => (
          <button
            key={project.id}
            aria-label={`Select project ${project.label}`}
            aria-pressed={state.projectId === project.id}
            onClick={() => void owner.select(project.id).catch(() => {})}
            disabled={state.busy}
          >
            <Folder size={13} />
            <span>{project.label}</span>
            <small>{project.base ? 'BASE' : 'PROJECT'}</small>
          </button>
        ))}
      </nav>
      {previewWorkspace && <PreviewGroups workspace={previewWorkspace}/>}
      <ProjectAdoption
        key={state.projectId}
        client={client}
        projectId={state.projectId}
        onApplied={() => void owner.refresh()}
      />
      <div className="project-files-heading">
        <strong>{state.tree?.project.label ?? 'Loading…'}</strong>
        <span>
          {state.tree?.entries.filter((e) => e.kind === 'file').length ?? 0}{' '}
          files
        </span>
      </div>
      <div className="project-file-tree" role="tree" aria-label="Project files">
        {tree('')}
        {state.tree?.entries.length === 0 && (
          <p className="project-help">
            Empty project. Create a file on the build canvas.
          </p>
        )}
      </div>
      <footer className="project-location" title={state.tree?.project.location}>
        {state.tree?.project.location ?? 'Loading project…'}
      </footer>
    </aside>
  );
}
