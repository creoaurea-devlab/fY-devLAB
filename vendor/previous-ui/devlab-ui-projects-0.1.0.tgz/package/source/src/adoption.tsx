import { useEffect, useRef, useState } from 'react';
import type { WisdomInspection, WisdomProposal } from '@devlab/contracts';
import type { ApplicationClient } from '@devlab/ui-contracts';

/** Selection-scoped proposals; applying never silently replaces existing authority. */
export function ProjectAdoption({
  client,
  projectId,
  onApplied,
}: {
  client: ApplicationClient;
  projectId: string;
  onApplied?: () => void;
}) {
  const api = client.wisdom;
  const [inspection, setInspection] = useState<WisdomInspection | null>(null);
  const [proposal, setProposal] = useState<WisdomProposal | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState('');
  const epoch = useRef(0),
    operation = useRef(0),
    active = useRef(false);
  const selected = inspection?.projectId === projectId ? inspection : null;
  const reviewed = proposal?.projectId === projectId ? proposal : null;
  useEffect(() => {
    const generation = ++epoch.current;
    operation.current++;
    active.current = false;
    setInspection(null);
    setProposal(null);
    setMessage('');
    setError('');
    setBusy('inspect');
    if (!api) {
      setBusy('');
      return;
    }
    void api
      .inspect(projectId)
      .then((value) => {
        if (generation === epoch.current && value.projectId === projectId)
          setInspection(value);
      })
      .catch((reason) => {
        if (generation === epoch.current)
          setError(reason instanceof Error ? reason.message : String(reason));
      })
      .finally(() => {
        if (generation === epoch.current) setBusy('');
      });
    return () => {
      epoch.current++;
    };
  }, [api, projectId]);
  async function run(action: 'plan' | 'rules' | 'apply' | 'start') {
    if (active.current || (!api && action !== 'start')) return;
    const generation = epoch.current,
      request = ++operation.current;
    active.current = true;
    setBusy(action);
    setError('');
    setMessage('');
    const valid = () =>
      generation === epoch.current && request === operation.current;
    try {
      if (action === 'plan' || action === 'rules') {
        setProposal(null);
        const value = await api!.plan(projectId, {
          previewOnly: action !== 'rules' && selected?.status !== 'absent',
        });
        if (valid() && value.projectId === projectId) setProposal(value);
      } else if (action === 'apply') {
        if (!reviewed) return;
        const result = await api!.apply(projectId, reviewed.sha256);
        if (valid() && result.inspection.projectId === projectId) {
          setInspection(result.inspection);
          setProposal(null);
          setMessage(
            reviewed.previewOnly
              ? 'Preview setup saved. Choose Start preview. Existing project rules are preserved.'
              : `Applied ${result.added.length} file changes. Project population still requires its own readiness checks.`,
          );
          onApplied?.();
        }
      } else {
        if (!client.servers) return;
        const server = await client.servers.inspect(projectId);
        if (server.status === 'unconfigured' && !server.descriptor && api) {
          const value = await api.plan(projectId, { previewOnly: true });
          if (valid() && value.projectId === projectId) {
            setProposal(value);
            setMessage(
              'Review and apply the preview setup below, then choose Start preview.',
            );
          }
          return;
        }
        const started = await client.servers.start(projectId);
        if (started.status !== 'ready')
          throw new Error(
            started.error ?? `Preview start ended in ${started.status}`,
          );
        if (valid())
          setMessage('Preview server started. Check UI preview for readiness.');
      }
    } catch (reason) {
      if (valid())
        setError(reason instanceof Error ? reason.message : String(reason));
    } finally {
      if (valid()) {
        active.current = false;
        setBusy('');
      }
    }
  }
  return (
    <details
      className="project-adoption"
      aria-label="Project preparation"
      data-testid="project-adoption"
      data-devlab-project-id={projectId}
    >
      <summary>
        <strong>Project preparation</strong>
        <span role="status">
          {!api
            ? 'Unavailable'
            : (selected?.status ??
              (busy === 'inspect' ? 'Inspecting…' : 'Unknown'))}
        </span>
      </summary>
      <p>
        Wisdom rules and preview wiring belong to this folder. Installed
        templates require project population before readiness.
      </p>
      {selected?.version && <small>Wisdom {selected.version}</small>}
      {selected?.warnings.map((warning, i) => (
        <p key={i} className="project-adoption-warning">
          {warning}
        </p>
      ))}
      {error && <p role="alert">{error}</p>}
      {message && <p role="status">{message}</p>}
      <div className="project-adoption-actions">
        <button
          data-devlab-id="project.prepare"
          data-devlab-source="plugins/ui-projects/src/adoption.tsx"
          disabled={!api || !!busy}
          onClick={() => void run('plan')}
        >
          {busy === 'plan' ? 'Inspecting additions…' : 'Prepare project'}
        </button>
        <button
          data-devlab-id="project.preview.start"
          data-devlab-source="plugins/ui-projects/src/adoption.tsx"
          disabled={!client.servers || !!busy}
          onClick={() => void run('start')}
        >
          {busy === 'start' ? 'Starting preview…' : 'Start preview'}
        </button>
        {selected && selected.status !== 'absent' && (
          <button
            data-devlab-id="project.prepare.rules"
            data-devlab-source="plugins/ui-projects/src/adoption.tsx"
            disabled={!api || !!busy}
            onClick={() => void run('rules')}
          >
            Review Wisdom setup
          </button>
        )}
      </div>
      {selected && selected.status !== 'absent' && (
        <p>
          Prepare project configures the preview independently. Wisdom recovery
          follows this folder’s existing rules.
        </p>
      )}
      {reviewed && (
        <div
          className="project-adoption-review"
          aria-label="Review project preparation"
        >
          <strong>
            {reviewed.previewOnly
              ? 'Review preview setup'
              : 'Review preparation'}{' '}
            · {reviewed.changes.length} changes
          </strong>
          <small>Bundle {reviewed.bundleVersion}</small>
          {reviewed.warnings.map((warning, i) => (
            <p key={i} className="project-adoption-warning">
              {warning}
            </p>
          ))}
          {!!reviewed.conflicts.length && (
            <div>
              <strong>Existing files preserved</strong>
              <ul>
                {reviewed.conflicts.map((path) => (
                  <li key={path}>{path}</li>
                ))}
              </ul>
              <p>
                Conflicts remain unresolved. Review any candidate files before
                adopting them.
              </p>
            </div>
          )}
          {reviewed.changes.map((change) => (
            <details key={change.path}>
              <summary
                data-devlab-id={`project.prepare.change.${btoa(change.path).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '')}`}
              >
                {change.operation === 'append' ? 'Append rules' : 'Add'} ·{' '}
                {change.path}
              </summary>
              <pre>{change.text}</pre>
            </details>
          ))}
          {!reviewed.changes.length && (
            <p>
              No additive changes proposed. This does not establish project
              readiness.
            </p>
          )}
          {reviewed.targetGateRequired && (
            <p>
              Use this folder’s agent to apply the reviewed proposal through its
              existing rules.
            </p>
          )}
          <button
            data-devlab-id="project.prepare.apply"
            data-devlab-source="plugins/ui-projects/src/adoption.tsx"
            disabled={
              !!busy || !reviewed.changes.length || reviewed.targetGateRequired
            }
            onClick={() => void run('apply')}
          >
            {busy === 'apply'
              ? 'Applying…'
              : reviewed.previewOnly
                ? 'Apply preview setup'
                : 'Apply preparation'}
          </button>
          <button
            data-devlab-id="project.prepare.dismiss"
            data-devlab-source="plugins/ui-projects/src/adoption.tsx"
            disabled={!!busy}
            onClick={() => setProposal(null)}
          >
            Dismiss
          </button>
        </div>
      )}
    </details>
  );
}
