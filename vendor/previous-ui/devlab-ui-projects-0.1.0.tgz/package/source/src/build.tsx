import { useState, useSyncExternalStore } from 'react';
import { HoodView } from '@creoaurea/pop-the-hood/react';
import type { ProjectWorkspace } from '@devlab/ui-contracts';
import { ProjectEditor } from './editor.tsx';
export function ProjectBuild({ owner }: { owner: ProjectWorkspace }) {
  const state = useSyncExternalStore(owner.subscribe, owner.snapshot);
  const [form, setForm] = useState<'file' | 'module' | null>(null),
    [path, setPath] = useState(''),
    [error, setError] = useState('');
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    try {
      if (form === 'module') await owner.createModule(path);
      else owner.newFile(path);
      setForm(null);
    } catch (e) {
      setError(String(e));
    }
  };
  return (
    <section
      className="project-build"
      data-testid="project-build-canvas"
      aria-label="Project build canvas"
    >
      {form && (
        <form
          className="project-path-form"
          aria-label={form === 'file' ? 'Create file' : 'Create module'}
          onSubmit={submit}
        >
          <label>
            {form === 'file' ? 'File path' : 'Module directory'}
            <input
              data-devlab-source="plugins/ui-projects/src/build.tsx"
              data-devlab-id="build.path"
              aria-label={form === 'file' ? 'File path' : 'Module directory'}
              value={path}
              onChange={(e) => setPath(e.target.value)}
              required
              autoFocus
            />
          </label>
          <button
            data-devlab-source="plugins/ui-projects/src/build.tsx"
            data-devlab-id="build.path.submit"
            className="project-primary"
            disabled={state.busy}
          >
            {form === 'file' ? 'Open new file' : 'Create module'}
          </button>
          <button
            data-devlab-source="plugins/ui-projects/src/build.tsx"
            data-devlab-id="build.path.cancel"
            type="button"
            onClick={() => setForm(null)}
          >
            Cancel
          </button>
          {error && <p role="alert">{error}</p>}
        </form>
      )}
      <div className="project-build-body">
        <div className="project-build-graph">
          <HoodView
            key={state.projectId}
            client={owner.sourceClient()}
            presentation="embedded"
            title={`${state.tree?.project.label ?? 'Project'} · Build canvas`}
            toolbarActions={
              <div className="project-build-actions">
                <button
                  data-devlab-source="plugins/ui-projects/src/build.tsx"
                  data-devlab-id="build.new-file"
                  onClick={() => {
                    setForm('file');
                    setPath('src/new-file.ts');
                  }}
                >
                  New file
                </button>
                <button
                  data-devlab-source="plugins/ui-projects/src/build.tsx"
                  data-devlab-id="build.new-module"
                  onClick={() => {
                    setForm('module');
                    setPath('src/modules/new-feature');
                  }}
                >
                  New module
                </button>
                <label>
                  <input
                    data-devlab-source="plugins/ui-projects/src/build.tsx"
                    data-devlab-id="build.files"
                    aria-label="Show file nodes"
                    type="checkbox"
                    checked={state.showFiles}
                    onChange={(e) => owner.showFiles(e.target.checked)}
                  />{' '}
                  File nodes
                </label>
              </div>
            }
            initialDepth={state.projectId === 'default' ? 2 : 99}
            hideFiles={!state.showFiles}
            onSourceSelect={(path) => void owner.openFile(path)}
            theme="inherit"
          />
        </div>
        <ProjectEditor owner={owner} />
      </div>
    </section>
  );
}
