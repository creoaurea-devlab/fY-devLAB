import { randomUUID } from 'node:crypto';
import {
  ApplicationError,
  BrowserIdentitySchema,
  BrowserActorSchema,
  BrowserTargetSchema,
  BrowserConfigSchema,
  BrowserCommandSchema,
  BrowserLeaseSchema,
  ProjectIdSchema,
  type CanvasGraph,
  type PluginDefinition,
  type BrowserIdentity,
  type BrowserActor,
  type BrowserTarget,
  type BrowserLease,
} from '@devlab/contracts';

/** Trusted local actors coordinate through fenced leases; saved wires are checked per operation. */
export function browserHarness(leaseMs = 30000): PluginDefinition {
  return {
    manifest: {
      id: 'browser-harness',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['browserControl'],
      requires: ['browsers', 'canvas'],
      capabilities: [],
      reload: 'restart',
    },
    activate(scope) {
      const host = scope.get('browsers'),
        canvas = scope.get('canvas');
      const leases = new Map<
        string,
        { lease: BrowserLease; commands: Set<string> }
      >();
      const queues = new Map<
        string,
        { tail: Promise<unknown>; size: number }
      >();
      let closed = false;
      const key = (i: BrowserIdentity) => `${i.projectId}/${i.browserId}`;
      const owner = (k: string) => {
        const state = leases.get(k);
        if (state && state.lease.expiresAt <= Date.now()) {
          leases.delete(k);
          return undefined;
        }
        return state;
      };
      function serial<T>(
        identity: BrowserIdentity,
        work: () => Promise<T>,
      ): Promise<T> {
        if (closed)
          return Promise.reject(
            new ApplicationError('NOT_READY', 'Browser harness is closed'),
          );
        const k = key(identity),
          queue = queues.get(k) ?? { tail: Promise.resolve(), size: 0 };
        if (queue.size >= 32)
          return Promise.reject(
            new ApplicationError(
              'BROWSER_BUSY',
              'Browser command queue is full; wait before sending more',
            ),
          );
        queue.size++;
        queues.set(k, queue);
        const result = queue.tail
          .catch(() => {})
          .then(() => {
            if (closed)
              throw new ApplicationError(
                'NOT_READY',
                'Browser harness is closed',
              );
            return work();
          });
        queue.tail = result;
        void result
          .finally(() => {
            if (--queue.size === 0 && queues.get(k) === queue) queues.delete(k);
          })
          .catch(() => {});
        return result;
      }
      function wires(graph: CanvasGraph, browserId: string) {
        const agents = new Set(
          graph.nodes
            .filter((n) => n.type === 'piAgent' || n.type === 'subagent')
            .map((n) => n.id),
        );
        return [
          ...new Set(
            graph.edges
              .filter(
                (e) =>
                  e.target === browserId &&
                  e.targetHandle === 'control' &&
                  agents.has(e.source),
              )
              .map((e) => e.source),
          ),
        ];
      }
      async function saved(identity: BrowserIdentity, actor?: BrowserActor) {
        const document = await canvas.load(identity.projectId),
          graph = document?.graph;
        const node = graph?.nodes.find(
          (n) => n.id === identity.browserId && n.type === 'browser',
        );
        if (!node || !graph)
          throw new ApplicationError(
            'BROWSER_NODE_MISSING',
            'Save this browser node on its project canvas before starting or controlling it',
          );
        const wired = wires(graph, node.id);
        if (actor?.kind === 'agent' && !wired.includes(actor.id))
          throw new ApplicationError(
            'BROWSER_WIRE_DENIED',
            'Save an agent output → browser control wire on this project canvas',
          );
        return { node, wired };
      }
      function current(target: BrowserTarget) {
        const session = host.inspect({
          projectId: target.projectId,
          browserId: target.browserId,
        });
        if (!session)
          throw new ApplicationError(
            'BROWSER_NOT_RUNNING',
            'Browser is stopped; Start it explicitly',
          );
        if (session.generation !== target.generation)
          throw new ApplicationError(
            'BROWSER_STALE_GENERATION',
            'Browser restarted; discover it and acquire a new lease',
          );
        if (!session.pages.some((p) => p.id === target.pageId))
          throw new ApplicationError(
            'BROWSER_PAGE_GONE',
            'Page no longer exists; discover the browser again',
          );
        return session;
      }
      function authorize(
        input: Pick<
          BrowserLease,
          'projectId' | 'browserId' | 'generation' | 'token' | 'actor'
        >,
      ) {
        const state = owner(key(input));
        if (
          !state ||
          state.lease.token !== input.token ||
          state.lease.generation !== input.generation ||
          state.lease.actor.kind !== input.actor.kind ||
          state.lease.actor.id !== input.actor.id
        )
          throw new ApplicationError(
            'BROWSER_LEASE_DENIED',
            'Control lease is missing, expired or replaced; acquire this exact browser again',
          );
        return state;
      }
      function publicOwner(
        identity: BrowserIdentity,
      ): Omit<BrowserLease, 'token'> | null {
        const state = owner(key(identity));
        if (!state) return null;
        const { token: _token, ...visible } = state.lease;
        return { ...visible, actor: { ...visible.actor } };
      }
      scope.onDispose(async () => {
        closed = true;
        leases.clear();
        await Promise.allSettled([...queues.values()].map((q) => q.tail));
        queues.clear();
      });
      scope.provide('browserControl', {
        async discover(raw) {
          const projectId = ProjectIdSchema.parse(raw),
            document = await canvas.load(projectId);
          const entries = [];
          for (const node of document?.graph.nodes ?? []) {
            if (node.type !== 'browser') continue;
            const identity = { projectId, browserId: node.id },
              wired = wires(document!.graph, node.id);
            entries.push({
              ...identity,
              label: String(node.data.label ?? 'Browser'),
              url: String(node.data.url ?? 'about:blank'),
              mode:
                node.data.mode === 'temporary'
                  ? ('temporary' as const)
                  : ('persistent' as const),
              wiredAgentIds: wired,
              session: host.inspect(identity),
              owner: publicOwner(identity),
            });
          }
          for (const session of host.list(projectId)) {
            if (entries.some((e) => e.browserId === session.browserId))
              continue;
            const identity = { projectId, browserId: session.browserId };
            entries.push({
              ...identity,
              label: 'Detached browser',
              url:
                session.pages.find((p) => p.id === session.activePageId)?.url ??
                'about:blank',
              mode: session.mode,
              wiredAgentIds: [],
              session,
              owner: publicOwner(identity),
            });
          }
          return entries;
        },
        start(raw, rawActor) {
          const identity = BrowserIdentitySchema.parse(raw),
            actor = BrowserActorSchema.parse(rawActor);
          return serial(identity, async () => {
            const { node } = await saved(identity, actor);
            return host.start(
              BrowserConfigSchema.parse({
                ...identity,
                url: node.data.url ?? 'about:blank',
                mode: node.data.mode ?? 'persistent',
              }),
            );
          });
        },
        acquire(raw, rawActor, takeover = false) {
          const target = BrowserTargetSchema.parse(raw),
            actor = BrowserActorSchema.parse(rawActor);
          return serial(target, async () => {
            if (
              actor.kind !== 'human' ||
              !host.inspect({
                projectId: target.projectId,
                browserId: target.browserId,
              })
            )
              await saved(target, actor);
            current(target);
            const k = key(target);
            if (leases.get(k)?.lease.generation !== target.generation)
              leases.delete(k);
            const state = owner(k);
            if (
              state &&
              state.lease.actor.kind === actor.kind &&
              state.lease.actor.id === actor.id &&
              state.lease.generation === target.generation
            ) {
              state.lease.expiresAt = Date.now() + leaseMs;
              return { ...state.lease, actor: { ...state.lease.actor } };
            }
            if (state && !(takeover && actor.kind === 'human'))
              throw new ApplicationError(
                'BROWSER_LOCKED',
                `Browser is controlled by ${state.lease.actor.kind} ${state.lease.actor.id}`,
              );
            const lease = {
              projectId: target.projectId,
              browserId: target.browserId,
              generation: target.generation,
              actor,
              token: randomUUID(),
              expiresAt: Date.now() + leaseMs,
            };
            leases.set(k, { lease, commands: new Set() });
            return { ...lease, actor: { ...lease.actor } };
          });
        },
        async command(raw) {
          const input = BrowserCommandSchema.parse(raw);
          const execute = async () => {
            if (input.action.op !== 'stop' || input.actor.kind !== 'human')
              await saved(input, input.actor);
            current(input);
            const state = authorize(input);
            if (state.commands.has(input.commandId))
              throw new ApplicationError(
                'BROWSER_DUPLICATE_COMMAND',
                'Command ID was already submitted; observe before deciding on a new operation',
              );
            if (state.commands.size >= 4096)
              throw new ApplicationError(
                'BROWSER_LIMIT',
                'Release and reacquire control after 4096 commands',
              );
            state.commands.add(input.commandId);
            state.lease.expiresAt = Date.now() + leaseMs;
            if (input.action.op === 'stop') {
              leases.delete(key(input));
              await host.stop({
                projectId: input.projectId,
                browserId: input.browserId,
              });
              return { session: null };
            }
            if (input.action.op === 'heartbeat')
              return { session: current(input) };
            const result = await host.execute(
              {
                projectId: input.projectId,
                browserId: input.browserId,
                generation: input.generation,
                pageId: input.pageId,
              },
              input.action,
            );
            authorize(input);
            if (input.action.op === 'screenshot')
              return {
                ...result,
                image: await host.frame({
                  projectId: input.projectId,
                  browserId: input.browserId,
                  generation: input.generation,
                  pageId: input.pageId,
                }),
              };
            return result;
          };
          // Closing the context cancels native work immediately. New owners wait for both tails.
          if (input.action.op === 'stop') {
            const k = key(input),
              before = queues.get(k)?.tail ?? Promise.resolve();
            const result = execute();
            const barrier = Promise.allSettled([before, result]);
            const queue = { tail: barrier, size: 1 };
            queues.set(k, queue);
            void barrier.then(() => {
              if (--queue.size === 0 && queues.get(k) === queue)
                queues.delete(k);
            });
            return result;
          }
          return serial(input, execute);
        },
        release(raw) {
          const lease = BrowserLeaseSchema.parse(raw);
          return serial(lease, async () => {
            authorize(lease);
            leases.delete(key(lease));
          });
        },
        async frame(raw) {
          const target = BrowserTargetSchema.parse(raw);
          await saved(target);
          current(target);
          return host.frame(target);
        },
        clearProfile(raw, rawActor) {
          const identity = BrowserIdentitySchema.parse(raw),
            actor = BrowserActorSchema.parse(rawActor);
          return serial(identity, async () => {
            if (actor.kind !== 'human')
              throw new ApplicationError(
                'BROWSER_LEASE_DENIED',
                'Only an explicit human action can clear browser data',
              );
            await saved(identity, actor);
            if (owner(key(identity)))
              throw new ApplicationError(
                'BROWSER_LOCKED',
                'Release control and Stop before clearing browsing data',
              );
            await host.clearProfile(identity);
          });
        },
      });
    },
  };
}
