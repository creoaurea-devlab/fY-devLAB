import { Worker } from 'node:worker_threads';
import { createServer } from 'node:net';
import { createHash } from 'node:crypto';
import { mkdir, realpath } from 'node:fs/promises';
import { join } from 'node:path';
import {
  ApplicationError,
  type PluginDefinition,
  type RunStore,
} from '@devlab/contracts';

/** Linux abstract socket is an OS-owned lock: crash releases it without stale-lock guessing. */
export function sqliteStore(directory: string): PluginDefinition {
  return {
    manifest: {
      id: 'store-sqlite',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['store'],
      requires: [],
      capabilities: ['storage:local'],
      reload: 'restart',
    },
    async activate(scope) {
      if (process.platform !== 'linux')
        throw new ApplicationError(
          'PLATFORM_UNSUPPORTED',
          'This local store lock currently requires Linux',
        );
      await mkdir(directory, { recursive: true, mode: 0o700 });
      const root = await realpath(directory);
      const lock = createServer((socket) => socket.destroy());
      await new Promise<void>((resolve, reject) => {
        lock.once('error', reject);
        lock.listen(
          `\0devlab-${createHash('sha256').update(root).digest('hex')}`,
          () => {
            lock.removeListener('error', reject);
            resolve();
          },
        );
      }).catch((error) => {
        throw new ApplicationError(
          'STORE_OWNED',
          `Store is already owned or cannot be locked: ${String(error)}`,
        );
      });
      let shutdown: () => Promise<void> = async () => {};
      scope.onDispose(async () => {
        try {
          await shutdown();
        } finally {
          await new Promise<void>((resolve, reject) =>
            lock.close((error) => (error ? reject(error) : resolve())),
          );
        }
      });
      const worker = new Worker(
        new URL('./store-worker.mjs', import.meta.url),
        { workerData: { file: join(root, 'runs.sqlite') } },
      );
      let counter = 0,
        closed = false;
      const pending = new Map<
        number,
        { resolve: (value: unknown) => void; reject: (error: Error) => void }
      >();
      let readyResolve: () => void, readyReject: (error: Error) => void;
      const ready = new Promise<void>((resolve, reject) => {
        readyResolve = resolve;
        readyReject = reject;
      });
      const fail = (error: Error) => {
        closed = true;
        readyReject(error);
        for (const request of pending.values()) request.reject(error);
        pending.clear();
      };
      worker.on('error', fail);
      worker.on('exit', (code) => {
        if (!closed)
          fail(
            new ApplicationError('STORE_EXIT', `Store worker exited (${code})`),
          );
      });
      worker.on(
        'message',
        (message: {
          ready?: boolean;
          id: number;
          value?: unknown;
          error?: { code: string; message: string };
        }) => {
          if (message.ready) {
            readyResolve();
            return;
          }
          const request = pending.get(message.id);
          if (!request) return;
          pending.delete(message.id);
          if (message.error)
            request.reject(
              new ApplicationError(message.error.code, message.error.message),
            );
          else request.resolve(message.value);
        },
      );
      const call = (method: string, args: unknown[]): Promise<unknown> => {
        if (closed)
          return Promise.reject(
            new ApplicationError('STORE_CLOSED', 'Store is closed'),
          );
        const id = ++counter;
        return new Promise((resolve, reject) => {
          pending.set(id, { resolve, reject });
          worker.postMessage({ id, method, args });
        });
      };
      // Worker cleanup is registered before readiness so failed setup cannot leak it.
      shutdown = async () => {
        try {
          if (!closed) await call('close', []);
        } finally {
          closed = true;
          await worker.terminate();
        }
      };
      await ready;
      const store: RunStore = {
        create: async (command) =>
          (await call('create', [command])) as Awaited<
            ReturnType<RunStore['create']>
          >,
        read: async (id) =>
          (await call('read', [id])) as Awaited<ReturnType<RunStore['read']>>,
        list: async () =>
          (await call('list', [])) as Awaited<ReturnType<RunStore['list']>>,
        append: async (id, seq, event) =>
          (await call('append', [id, seq, event])) as Awaited<
            ReturnType<RunStore['append']>
          >,
      };
      scope.provide('store', store);
    },
  };
}
