import { DatabaseSync } from 'node:sqlite';
import { parentPort, workerData } from 'node:worker_threads';
import { chmodSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import {
  ApplicationError,
  canonicalJson,
  EventInputSchema,
  StartCommandSchema,
  type Journal,
  type RunEvent,
} from '@devlab/contracts';

if (!parentPort) throw new Error('SQLite must run in its owned worker');
const port = parentPort;
const db = new DatabaseSync(
  z.object({ file: z.string() }).parse(workerData).file,
);
chmodSync(workerData.file, 0o600);
db.exec(
  'PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA busy_timeout=3000;',
);
const version = (
  db.prepare('PRAGMA user_version').get() as { user_version: number }
).user_version;
if (version !== 0 && version !== 1)
  throw new Error(`Unsupported database schema ${version}`);
db.exec(`CREATE TABLE IF NOT EXISTS runs(run_id TEXT PRIMARY KEY,command_id TEXT UNIQUE NOT NULL,request TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(run_id TEXT NOT NULL REFERENCES runs(run_id),seq INTEGER NOT NULL,event_id TEXT UNIQUE NOT NULL,at TEXT NOT NULL,input TEXT NOT NULL,PRIMARY KEY(run_id,seq));
PRAGMA foreign_keys=ON; PRAGMA user_version=1;`);

function read(runId: string): Journal {
  const row = db
    .prepare('SELECT request FROM runs WHERE run_id=?')
    .get(runId) as { request: string } | undefined;
  if (!row)
    throw new ApplicationError('RUN_NOT_FOUND', `Unknown run '${runId}'`);
  const rows = db
    .prepare(
      'SELECT seq,event_id,at,input FROM events WHERE run_id=? ORDER BY seq LIMIT 10001',
    )
    .all(runId) as {
    seq: number;
    event_id: string;
    at: string;
    input: string;
  }[];
  if (rows.length > 10000)
    throw new ApplicationError(
      'JOURNAL_LIMIT',
      'Run journal exceeds the local profile limit',
    );
  const events: RunEvent[] = rows.map((r) => ({
    seq: r.seq,
    eventId: r.event_id,
    at: r.at,
    schemaVersion: 1,
    input: EventInputSchema.parse(JSON.parse(r.input)),
  }));
  return {
    runId,
    command: StartCommandSchema.parse(JSON.parse(row.request)),
    events,
  };
}
function append(runId: string, seq: number, input: unknown): void {
  const event = EventInputSchema.parse(input);
  db.prepare(
    'INSERT INTO events(run_id,seq,event_id,at,input) VALUES(?,?,?,?,?)',
  ).run(
    runId,
    seq,
    randomUUID(),
    new Date().toISOString(),
    JSON.stringify(event),
  );
}
function transaction<T>(fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const value = fn();
    db.exec('COMMIT');
    return value;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}
const Message = z
  .object({
    id: z.number().int(),
    method: z.enum(['create', 'read', 'list', 'append', 'close']),
    args: z.array(z.unknown()),
  })
  .strict();
port.on('message', (raw: unknown) => {
  const parsed = Message.safeParse(raw);
  if (!parsed.success) {
    port.postMessage({
      id: -1,
      error: { code: 'INVALID_STORE_MESSAGE', message: parsed.error.message },
    });
    return;
  }
  const { id, method, args } = parsed.data;
  try {
    let value: unknown;
    if (method === 'create') {
      const command = StartCommandSchema.parse(args[0]);
      value = transaction(() => {
        const existing = db
          .prepare('SELECT run_id,request FROM runs WHERE command_id=?')
          .get(command.commandId) as
          | { run_id: string; request: string }
          | undefined;
        if (existing) {
          if (existing.request !== canonicalJson(command))
            throw new ApplicationError(
              'COMMAND_CONFLICT',
              'Command ID was reused with different input',
            );
          return read(existing.run_id);
        }
        const runId = randomUUID();
        db.prepare('INSERT INTO runs VALUES(?,?,?)').run(
          runId,
          command.commandId,
          canonicalJson(command),
        );
        append(runId, 1, { type: 'run.created', data: command });
        return read(runId);
      });
    } else if (method === 'read') value = read(z.string().parse(args[0]));
    else if (method === 'list') {
      const rows = db
        .prepare('SELECT run_id FROM runs ORDER BY rowid DESC LIMIT 50')
        .all() as { run_id: string }[];
      value = rows.map((r) => read(r.run_id));
    } else if (method === 'append') {
      const runId = z.string().parse(args[0]),
        expected = z.number().int().min(1).parse(args[1]);
      value = transaction(() => {
        const journal = read(runId);
        if (journal.events.length !== expected)
          throw new ApplicationError(
            'REVISION_CONFLICT',
            'Run sequence changed',
          );
        if (expected >= 10000)
          throw new ApplicationError('JOURNAL_LIMIT', 'Run journal is full');
        append(runId, expected + 1, args[2]);
        return read(runId);
      });
    } else {
      db.close();
      port.postMessage({ id, value: null });
      port.close();
      return;
    }
    port.postMessage({ id, value });
  } catch (error) {
    port.postMessage({
      id,
      error: {
        code: error instanceof ApplicationError ? error.code : 'STORE_ERROR',
        message: error instanceof Error ? error.message : String(error),
      },
    });
  }
});
port.postMessage({
  ready: true,
  sqlite: (db.prepare('SELECT sqlite_version() AS v').get() as { v: string }).v,
});
