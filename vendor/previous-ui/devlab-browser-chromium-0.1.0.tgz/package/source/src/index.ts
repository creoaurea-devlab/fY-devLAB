import { mkdir, realpath, lstat, rm, mkdtemp, chmod } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import {
  ApplicationError,
  BrowserConfigSchema,
  BrowserIdentitySchema,
  BrowserTargetSchema,
  BrowserActionSchema,
  type PluginDefinition,
  type BrowserAdapter,
  type BrowserConfig,
  type BrowserFrame,
  type BrowserSession,
} from '@devlab/contracts';

/** Profiles contain credentials. They never enter canvas/source/registry data. */
export function chromiumBrowser(directory: string): PluginDefinition {
  return {
    manifest: {
      id: 'browser-chromium',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['browsers'],
      requires: ['workspace'],
      capabilities: ['browser:local', 'storage:local'],
      reload: 'restart',
    },
    async activate(scope) {
      const workspace = scope.get('workspace');
      type Live = {
        config: BrowserConfig;
        generation: string;
        adapter: BrowserAdapter;
        temporary: string | null;
        frame?: BrowserFrame;
        capture?: Promise<BrowserFrame>;
        frameAt: number;
      };
      const sessions = new Map<string, Live>();
      const pending = new Map<string, Promise<BrowserSession>>();
      const retiring = new Map<string, Promise<void>>();
      let closed = false;
      const identityOf = (input: { projectId: string; browserId: string }) =>
        BrowserIdentitySchema.parse({
          projectId: input.projectId,
          browserId: input.browserId,
        });
      const key = (input: { projectId: string; browserId: string }) =>
        `${input.projectId}/${input.browserId}`;
      const ready = () => {
        if (closed)
          throw new ApplicationError('NOT_READY', 'Browser host is closed');
      };
      const snapshot = (s: Live): BrowserSession => {
        const { url: _url, ...identity } = s.config;
        const view = s.adapter.snapshot();
        return {
          ...identity,
          ...view,
          viewport: { ...view.viewport },
          generation: s.generation,
        };
      };
      async function folder(projectId: string) {
        // Refuse redirected profile roots and children; never unlink another browser's locks.
        const root = resolve(directory);
        await mkdir(root, { recursive: true, mode: 0o700 });
        if (
          (await lstat(root)).isSymbolicLink() ||
          (await realpath(root)) !== root
        )
          throw new ApplicationError(
            'PATH_DENIED',
            'Browser profile root cannot contain symlinks',
          );
        await chmod(root, 0o700);
        const project = join(root, projectId);
        await mkdir(project, { recursive: true, mode: 0o700 });
        if ((await lstat(project)).isSymbolicLink())
          throw new ApplicationError(
            'PATH_DENIED',
            'Browser project profile cannot be a symlink',
          );
        return project;
      }
      async function stop(input: { projectId: string; browserId: string }) {
        const identity = identityOf(input),
          k = key(identity);
        await pending.get(k)?.catch(() => {});
        await retiring.get(k);
        const s = sessions.get(k);
        if (!s) return;
        sessions.delete(k);
        try {
          await s.adapter.close();
        } finally {
          if (s.temporary)
            await rm(s.temporary, { recursive: true, force: true });
        }
      }
      const targetSession = (input: unknown) => {
        ready();
        const target = BrowserTargetSchema.parse(input),
          live = sessions.get(key(target));
        if (!live)
          throw new ApplicationError(
            'BROWSER_NOT_RUNNING',
            'Browser is stopped; Start it explicitly',
          );
        if (live.generation !== target.generation)
          throw new ApplicationError(
            'BROWSER_STALE_GENERATION',
            'Browser restarted; acquire control for the new generation',
          );
        const state = live.adapter.snapshot();
        if (!state.pages.some((p) => p.id === target.pageId))
          throw new ApplicationError(
            'BROWSER_PAGE_GONE',
            'Page no longer exists; inspect the browser again',
          );
        return { target, live };
      };
      scope.onDispose(async () => {
        closed = true;
        await Promise.allSettled([...pending.values()]);
        await Promise.all([...sessions.values()].map((s) => stop(s.config)));
        await Promise.all([...retiring.values()]);
      });
      scope.provide('browsers', {
        list(projectId) {
          ready();
          return [...sessions.values()]
            .filter((s) => s.config.projectId === projectId)
            .map(snapshot);
        },
        inspect(input) {
          ready();
          const s = sessions.get(key(identityOf(input)));
          return s ? snapshot(s) : null;
        },
        async start(input) {
          ready();
          const config = BrowserConfigSchema.parse(input),
            k = key(config);
          const existing = sessions.get(k);
          if (existing) return snapshot(existing);
          const starting = pending.get(k);
          if (starting) return starting;
          if (sessions.size + pending.size >= 4)
            throw new ApplicationError(
              'BROWSER_LIMIT',
              'Stop a browser before starting another (maximum 4)',
            );
          const launch = (async () => {
            await retiring.get(k);
            await workspace.resolve(config.projectId, '.');
            const project = await folder(config.projectId);
            const path =
              config.mode === 'temporary'
                ? await mkdtemp(join(project, '.temporary-'))
                : join(project, config.browserId);
            await mkdir(path, { recursive: true, mode: 0o700 });
            if ((await lstat(path)).isSymbolicLink())
              throw new ApplicationError(
                'PATH_DENIED',
                'Browser profile cannot be a symlink',
              );
            try {
              const { openChromium } = await import('./playwright.ts');
              const generation = randomUUID();
              const adapter = await openChromium(path, config, () => {
                const current = sessions.get(k);
                if (current?.generation !== generation) return;
                sessions.delete(k);
                const cleanup = current.adapter
                  .close()
                  .then(async () => {
                    if (current.temporary)
                      await rm(current.temporary, {
                        recursive: true,
                        force: true,
                      });
                  })
                  .finally(() => {
                    retiring.delete(k);
                  });
                retiring.set(k, cleanup);
                void cleanup.catch(() => {});
              });
              if (closed) {
                await adapter.close();
                throw new ApplicationError(
                  'NOT_READY',
                  'Host closed during browser Start',
                );
              }
              const s: Live = {
                config,
                generation,
                adapter,
                temporary: config.mode === 'temporary' ? path : null,
                frameAt: 0,
              };
              sessions.set(k, s);
              return snapshot(s);
            } catch (error) {
              if (config.mode === 'temporary')
                await rm(path, { recursive: true, force: true });
              if (error instanceof ApplicationError) throw error;
              throw new ApplicationError(
                'BROWSER_START_FAILED',
                'Chromium could not start. Run npm run browser:install; check system libraries, Chromium sandbox support and whether this profile is already open.',
              );
            }
          })();
          pending.set(k, launch);
          try {
            return await launch;
          } finally {
            pending.delete(k);
          }
        },
        async execute(input, raw) {
          const { target, live } = targetSession(input),
            action = BrowserActionSchema.parse(raw);
          try {
            const extra = await live.adapter.execute(target.pageId, action);
            if (action.op === 'stop') {
              await stop(target);
              return { session: null };
            }
            live.frame = undefined;
            return { session: snapshot(live), ...extra };
          } catch (error) {
            if (error instanceof ApplicationError) throw error;
            // Native call logs can contain typed credentials or page content.
            throw new ApplicationError(
              'BROWSER_ACTION_FAILED',
              `${action.op} failed or timed out; inspect/observe the exact browser and retry deliberately`,
            );
          }
        },
        async frame(input) {
          const { target, live } = targetSession(input);
          if (target.pageId !== live.adapter.snapshot().activePageId)
            throw new ApplicationError(
              'BROWSER_STALE_PAGE',
              'Active tab changed; inspect again',
            );
          if (live.capture) return live.capture;
          if (live.frame && Date.now() - live.frameAt < 250) return live.frame;
          live.capture = live.adapter
            .frame(target.pageId)
            .then((frame) => {
              if (live.adapter.snapshot().activePageId !== target.pageId)
                throw new Error('Tab changed');
              live.frame = { target, mime: 'image/jpeg', ...frame };
              live.frameAt = Date.now();
              return live.frame;
            })
            .catch(() => {
              live.frame = undefined;
              throw new ApplicationError(
                'BROWSER_FRAME_FAILED',
                'Frame unavailable; reconnect to the current browser/page',
              );
            })
            .finally(() => {
              live.capture = undefined;
            });
          return live.capture;
        },
        stop,
        async clearProfile(input) {
          ready();
          const identity = identityOf(input),
            k = key(identity);
          if (sessions.has(k) || pending.has(k))
            throw new ApplicationError(
              'BROWSER_BUSY',
              'Stop the browser before clearing its profile',
            );
          await retiring.get(k);
          await workspace.resolve(identity.projectId, '.');
          const project = await folder(identity.projectId),
            path = join(project, identity.browserId);
          const info = await lstat(path).catch((e: NodeJS.ErrnoException) => {
            if (e.code !== 'ENOENT') throw e;
            return null;
          });
          if (info?.isSymbolicLink())
            throw new ApplicationError(
              'PATH_DENIED',
              'Browser profile cannot be a symlink',
            );
          // Chromium creates SingletonLock while another process owns the profile.
          const lock = await lstat(join(path, 'SingletonLock')).catch(
            (e: NodeJS.ErrnoException) => {
              if (e.code !== 'ENOENT') throw e;
              return null;
            },
          );
          if (lock)
            throw new ApplicationError(
              'BROWSER_BUSY',
              'Profile has a Chromium lock; close its owner before clearing',
            );
          await rm(path, { recursive: true, force: true });
        },
      });
    },
  };
}
