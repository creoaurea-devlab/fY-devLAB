import {
  ApplicationError,
  type BrowserAdapter,
  type BrowserConfig,
  type BrowserAction,
} from '@devlab/contracts';
import { randomUUID } from 'node:crypto';
import { stat } from 'node:fs/promises';
import type { Page, Locator } from 'playwright-core';

/** One native context owns both automation and the canvas view. Imported only on Start. */
export async function openChromium(
  directory: string,
  config: BrowserConfig,
  onClosed: () => void,
): Promise<BrowserAdapter> {
  const { chromium } = await import('playwright-core');
  const env = Object.fromEntries(
    Object.entries(process.env).filter(
      ([key, value]) =>
        value !== undefined &&
        /^(PATH|HOME|USER|LOGNAME|LANG|LC_.*|TZ|TMPDIR|LD_LIBRARY_PATH)$/.test(
          key,
        ),
    ),
  ) as Record<string, string>;
  // Ubuntu can restrict unprivileged namespaces. Reuse an installed, root-owned
  // native sandbox helper instead of weakening browser isolation or changing the OS.
  for (const path of [
    process.env.CHROME_DEVEL_SANDBOX,
    '/opt/google/chrome/chrome-sandbox',
    '/usr/lib/chromium/chrome-sandbox',
  ]) {
    if (!path) continue;
    const info = await stat(path).catch(() => null);
    if (
      info?.isFile() &&
      info.uid === 0 &&
      (info.mode & 0o4000) !== 0 &&
      (info.mode & 0o022) === 0
    ) {
      env.CHROME_DEVEL_SANDBOX = path;
      break;
    }
  }
  const context = await chromium.launchPersistentContext(directory, {
    headless: true,
    chromiumSandbox: true,
    viewport: config.viewport,
    deviceScaleFactor: 1,
    acceptDownloads: false,
    timeout: 15000,
    env,
  });
  context.setDefaultTimeout(5000);
  context.setDefaultNavigationTimeout(10000);
  const pages = new Map<string, Page>();
  let activePageId = '',
    viewport = config.viewport,
    closing = false;
  context.on('close', () => {
    closing = true;
    onClosed();
  });
  function register(page: Page) {
    if ([...pages.values()].includes(page)) return;
    if (pages.size >= 12) {
      void page.close().catch(() => {});
      return;
    }
    const id = randomUUID();
    pages.set(id, page);
    activePageId = id;
    page.on('dialog', (dialog) => void dialog.dismiss().catch(() => {}));
    page.on('download', (download) => void download.cancel().catch(() => {}));
    page.on('close', () => {
      pages.delete(id);
      if (activePageId === id) activePageId = pages.keys().next().value ?? id;
      if (!pages.size && !closing)
        void context
          .newPage()
          .then(register)
          .catch(() => {});
    });
  }
  context.on('page', register);
  for (const page of context.pages()) register(page);
  try {
    if (!pages.size) register(await context.newPage());
    const initial = pages.get(activePageId)!;
    if (config.url !== 'about:blank')
      await initial.goto(config.url, { waitUntil: 'domcontentloaded' });
  } catch (error) {
    await context.close();
    throw error;
  }
  const pageFor = (id: string) => {
    const page = pages.get(id);
    if (!page || page.isClosed())
      throw new ApplicationError(
        'BROWSER_PAGE_GONE',
        'Page no longer exists; inspect the browser again',
      );
    return page;
  };
  function locate(
    page: Page,
    input: Extract<BrowserAction, { op: 'click' }>['locator'],
  ): Locator {
    const root = input.frame ? page.frameLocator(input.frame) : page;
    switch (input.by) {
      case 'role':
        return root.getByRole(input.value as Parameters<Page['getByRole']>[0], {
          name: input.name,
          exact: input.exact,
        });
      case 'label':
        return root.getByLabel(input.value, { exact: input.exact });
      case 'text':
        return root.getByText(input.value, { exact: input.exact });
      case 'placeholder':
        return root.getByPlaceholder(input.value, { exact: input.exact });
      case 'testId':
        return root.getByTestId(input.value);
      case 'css':
        return root.locator(input.value);
    }
  }
  return {
    snapshot: () => ({
      activePageId,
      viewport,
      pages: [...pages].map(([id, page]) => ({
        id,
        url: page.url().slice(0, 8192),
      })),
    }),
    async execute(pageId, action) {
      const page = pageFor(pageId);
      // Commands target the visible tab; an old screenshot cannot steer a hidden tab.
      if (pageId !== activePageId)
        throw new ApplicationError(
          'BROWSER_STALE_PAGE',
          'Active tab changed; inspect the browser again',
        );
      switch (action.op) {
        case 'observe': {
          const aria = await page
            .locator('body')
            .ariaSnapshot({ timeout: 5000 });
          return {
            observation: {
              title: (await page.title()).slice(0, 1024),
              url: page.url().slice(0, 8192),
              aria: aria.slice(0, 16000),
              truncated: aria.length > 16000,
            },
          };
        }
        case 'navigate':
          await page.goto(action.url, { waitUntil: 'domcontentloaded' });
          break;
        case 'back':
          await page.goBack({ waitUntil: 'domcontentloaded' });
          break;
        case 'forward':
          await page.goForward({ waitUntil: 'domcontentloaded' });
          break;
        case 'reload':
          await page.reload({ waitUntil: 'domcontentloaded' });
          break;
        case 'click':
          await locate(page, action.locator).click();
          break;
        case 'fill':
          await locate(page, action.locator).fill(action.text);
          break;
        case 'select':
          await locate(page, action.locator).selectOption(action.value);
          break;
        case 'press':
          await page.keyboard.press(action.key);
          break;
        case 'type':
          await page.keyboard.insertText(action.text);
          break;
        case 'pointer': {
          if (
            action.viewport.width !== viewport.width ||
            action.viewport.height !== viewport.height
          )
            throw new ApplicationError(
              'BROWSER_STALE_VIEWPORT',
              'Viewport changed; request a fresh frame before pointing',
            );
          if (action.x >= viewport.width || action.y >= viewport.height)
            throw new ApplicationError(
              'INVALID_INPUT',
              'Pointer is outside browser viewport',
            );
          await page.mouse.move(action.x, action.y);
          if (action.phase !== 'move')
            await page.mouse[action.phase]({ button: action.button });
          break;
        }
        case 'scroll':
          await page.mouse.wheel(action.deltaX, action.deltaY);
          break;
        case 'resize':
          await Promise.all(
            [...pages.values()].map((p) => p.setViewportSize(action.viewport)),
          );
          viewport = action.viewport;
          break;
        case 'newTab': {
          if (pages.size >= 12)
            throw new ApplicationError(
              'BROWSER_LIMIT',
              'Maximum 12 tabs per browser',
            );
          const next = await context.newPage();
          register(next);
          if (action.url !== 'about:blank')
            await next.goto(action.url, { waitUntil: 'domcontentloaded' });
          break;
        }
        case 'selectTab':
          await pageFor(action.pageId).bringToFront();
          activePageId = action.pageId;
          break;
        case 'closeTab':
          if (pages.size === 1) register(await context.newPage());
          await page.close();
          break;
        case 'screenshot':
        case 'heartbeat':
          break;
        case 'stop':
          closing = true;
          await context.close();
          break;
      }
      return {};
    },
    async frame(pageId) {
      if (pageId !== activePageId)
        throw new ApplicationError(
          'BROWSER_STALE_PAGE',
          'Active tab changed; inspect the browser again',
        );
      const size = viewport;
      const data = await pageFor(pageId).screenshot({
        type: 'jpeg',
        quality: 65,
        timeout: 5000,
      });
      if (data.length > 2_000_000)
        throw new ApplicationError('BROWSER_LIMIT', 'Frame exceeds 2 MB');
      if (size !== viewport)
        throw new ApplicationError(
          'BROWSER_STALE_FRAME',
          'Viewport changed; request a new frame',
        );
      return { data: data.toString('base64'), viewport: { ...size } };
    },
    close: () => {
      closing = true;
      return context.close();
    },
  };
}
