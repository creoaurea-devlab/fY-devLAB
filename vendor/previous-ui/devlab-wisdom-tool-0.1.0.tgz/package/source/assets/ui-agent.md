---
name: ui-agent
description: Investigate, change, or review first-party UI using source-backed element, action, token, and contract maps. Use for visual layout, controls, interaction states, accessibility, or UI-to-service wiring in devLAB projects.
---

# UI agent

Read the exact project's AGENTS entry and Wisdom BOOT first. Use its existing effect route and task preflight; this skill supplies UI working context, not a router role or running process. When delegated, receive the user's authorized outcome and exact owned scope.

1. Run `node .agents/skills/ui-agent/scripts/ui-map.mjs summary`, then query only the affected region or element (`query --region ui-preview --type element`, or `query --id preview.start`). Use `--root <project>` for an opened project. Read the returned source spans and their direct action/contract dependencies. Continue when every requested UI behavior has a current source anchor or an explicit unresolved gap. Keep queries bounded; request the next page instead of loading all regions.
2. Trace the visible control through its handler, client operation, transport validation, service contract, and selected plugin implementation when applicable. Mark local state, navigation, inspection, process startup and project mutations distinctly. Static syntax is evidence of wiring intent; rendered interaction is separate evidence.
3. Before changing UI, load `.context/protocols/ui-agent.md` when the target provides it; retain its existing Wisdom and preview protocols. State target project/region, affected elements/tokens/actions, success/loading/empty/error/disabled states, accessibility behavior and exact candidate files. Preserve semantic IDs and project scope. Resolve dynamic controls or delegated rendering through the referenced source; record unknown links explicitly.
4. Execute the authorized task through existing Wisdom guards. Keep shared contract/composition changes with their designated owner. Maintain Cordis lifecycle ownership and contract-only plugin imports. Reuse semantic tokens; evaluate inherited theme definitions before introducing a token.
5. Verify the behavior with applicable source checks and rendered interaction, including failure and keyboard paths. Run a fresh focused inventory query after edits; the tool reads source directly and writes no files. Report implementation, executed checks, rendered evidence and remaining gaps separately. Completion requires requested behavior plus evidence; generated maps alone establish no runtime acceptance.

For a visual review without code changes, use the read-only route and return source-backed findings. The inventory commands are read-only; review does not update maps or context files.

The map contains static source sites, including opaque component callsites. A literal semantic ID is recorded only when present in source. Handler/import/call references do not prove runtime service wiring. Defaults return12 records per page (maximum50); oversized records identify omitted fields and require reading their source spans. Source/layout/parser failures remain visible. The tool loads parsers from its own trusted installation, never from `--root` dependencies.
