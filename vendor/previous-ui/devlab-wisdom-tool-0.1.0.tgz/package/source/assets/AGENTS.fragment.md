For project UI work, Open Folder adoption, preview wiring or semantic styling,
read `.context/protocols/project-preview.md`. Every authored UI element needs a
stable identity and evidenced source/token mapping. Use the exact project's own
authority before changing source or governance.

For substantial delivery planning, use `.agents/skills/planoria/SKILL.md` and
retain the project's canonical execution graph.

For UI layout, controls, semantic tokens or UI-to-service wiring, load
`.agents/skills/ui-agent/SKILL.md` and `.context/protocols/ui-agent.md`. Query
fresh, bounded source evidence before edits and verify rendered interactions
afterward. The skill is context for an authorized agent, not a running process.
