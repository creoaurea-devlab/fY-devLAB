# UI agent protocol

Use the target project's own AGENTS/BOOT, planning chain and exact write gates.
The UI agent is a discoverable skill/context profile; it does not replace the
Wisdom router or create a running model process. Authorized host delegation gives
it an actual task, project and exact owned scope. Cordis and public contracts
remain authoritative for lifecycle and capability ownership.

## Source map and context

Run the UI skill's read-only `scripts/ui-map.mjs summary` from the project root;
query only affected regions, elements, action references and semantic tokens.
For this installation the entry is `.agents/skills/ui-agent/scripts/ui-map.mjs`.
Use `query --region ui-preview --type element`, `query --type token-definition`
or `query --id preview.start`; advance explicit pages while hasMore. The tool
uses its trusted TypeScript/PostCSS/parse5 parsers, caps query output at32KiB and
detects source content/enumeration changes. Missing prerequisites are errors,
not permission to run a target package script or install dependencies.

Static source sites include intrinsic JSX, literal HTML and component callsites. A semantic
ID is known only when declared literally; a source span is a locator, not a
stable runtime identity. HTML bodies, dynamic/spread attributes, computed
handlers, opaque components and unobserved runtime states remain explicit gaps.
Token records retain selector/theme/media ancestry; computed cascade remains a
runtime question. Read source spans and imports to resolve a control's handler,
client method, transport validation, service contract and profile-selected
implementation. A call expression alone proves neither effect nor runtime wiring.

## Changes

For each Planoria atomic task, state the affected project/regions, elements,
actions, token sources and observable behavior before preflight. Include success,
loading, empty, error, disabled, keyboard and focus states where applicable.
Every touched first-party control needs an accessible name/state, semantic
identity and source association. Use existing semantic CSS tokens and inspect
theme inheritance before adding aliases. Keep element IDs unique within their
project/presentation instance; generated/third-party exceptions stay documented.

Product plugins import contracts and their own internals. Shared contracts,
composition and lockfiles have one designated writer. UI disposal owns observers;
backend services own PTYs, servers and native browser processes. Pane/drawer
changes preserve those owners and project/generation fences.

## Verify and reconcile

Use the task's actual type/import checks and meaningful rendered interactions.
Check keyboard/focus paths, real geometry, narrow CSS viewport, stale responses
and lifecycle continuity. Use temporary data and owned background browser
contexts; preserve user sessions. Refresh focused source queries after edits.
Separate observed runtime behavior from static mapping and unresolved coverage.

Update only changed material facts through their own guarded map/context
population routes; a hash seal establishes freshness, not semantic accuracy.
Generic project preparation preserves existing authority and cannot populate it
by copying devLAB facts. Read-only investigation performs no source/memory writes.
