# Project-local Planoria JSON planning

For new features, bug fixes and UI integrations, plan a roadmap of milestones, slices and atomic tasks as versioned JSON values under .planea. Use schemas/roadmap.v2.schema.json and validate IDs, parent links, ordering, exact scope, prerequisites, checks and completion evidence. UI tasks specify semantic targets/states; bugs specify a reproduction. Keep one task-status authority.

Read the exact target BOOT and existing agent rules first. Existing authority is preserved. Installation provides schema/guidance only; it does not migrate or populate a target roadmap. A target-local agent must inspect actual source, write the plan and establish the target's guarded writer before enabling board commands. Markdown is a derived review view. Begin/verify/finish gates own running/review/complete; card movement never supplies evidence or executes project scripts implicitly.
