---
name: planoria
description: Investigate a feature and create an evidence-based milestone, slice, and atomic-task Markdown plan linked to the project's execution graph. Use when organizing substantial implementation work or refining an existing delivery plan.
---

# Planoria

Load the target project's instruction entry and existing planning protocol first.
Preserve its spec/roadmap authority, execution gates and unrelated dirty hunks.
Use additive edits; retain user work and live sessions. This skill structures
planning; it does not authorize implementation or replace local governance.

1. Inspect the requested outcome, current interfaces, existing changes and relevant
   source. Label verified facts, assumptions and unresolved decisions. Use read-only
   investigation before choosing seams; completion means each design claim points
   to evidence or is explicitly unresolved.
2. Define observable acceptance IDs, compatibility, failure behavior, risks and
   rollback. Prefer small interfaces hiding lifecycle complexity. Reuse actual
   adapters; introduce a new seam where behavior genuinely varies. Completion:
   every user requirement maps to an observable acceptance criterion.
3. Write a plan root with SPEC.md and ROADMAP.md. Under `milestones/<id-name>/`,
   create `slices/<id-name>/` and one `<task-id>.md` per atomic task. Reuse the
   repository's established plan location when one exists. A milestone delivers
   a capability; a slice delivers a useful demonstrable increment. Split a task
   further if its result cannot be checked or rolled back independently.
4. Each task records status, owning milestone/slice, acceptance IDs, dependencies,
   exact candidate reads/writes, behavior, failure cases, executable verification,
   completion evidence and rollback. Candidate scope must be rechecked before
   implementation preflight. If an executable probe does not exist, name a prior
   task to create it; never present a planned check as passing evidence.
5. Link tasks into the existing canonical execution graph without duplicating
   status authority. Validate coverage, unique assignment and acyclic dependencies.
   Keep completed work intact. Planning is complete when the graph validates,
   links resolve and the first pending task has a concrete safe entry point.
6. When delegation is authorized, parallelize read-only investigation or disjoint
   task scopes. One writer owns shared contracts, composition, locks and context
   updates. Run no implementation merely to make a planning deliverable look done.

Use measured performance budgets for claims such as smooth, fast or accelerated.
Specify environment, workload, metrics and failure threshold. Distinguish design
intent, implementation, executed checks and verified acceptance in handoffs.

For JSON planning in an onboarded project, read .context/protocols/planea-planning.md. Preserve its existing authority; schema/guidance installation does not perform a cutover or grant runtime completion.
