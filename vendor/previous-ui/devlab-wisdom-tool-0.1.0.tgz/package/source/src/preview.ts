import { readdir, realpath } from 'node:fs/promises';
import { resolve } from 'node:path';
import {
  discoverPreview,
  ProjectRelativePathSchema,
  type ProjectCatalog,
} from '@devlab/contracts';
import protocol from '../assets/project-preview.md';
import agentRule from '../assets/AGENTS.fragment.md';
import planoria from '../assets/planoria.md';
import planeaProtocol from '../assets/planea-protocol.md';
import planeaSchema from '../assets/planea-roadmap.schema.json';
import schema from '../assets/preview.project.schema.json';
import uiAgent from '../assets/ui-agent.md';
import uiProtocol from '../assets/ui-agent-protocol.md';
import uiMap from '../assets/ui-map.txt';
export const PREVIEW_AGENT_RULE = agentRule;
export type PreparedAdditions = {
  files: Record<string, string>;
  inputs: Record<string, string | null>;
  warnings: string[];
};
export async function previewAdditions(
  projects: ProjectCatalog,
  id: string,
  bridge: string,
  previewOnly = false,
): Promise<PreparedAdditions> {
  const root = await projects.root(id),
    files = await readdir(root);
  const inputs: PreparedAdditions['inputs'] = {
    listing: JSON.stringify(files.sort()),
  };
  const read = async (path: string) => {
    try {
      const text = (await projects.read(id, path)).text;
      inputs[path] = text;
      return text;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        inputs[path] = null;
        return undefined;
      }
      throw error;
    }
  };
  const descriptorText = await read('devlab.preview.json'),
    manifestText = await read('package.json');
  const parse = (text: string | undefined) => {
    try {
      return text === undefined ? undefined : JSON.parse(text);
    } catch {
      return {};
    }
  };
  let discovery = discoverPreview({
    files,
    descriptor: parse(descriptorText),
    manifest: parse(manifestText),
  });
  if (discovery.status === 'unconfigured') {
    const manifest = parse(manifestText);
    const workspaces = Array.isArray(manifest?.workspaces)
      ? manifest.workspaces
      : manifest?.workspaces?.packages;
    let patterns: string[] = Array.isArray(workspaces) ? workspaces : [];
    if (!patterns.length && files.includes('pnpm-workspace.yaml')) {
      const yaml = await read('pnpm-workspace.yaml');
      // Read only the common packages list; never evaluate project YAML tags/code.
      const block =
        /^packages:\s*\n((?:[ \t]+[^\n]*\n?)*)/m.exec(yaml ?? '')?.[1] ?? '';
      patterns = [
        ...block.matchAll(/^\s+-\s+['"]?([^'"\s#]+)['"]?\s*(?:#.*)?$/gm),
      ].map((m) => m[1]!);
    }
    if (patterns.length > 32)
      throw new Error(
        'Too many workspace patterns. Configure devlab.preview.json explicitly.',
      );
    const candidates = new Set<string>();
    for (const pattern of patterns) {
      if (typeof pattern !== 'string')
        throw new Error(
          'Invalid workspace pattern. Configure devlab.preview.json explicitly.',
        );
      const wildcard = pattern.endsWith('/*');
      const parent = wildcard ? pattern.slice(0, -2) : pattern;
      if (
        parent.includes('*') ||
        !ProjectRelativePathSchema.safeParse(parent).success
      )
        throw new Error(
          'Unsupported workspace pattern: ' +
            pattern +
            '. Configure devlab.preview.json explicitly.',
        );
      const path = resolve(root, parent);
      try {
        if ((await realpath(path)) !== path)
          throw new Error(
            'Workspace must be a physical project directory: ' + parent,
          );
        if (wildcard) {
          const entries = await readdir(path, { withFileTypes: true });
          for (const entry of entries)
            if (
              entry.isDirectory() &&
              ProjectRelativePathSchema.safeParse(parent + '/' + entry.name)
                .success
            )
              candidates.add(parent + '/' + entry.name);
        } else candidates.add(parent);
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
      }
      if (candidates.size > 64)
        throw new Error(
          'Too many workspace apps. Configure devlab.preview.json explicitly.',
        );
    }
    const supported = [];
    for (const cwd of [...candidates].sort()) {
      const child = parse(await read(cwd + '/package.json'));
      if (
        manifest?.packageManager &&
        child?.packageManager &&
        manifest.packageManager !== child.packageManager
      )
        throw new Error(
          'Conflicting package manager/version evidence in workspace app: ' +
            cwd +
            '. Configure the project explicitly.',
        );
      // Installation belongs to the workspace; root manager/version evidence wins.
      const candidate = discoverPreview({
        files,
        manifest: {
          ...child,
          ...(manifest?.packageManager
            ? { packageManager: manifest.packageManager }
            : {}),
        },
      });
      if (candidate.status === 'invalid')
        throw new Error(candidate.warnings.join(' '));
      if (candidate.status === 'inferred' && candidate.descriptor)
        supported.push({
          ...candidate,
          descriptor: { ...candidate.descriptor, workspaceRoot: '.', cwd },
        });
    }
    if (supported.length > 1)
      throw new Error(
        'Multiple web apps found: ' +
          supported.map((c) => c.descriptor.cwd).join(', ') +
          '. Choose the app in devlab.preview.json.',
      );
    if (supported.length === 1) discovery = supported[0]!;
  }
  if (previewOnly && !discovery.descriptor)
    throw new Error(
      discovery.warnings.join(' ') ||
        'No supported web app found. Configure devlab.preview.json explicitly.',
    );
  const result: Record<string, string> = {
    '.context/protocols/project-preview.md': protocol,
    '.context/schemas/project-preview.schema.json':
      JSON.stringify(schema, null, 2) + '\n',
    '.agents/skills/planoria/SKILL.md': planoria,
    '.context/protocols/planea-planning.md': planeaProtocol,
    '.planea/schemas/roadmap.v2.schema.json': JSON.stringify(planeaSchema, null, 2) + '\n',
    '.planea/README.md': '# Project-local JSON planning\n\nRead .context/protocols/planea-planning.md and your existing BOOT/agent rules. This schema is unpopulated guidance; create a source-backed target plan before execution.\n',
    '.agents/skills/ui-agent/SKILL.md': uiAgent,
    '.agents/skills/ui-agent/scripts/ui-map.mjs': uiMap,
    '.context/protocols/ui-agent.md': uiProtocol,
  };
  if (
    descriptorText === undefined &&
    discovery.status === 'inferred' &&
    discovery.descriptor
  )
    result['devlab.preview.json'] =
      JSON.stringify(discovery.descriptor, null, 2) + '\n';
  if (discovery.descriptor?.inspection === 'bridge')
    result['public/devlab-bridge.js'] = bridge;
  return { files: result, inputs, warnings: discovery.warnings };
}
