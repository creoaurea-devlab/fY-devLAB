import {
  previewAdditions,
  PREVIEW_AGENT_RULE,
  type PreparedAdditions,
} from './preview.ts';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { lstat, realpath, open, mkdir, unlink } from 'node:fs/promises';
import { constants } from 'node:fs';
import { resolve, sep } from 'node:path';
import type { ProjectCatalog, PluginDefinition } from '@devlab/contracts';
import type {
  WisdomTool,
  WisdomInspection,
  WisdomProposal,
} from '@devlab/contracts';
export type WisdomBundle = {
  version: '2.4.0';
  files: Record<string, { text: string; sha256: string }>;
  agentFragment?: string;
};
const hash = (text: string | Buffer) =>
  createHash('sha256').update(text).digest('hex');
const fragment =
  '<!-- DEVLAB:WISDOM:START -->\nBefore substantive project work, read `.context/BOOT.md` in this exact project and follow its existing authority, routes, and gates.\n<!-- DEVLAB:WISDOM:END -->\n';
const population =
  '\nInstallation copies are unpopulated. Read existing project authority first. Map/index actual source, populate core project facts, then agent roles using the installed edition protocols. Do not claim readiness from copied templates; validate the target with its own router and record real verification. Preserve existing rules and source changes.\n';
type Snapshot = { path: string; text: string | null; sha256: string | null };
type Internal = {
  public: WisdomProposal;
  root: string;
  reads: Snapshot[];
  additionsHash: string;
  writes: { path: string; text: string; operation: 'add' | 'append' }[];
};
async function safe(root: string, path: string, createParents = false) {
  if (
    !path ||
    path.includes('\\') ||
    path.includes('\0') ||
    path.split('/').some((p) => !p || p === '.' || p === '..') ||
    path.startsWith('/')
  )
    throw new Error('Invalid Wisdom path');
  const target = resolve(root, path);
  if (!target.startsWith(root + sep))
    throw new Error('Wisdom path escapes project');
  if ((await realpath(root)) !== root)
    throw new Error('Selected project root changed');
  let cursor = root;
  for (const p of path.split('/').slice(0, -1)) {
    cursor = resolve(cursor, p);
    let info = await lstat(cursor).catch((error) => {
      if (error.code === 'ENOENT') return null;
      throw error;
    });
    if (!info && createParents) {
      await mkdir(cursor).catch((error) => {
        if (error.code !== 'EEXIST') throw error;
      });
      info = await lstat(cursor);
    }
    if (
      info &&
      (!info.isDirectory() ||
        info.isSymbolicLink() ||
        (await realpath(cursor)) !== cursor)
    )
      throw new Error('Wisdom parent is not a physical directory');
  }
  const info = await lstat(target).catch((error) => {
    if (error.code === 'ENOENT') return null;
    throw error;
  });
  if (
    info &&
    (!info.isFile() ||
      info.isSymbolicLink() ||
      info.size > 2 * 1024 * 1024 ||
      (await realpath(target)) !== target)
  )
    throw new Error('Unsafe Wisdom file');
  return target;
}
async function snapshot(root: string, path: string): Promise<Snapshot> {
  const target = await safe(root, path);
  let fd;
  try {
    fd = await open(
      target,
      constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK,
    );
    const stat = await fd.stat();
    if (!stat.isFile() || stat.size > 2 * 1024 * 1024)
      throw new Error('Unsafe Wisdom input');
    if (
      process.platform === 'linux' &&
      (await realpath('/proc/self/fd/' + fd.fd)) !== target
    )
      throw new Error('Wisdom file changed scope');
    const value = await fd.readFile();
    if (value.includes(0)) throw new Error('Binary Wisdom input');
    return { path, text: value.toString('utf8'), sha256: hash(value) };
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT')
      return { path, text: null, sha256: null };
    throw error;
  } finally {
    await fd?.close();
  }
}
/** Node-only installation planning; does not run routers or claim project population. */
export function createWisdomTool(
  projects: Pick<ProjectCatalog, 'root'>,
  bundle: WisdomBundle,
  options: {
    additions?: (
      id: string,
      previewOnly?: boolean,
    ) => Promise<PreparedAdditions>;
    agentRule?: string;
  } = {},
): WisdomTool & { dispose(): Promise<void> } {
  if (bundle.version !== '2.4.0')
    throw new Error('Unsupported bundled Wisdom edition');
  const assets = new Map<string, string>();
  for (const [source, asset] of Object.entries(bundle.files)) {
    const path = source.replace(/^templates\/core\//, '');
    if (
      !(
        path.startsWith('.context/') ||
        path.startsWith('.agents/skills/') ||
        path.startsWith('.wisdom/tools/')
      ) ||
      path.includes('/.git/') ||
      path.endsWith('/population.json') ||
      !asset ||
      typeof asset.text !== 'string' ||
      hash(asset.text) !== asset.sha256
    )
      throw new Error('Invalid or unsupported Wisdom bundle asset: ' + source);
    if (assets.has(path)) throw new Error('Duplicate Wisdom bundle path');
    if (
      path.split('/').some((v) => !v || v === '.' || v === '..') ||
      path.includes('\\') ||
      path.includes('\0')
    )
      throw new Error('Unsafe bundle path');
    assets.set(path, asset.text);
  }
  for (const key of [
    '.context/BOOT.md',
    '.context/index.json',
    '.context/router.py',
  ])
    if (!assets.has(key)) throw new Error('Incomplete Wisdom bundle');
  const loader = bundle.agentFragment ?? fragment;
  if (!loader.includes('.context/BOOT.md'))
    throw new Error('Wisdom loader does not reference authority');
  const proposals = new Map<string, Internal>(),
    queues = new Map<string, Promise<unknown>>();
  let alive = true;
  const active = () => {
    if (!alive) throw new Error('Wisdom tool is disposed');
  };
  async function inspectInternal(projectId: string): Promise<WisdomInspection> {
    const root = await projects.root(projectId);
    const [boot, index, settings, seal, router, project, agents] =
      await Promise.all(
        [
          '.context/BOOT.md',
          '.context/index.json',
          '.context/settings.json',
          '.context/state/population.json',
          '.context/router.py',
          '.context/config/project.yaml',
          'AGENTS.md',
        ].map((p) => snapshot(root, p)),
      );
    const present = [boot!, index!, settings!].filter((s) => s.text !== null);
    if (
      !present.length &&
      router!.text === null &&
      project!.text === null &&
      seal!.text === null &&
      !agents!.text?.includes('.context/BOOT.md')
    )
      return {
        projectId,
        status: 'absent',
        warnings: ['No Wisdom authority detected.'],
      };
    let version: string | undefined;
    try {
      version = JSON.parse(index!.text ?? '{}').version;
    } catch {
      /* classify partial */
    }
    const complete =
      present.length === 3 &&
      !!version &&
      router!.text !== null &&
      project!.text !== null;
    return {
      projectId,
      status: !complete
        ? 'partial'
        : seal!.text === null
          ? 'unpopulated'
          : 'existing',
      version,
      warnings: [
        ...(!complete
          ? ['Existing partial authority requires edition-specific recovery.']
          : []),
        ...(version && version !== '2.4.0'
          ? [
              'Existing ' +
                version +
                ' authority preserved; bundled 2.4 validator is not applicable.',
            ]
          : []),
        'Population and gate readiness are informational until validated by the target edition; no router was executed.',
      ],
    };
  }
  async function plan(
    projectId: string,
    options_: { previewOnly?: boolean } = {},
  ): Promise<WisdomProposal> {
    const previewOnly = options_.previewOnly === true;
    active();
    const root = await projects.root(projectId),
      inspection = await inspectInternal(projectId);
    const prepared = options.additions
      ? await options.additions(projectId, previewOnly)
      : { files: {}, inputs: {}, warnings: [] };
    const additions = previewOnly
      ? Object.fromEntries(
          Object.entries(prepared.files).filter(
            ([path]) => path === 'devlab.preview.json',
          ),
        )
      : prepared.files;
    const additionsHash = hash(JSON.stringify(prepared));
    const paths = [
      ...Object.keys(additions),
      ...assets.keys(),
      'AGENTS.md',
      '.context/state/population.json',
    ];
    const reads = await Promise.all(
      [...new Set(paths)].sort().map((p) => snapshot(root, p)),
    );
    const byPath = new Map(reads.map((s) => [s.path, s]));
    const writes: Internal['writes'] = [],
      conflicts: string[] = [],
      warnings = [
        ...inspection.warnings,
        ...prepared.warnings,
        ...(previewOnly
          ? [
              'Preview setup only; existing Wisdom authority and project rules are preserved.',
            ]
          : [population.trim()]),
      ];
    if (!previewOnly && inspection.status === 'absent')
      for (const [path, text] of assets) {
        const existing = byPath.get(path)!;
        if (existing.text === null)
          writes.push({ path, text, operation: 'add' });
        else if (existing.text !== text) conflicts.push(path);
      }
    else if (!previewOnly) {
      warnings.push(
        'Existing authority is preserved. This tool does not fill missing edition files or upgrade authority.',
      );
      for (const [path, text] of assets) {
        const existing = byPath.get(path)!;
        if (existing.text !== null && existing.text !== text)
          conflicts.push(path);
      }
    }
    for (const [path, text] of Object.entries(additions)) {
      await safe(root, path);
      const current = byPath.get(path)!;
      if (current.text === null) writes.push({ path, text, operation: 'add' });
      else if (current.text !== text) conflicts.push(path);
    }
    if (!previewOnly && inspection.status !== 'absent' && writes.length)
      warnings.push(
        'Use this project’s agent and target-local gates to apply this proposal. The generic Apply tool preserves existing authority.',
      );
    const agents = byPath.get('AGENTS.md')!;
    if (!previewOnly && !(agents.text ?? '').includes('.context/BOOT.md'))
      writes.push({
        path: 'AGENTS.md',
        operation: agents.text === null ? 'add' : 'append',
        text: agents.text === null ? loader : '\n\n' + loader,
      });
    if (
      !previewOnly &&
      options.agentRule &&
      !(agents.text ?? '').includes('.context/protocols/project-preview.md')
    ) {
      const pending = writes.find((w) => w.path === 'AGENTS.md');
      if (pending) pending.text += '\n' + options.agentRule;
      else
        writes.push({
          path: 'AGENTS.md',
          operation: agents.text === null ? 'add' : 'append',
          text: '\n' + options.agentRule,
        });
    }
    // Differing existing files are disclosed, retained byte-for-byte, and never silently staged or upgraded.
    const digest = hash(
      JSON.stringify({
        projectId,
        root,
        bundleVersion: bundle.version,
        previewOnly,
        additionsHash,
        reads: reads.map(({ path, sha256 }) => ({ path, sha256 })),
        writes,
      }),
    );
    const proposal: WisdomProposal = {
      projectId,
      sha256: digest,
      bundleVersion: bundle.version,
      previewOnly,
      targetGateRequired:
        !previewOnly && inspection.status !== 'absent' && writes.length > 0,
      changes: writes.map((w) => ({
        path: w.path,
        operation: w.operation,
        sha256: hash(w.text),
        expectedHash: byPath.get(w.path)!.sha256,
        text: w.text,
      })),
      conflicts,
      warnings,
    };
    if (proposals.size >= 128) proposals.delete(proposals.keys().next().value!);
    proposals.set(digest, {
      public: proposal,
      root,
      reads,
      writes,
      additionsHash,
    });
    return structuredClone(proposal);
  }
  async function apply(projectId: string, proposalSha: string) {
    active();
    const prior = queues.get(projectId) ?? Promise.resolve();
    const operation = prior
      .catch(() => {})
      .then(async () => {
        const proposal = proposals.get(proposalSha);
        if (!proposal || proposal.public.projectId !== projectId)
          throw new Error('Unknown reviewed Wisdom proposal');
        if ((await projects.root(projectId)) !== proposal.root)
          throw new Error('Project root changed');
        for (const expected of proposal.reads) {
          const current = await snapshot(proposal.root, expected.path);
          if (current.sha256 !== expected.sha256)
            throw new Error('Stale Wisdom proposal: ' + expected.path);
        }
        const prepared = options.additions
          ? await options.additions(projectId, proposal.public.previewOnly)
          : { files: {}, inputs: {}, warnings: [] };
        if (hash(JSON.stringify(prepared)) !== proposal.additionsHash)
          throw new Error(
            'Stale preview discovery; prepare the project again.',
          );
        const previewOnly =
          proposal.public.previewOnly === true &&
          proposal.writes.every(
            (w) => w.path === 'devlab.preview.json' && w.operation === 'add',
          );
        if (
          !previewOnly &&
          proposal.writes.length &&
          (await inspectInternal(projectId)).status !== 'absent'
        )
          throw new Error(
            'Existing Wisdom authority requires its target-local agent route and gates; no files were changed. Review the proposal with that project’s agent.',
          );
        const added: string[] = [];
        for (const write of proposal.writes) {
          const path = await safe(proposal.root, write.path, true);
          const expected = proposal.reads.find((r) => r.path === write.path)!;
          const current = await snapshot(proposal.root, write.path);
          if (current.sha256 !== expected.sha256)
            throw new Error(
              'Stale Wisdom proposal during apply: ' + write.path,
            );
          let fd;
          try {
            fd = await open(
              path,
              write.operation === 'add'
                ? constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY
                : constants.O_RDWR | constants.O_APPEND | constants.O_NOFOLLOW,
              0o600,
            );
            if (
              write.operation === 'append' &&
              hash(await fd.readFile()) !== expected.sha256
            )
              throw new Error('Agent rules changed before append');
            await fd.writeFile(write.text);
            await fd.sync();
            added.push(write.path);
          } catch (error) {
            if (write.operation === 'add' && fd)
              await unlink(path).catch(() => {});
            throw error;
          } finally {
            await fd?.close();
          }
        }
        proposals.delete(proposalSha);
        return { inspection: await inspectInternal(projectId), added };
      });
    queues.set(projectId, operation);
    void operation
      .finally(() => {
        if (queues.get(projectId) === operation) queues.delete(projectId);
      })
      .catch(() => {});
    return operation;
  }
  return {
    inspect(projectId) {
      active();
      return inspectInternal(projectId);
    },
    plan,
    apply,
    async dispose() {
      alive = false;
      await Promise.allSettled([...queues.values()]);
      proposals.clear();
    },
  };
}
// Root integration: add WisdomTool to ServiceMap under `wisdom`, export its contract,
// then use this factory. Bundle remains an injected verified internal asset map.
export function wisdomTool(
  bundle: WisdomBundle,
  options: { preview?: boolean } = {},
): PluginDefinition {
  return {
    manifest: {
      id: 'wisdom-tool',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['wisdom'],
      requires: options.preview
        ? ['projects', 'previewInspector']
        : ['projects'],
      capabilities: ['workspace:local'],
      reload: 'restart',
    },
    activate(scope) {
      const service = createWisdomTool(
        scope.get('projects'),
        bundle,
        options.preview
          ? {
              agentRule: PREVIEW_AGENT_RULE,
              additions: (id, previewOnly) =>
                previewAdditions(
                  scope.get('projects'),
                  id,
                  scope.get('previewInspector').bridgeScript(),
                  previewOnly,
                ),
            }
          : {},
      );
      scope.onDispose(() => service.dispose());
      scope.provide('wisdom', service);
    },
  };
}

/** Explicit prerequisite probe only; never called during construction, inspect, plan or apply. */
export async function validateWisdomPrerequisites() {
  try {
    const { stdout } = await promisify(execFile)(
      'python3',
      [
        '-c',
        'import json,sys,importlib.util; print(json.dumps({"python":sys.version.split()[0],"pyyaml":importlib.util.find_spec("yaml") is not None,"jsonschema":importlib.util.find_spec("jsonschema") is not None}))',
      ],
      {
        timeout: 5000,
        maxBuffer: 4096,
        env: {
          PATH: process.env.PATH,
          HOME: process.env.HOME,
          LANG: process.env.LANG,
        },
      },
    );
    return JSON.parse(stdout) as {
      python: string;
      pyyaml: boolean;
      jsonschema: boolean;
    };
  } catch (error) {
    return { error: String(error) };
  }
}
