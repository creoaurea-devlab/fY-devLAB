import distribution from '../assets/distribution.json';
import { createHash } from 'node:crypto';
import { wisdomTool, type WisdomBundle } from './index.ts';
/** Retain reviewed source paths in the artifact; project destinations are explicit here. */
export function wisdomBundle(): WisdomBundle {
  if (distribution.sourceVersion !== '2.4.0')
    throw new Error('Unsupported Wisdom distribution');
  const files: WisdomBundle['files'] = {};
  for (const [path, asset] of Object.entries(distribution.files)) {
    if (createHash('sha256').update(asset.text).digest('hex') !== asset.sha256)
      throw new Error('Wisdom asset integrity failed: ' + path);
    let target: string | undefined;
    if (path.startsWith('templates/core/'))
      target = path.slice('templates/core/'.length);
    if (path.startsWith('tools/populate-context/'))
      target = '.agents/skills/' + path.slice('tools/'.length);
    if (path.startsWith('tools/map-codebase/')) target = '.wisdom/' + path;
    if (target) files[target] = asset;
  }
  return {
    version: '2.4.0',
    files,
    agentFragment: distribution.files['adapters/shared/AGENTS.md'].text,
  };
}
export function bundledWisdomTool() {
  return wisdomTool(wisdomBundle(),{preview:true});
}
