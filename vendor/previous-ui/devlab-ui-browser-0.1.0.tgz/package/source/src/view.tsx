import { useEffect, useRef, useState, type PointerEvent } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Play,
  Square,
  Maximize,
  Plus,
  X,
  Lock,
  Unlock,
} from 'lucide-react';
import {
  ApplicationError,
  BrowserURLSchema,
  type BrowserEntry,
  type BrowserLease,
  type BrowserFrame,
  type BrowserAction,
  type BrowserSession,
  type BrowserTarget,
} from '@devlab/contracts';
import type {
  UIPluginProps,
  BrowserClient,
  BrowserViewOptions,
  CanvasWorkspace,
} from '@devlab/ui-contracts';
import './browser.css';

// Credentials live only in this document's memory. Remounts reconnect; reloads observe.
const actor = { kind: 'human' as const, id: 'ui_' + crypto.randomUUID() };
const leases = new Map<string, BrowserLease>();
const targetOf = (s: BrowserSession): BrowserTarget => ({
  projectId: s.projectId,
  browserId: s.browserId,
  generation: s.generation,
  pageId: s.activePageId,
});

export function BrowserView({
  client,
  browserOptions,
  workspace,
}: UIPluginProps) {
  if (!client.browsers || !browserOptions)
    return <div role="alert">Browser capability unavailable</div>;
  return (
    <BrowserSurface
      key={browserOptions.projectId + '/' + browserOptions.nodeId}
      api={client.browsers}
      options={browserOptions}
      workspace={workspace}
    />
  );
}
function BrowserSurface({
  api,
  options,
  workspace,
}: {
  api: BrowserClient;
  options: BrowserViewOptions;
  workspace?: CanvasWorkspace;
}) {
  const identity = { projectId: options.projectId, browserId: options.nodeId },
    key = identity.projectId + '/' + identity.browserId;
  const [entry, setEntry] = useState<BrowserEntry | null>(null),
    [frame, setFrame] = useState<BrowserFrame | null>(null),
    [address, setAddress] = useState('about:blank');
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [connected, setConnected] = useState(false);
  const visible = useRef(false),
    refreshVersion = useRef(0);
  const root = useRef<HTMLDivElement>(null),
    surface = useRef<HTMLDivElement>(null),
    image = useRef<HTMLImageElement>(null),
    keyboard = useRef<HTMLTextAreaElement>(null);
  const live = useRef<BrowserSession | null>(null),
    shown = useRef<BrowserFrame | null>(null),
    mounted = useRef(true),
    input = useRef(Promise.resolve());
  const frameRequest = useRef<AbortController | null>(null),
    frameEpoch = useRef(0),
    pendingCommands = useRef(0),
    pollError = useRef('');
  const desired = useRef({ width: 1280, height: 720 }),
    resizeTimer = useRef<ReturnType<typeof setTimeout>>(),
    composing = useRef(false),
    lastMove = useRef(0);
  const owns =
    entry?.owner?.actor.id === actor.id &&
    entry.owner.actor.kind === 'human' &&
    leases.has(key);
  const report = (e: unknown) => {
    if (mounted.current) setError(e instanceof Error ? e.message : String(e));
  };
  const updateSession = (session: BrowserSession | null) => {
    refreshVersion.current++;
    live.current = session;
    if (!mounted.current) return;
    setEntry((old) => (old ? { ...old, session } : old));
    if (!session) {
      leases.delete(key);
      setFrame(null);
      shown.current = null;
    }
  };
  async function refresh() {
    const version = ++refreshVersion.current;
    const entries = await api.discover(identity.projectId);
    if (!mounted.current || version !== refreshVersion.current) return;
    const next =
      entries.find((e) => e.browserId === identity.browserId) ?? null;
    live.current = next?.session ?? null;
    setEntry(next);
    if (!next?.session) setConnected(true);
    const lease = leases.get(key);
    if (
      lease &&
      (!next?.session ||
        lease.generation !== next.session.generation ||
        next.owner?.actor.id !== actor.id ||
        next.owner.actor.kind !== 'human')
    )
      leases.delete(key);
    if (!next?.session) {
      setFrame(null);
      shown.current = null;
    }
  }
  async function command(action: BrowserAction, source?: BrowserTarget) {
    const session = live.current,
      lease = leases.get(key);
    if (!session || !lease)
      throw new Error('Take control of this browser first');
    const target = targetOf(session);
    if (
      source &&
      (source.generation !== target.generation ||
        source.pageId !== target.pageId)
    )
      throw new Error('The displayed tab changed; wait for its new frame');
    const changesView = action.op !== 'heartbeat';
    if (changesView) {
      pendingCommands.current++;
      frameEpoch.current++;
      frameRequest.current?.abort();
    }
    try {
      const result = await api.command({
        ...target,
        actor,
        token: lease.token,
        commandId: crypto.randomUUID(),
        action,
      });
      if (mounted.current) updateSession(result.session);
    } finally {
      if (changesView) pendingCommands.current--;
    }
  }
  function send(action: BrowserAction, source?: BrowserTarget) {
    input.current = input.current
      .catch(() => {})
      .then(() => {
        if (!mounted.current) return;
        return command(action, source);
      })
      .catch(report);
    return input.current;
  }
  async function perform(work: () => Promise<void>) {
    setBusy(true);
    setError('');
    try {
      await work();
      await refresh();
    } catch (e) {
      report(e);
    } finally {
      if (mounted.current) setBusy(false);
    }
  }
  async function takeControl(takeover = false) {
    const session = live.current;
    if (!session) throw new Error('Start this browser first');
    const lease = await api.acquire(targetOf(session), actor, takeover);
    if (!mounted.current) {
      await api.release(lease).catch(() => {});
      return;
    }
    leases.set(key, lease);
    await command({ op: 'resize', viewport: desired.current });
  }
  async function ensureSaved() {
    if (!workspace) throw new Error('Canvas saving is unavailable');
    await workspace.save();
    if (workspace.snapshot().dirty || workspace.snapshot().error)
      throw new Error(
        workspace.snapshot().error ||
          'Save this canvas before starting the browser',
      );
  }
  useEffect(() => {
    mounted.current = true;
    let stopped = false,
      timer: ReturnType<typeof setTimeout>;
    let lastRefresh = 0,
      lastHeartbeat = 0,
      failures = 0;
    async function poll() {
      try {
        if (Date.now() - lastRefresh > 1500) {
          await refresh();
          lastRefresh = Date.now();
        }
        const session = live.current;
        if (
          !stopped &&
          visible.current &&
          !document.hidden &&
          session &&
          !pendingCommands.current
        ) {
          const target = targetOf(session),
            epoch = frameEpoch.current,
            abort = new AbortController();
          frameRequest.current = abort;
          let next: BrowserFrame;
          try {
            next = await api.frame(target, abort.signal);
          } finally {
            if (frameRequest.current === abort) frameRequest.current = null;
          }
          const current = live.current;
          if (
            !stopped &&
            epoch === frameEpoch.current &&
            current &&
            current.generation === next.target.generation &&
            current.activePageId === next.target.pageId &&
            current.viewport.width === next.viewport.width &&
            current.viewport.height === next.viewport.height
          ) {
            const previous = shown.current;
            shown.current = next;
            if (
              !previous ||
              previous.data !== next.data ||
              previous.target.generation !== next.target.generation ||
              previous.target.pageId !== next.target.pageId ||
              previous.viewport.width !== next.viewport.width ||
              previous.viewport.height !== next.viewport.height
            )
              setFrame(next);
            setConnected(true);
            failures = 0;
            if (pollError.current) {
              const recovered = pollError.current;
              pollError.current = '';
              setError((value) => (value === recovered ? '' : value));
            }
          }
        }
        if (
          !stopped &&
          visible.current &&
          leases.has(key) &&
          live.current &&
          Date.now() - lastHeartbeat > 10000
        ) {
          lastHeartbeat = Date.now();
          await command({ op: 'heartbeat' });
        }
      } catch (e) {
        if (!stopped && !(e instanceof Error && e.name === 'AbortError')) {
          failures++;
          const transient =
            e instanceof ApplicationError &&
            [
              'BROWSER_FRAME_FAILED',
              'BROWSER_STALE_PAGE',
              'BROWSER_PAGE_GONE',
              'BROWSER_STALE_GENERATION',
              'BROWSER_NOT_RUNNING',
            ].includes(e.code);
          if (transient) lastRefresh = 0;
          // Native resize/navigation can invalidate one capture. Keep its last
          // good image and retry; persistent outages still get a visible error.
          if (!transient || failures >= 4) {
            setConnected(false);
            pollError.current = e instanceof Error ? e.message : String(e);
            report(e);
          }
        }
      } finally {
        if (!stopped)
          timer = setTimeout(
            () => void poll(),
            Math.min(4000, 250 * 2 ** Math.min(4, Math.max(0, failures - 1))),
          );
      }
    }
    void poll();
    return () => {
      stopped = true;
      mounted.current = false;
      frameRequest.current?.abort();
      frameRequest.current = null;
      clearTimeout(timer);
      clearTimeout(resizeTimer.current);
    };
    // The loop reads session/lease refs; frame delivery never owns browser lifetime.
  }, [api, key]);
  useEffect(() => {
    if (!root.current) return;
    const observer = new IntersectionObserver(([item]) => {
      visible.current = item?.isIntersecting === true;
    });
    observer.observe(root.current);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (!surface.current) return;
    const observer = new ResizeObserver(([size]) => {
      if (!size || size.contentRect.width < 1 || size.contentRect.height < 1)
        return;
      const viewport = {
        width: Math.min(
          1920,
          Math.max(480, Math.round(size.contentRect.width)),
        ),
        height: Math.min(
          1200,
          Math.max(240, Math.round(size.contentRect.height)),
        ),
      };
      desired.current = viewport;
      clearTimeout(resizeTimer.current);
      resizeTimer.current = setTimeout(() => {
        const session = live.current;
        if (
          session &&
          visible.current &&
          leases.has(key) &&
          (session.viewport.width !== viewport.width ||
            session.viewport.height !== viewport.height)
        )
          void send({ op: 'resize', viewport });
      }, 200);
    });
    observer.observe(surface.current);
    return () => observer.disconnect();
  }, [key]);
  useEffect(() => {
    const element = surface.current;
    if (!element) return;
    const wheel = (event: WheelEvent) => {
      event.preventDefault();
      event.stopPropagation();
      if (!leases.has(key) || !shown.current) return;
      const scale =
        event.deltaMode === 1
          ? 16
          : event.deltaMode === 2
            ? desired.current.height
            : 1;
      void send(
        {
          op: 'scroll',
          deltaX: Math.max(-10000, Math.min(10000, event.deltaX * scale)),
          deltaY: Math.max(-10000, Math.min(10000, event.deltaY * scale)),
        },
        shown.current.target,
      );
    };
    element.addEventListener('wheel', wheel, { passive: false });
    return () => element.removeEventListener('wheel', wheel);
  }, [key]);
  function pointer(
    event: PointerEvent<HTMLDivElement>,
    phase: 'move' | 'down' | 'up',
  ) {
    if (!owns || !shown.current || !image.current) return;
    event.preventDefault();
    event.stopPropagation();
    if (phase === 'move' && Date.now() - lastMove.current < 120) return;
    if (phase === 'move') lastMove.current = Date.now();
    const box = image.current.getBoundingClientRect(),
      size = shown.current.viewport;
    const scale = Math.min(box.width / size.width, box.height / size.height),
      left = box.x + (box.width - size.width * scale) / 2,
      top = box.y + (box.height - size.height * scale) / 2;
    const x = (event.clientX - left) / scale,
      y = (event.clientY - top) / scale;
    if (
      phase === 'down' &&
      (x < 0 || y < 0 || x >= size.width || y >= size.height)
    )
      return;
    if (phase === 'down') {
      event.currentTarget.setPointerCapture(event.pointerId);
      keyboard.current?.focus({ preventScroll: true });
    }
    if (
      phase === 'up' &&
      event.currentTarget.hasPointerCapture(event.pointerId)
    )
      event.currentTarget.releasePointerCapture(event.pointerId);
    void send(
      {
        op: 'pointer',
        phase,
        x: Math.max(0, Math.min(size.width - 1, x)),
        y: Math.max(0, Math.min(size.height - 1, y)),
        viewport: shown.current.viewport,
        button:
          event.button === 2 ? 'right' : event.button === 1 ? 'middle' : 'left',
      },
      shown.current.target,
    );
  }
  const session = entry?.session;
  const activeURL = session?.pages.find(
    (p) => p.id === session.activePageId,
  )?.url;
  useEffect(() => {
    if (activeURL) setAddress(activeURL);
    else if (entry?.url) setAddress(entry.url);
  }, [activeURL, entry?.url]);
  return (
    <div
      ref={root}
      className="browser-view"
      data-testid={`browser-${options.nodeId}`}
      onKeyDown={(e) => e.stopPropagation()}
    >
      <div className="browser-toolbar">
        <button
          aria-label="Browser back"
          title="Back"
          disabled={!owns}
          onClick={() => void send({ op: 'back' })}
        >
          <ArrowLeft size={13} />
        </button>
        <button
          aria-label="Browser forward"
          title="Forward"
          disabled={!owns}
          onClick={() => void send({ op: 'forward' })}
        >
          <ArrowRight size={13} />
        </button>
        <button
          aria-label="Reload browser page"
          title="Reload page"
          disabled={!owns}
          onClick={() => void send({ op: 'reload' })}
        >
          <RotateCw size={12} />
        </button>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void perform(async () => {
              const url = BrowserURLSchema.parse(address);
              if (!workspace) throw new Error('Canvas saving unavailable');
              const state = workspace.snapshot();
              workspace.update({
                ...state.graph,
                nodes: state.graph.nodes.map((n) =>
                  n.id === options.nodeId
                    ? { ...n, data: { ...n.data, url } }
                    : n,
                ),
              });
              await ensureSaved();
              if (live.current) {
                if (!leases.has(key)) await takeControl();
                await command({ op: 'navigate', url });
              }
            });
          }}
        >
          <input
            aria-label="Browser address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            spellCheck={false}
          />
        </form>
        <button
          aria-label="Fullscreen browser"
          title="Fullscreen"
          onClick={() =>
            void (
              document.fullscreenElement
                ? document.exitFullscreen()
                : root.current?.requestFullscreen()
            )?.catch(report)
          }
        >
          <Maximize size={12} />
        </button>
      </div>
      {session && (
        <div className="browser-tabs" role="tablist" aria-label="Browser tabs">
          {session.pages.map((page, i) => (
            <button
              role="tab"
              aria-selected={page.id === session.activePageId}
              title={page.url}
              disabled={!owns}
              key={page.id}
              onClick={() => void send({ op: 'selectTab', pageId: page.id })}
            >
              {' '}
              {i + 1} ·{' '}
              {page.url === 'about:blank'
                ? 'New tab'
                : page.url.replace(/^https?:\/\//, '').slice(0, 40)}
            </button>
          ))}
          <button
            aria-label="New browser tab"
            disabled={!owns}
            onClick={() => void send({ op: 'newTab', url: 'about:blank' })}
          >
            <Plus size={12} />
          </button>
          <button
            aria-label="Close browser tab"
            disabled={!owns}
            onClick={() => void send({ op: 'closeTab' })}
          >
            <X size={12} />
          </button>
        </div>
      )}
      <div className="browser-controls">
        {!session ? (
          <button
            disabled={busy}
            onClick={() =>
              void perform(async () => {
                await ensureSaved();
                const next = await api.start(identity, actor);
                if (!mounted.current) return;
                updateSession(next);
                await refresh();
                await takeControl();
              })
            }
          >
            <Play size={11} />
            Start browser
          </button>
        ) : (
          <>
            <button
              onClick={() =>
                void perform(async () => {
                  if (!leases.has(key)) await takeControl(true);
                  await command({ op: 'stop' });
                })
              }
            >
              <Square size={10} />
              Stop browser
            </button>
            {owns ? (
              <button
                onClick={() =>
                  void perform(async () => {
                    const lease = leases.get(key);
                    if (lease) await api.release(lease);
                    leases.delete(key);
                  })
                }
              >
                <Unlock size={11} />
                Release control
              </button>
            ) : (
              <button
                disabled={busy}
                onClick={() =>
                  void perform(() => takeControl(Boolean(entry?.owner)))
                }
              >
                <Lock size={11} />
                {entry?.owner ? 'Take over control' : 'Take control'}
              </button>
            )}
          </>
        )}
        <button disabled={busy} onClick={() => void perform(refresh)}>
          Reconnect
        </button>
        {!session && (
          <button
            disabled={busy}
            onClick={() => {
              if (
                confirm(
                  'Clear all saved cookies and browsing storage for this browser?',
                )
              )
                void perform(async () => {
                  await ensureSaved();
                  await api.clearProfile(identity, actor);
                });
            }}
          >
            Clear browsing data
          </button>
        )}
        <span
          className={`browser-status ${session && connected ? 'running' : ''}`}
          data-testid="browser-status"
        >
          {!connected ? 'Disconnected' : session ? 'Running' : 'Stopped'}
        </span>
      </div>
      <div
        ref={surface}
        className={`browser-screen${owns ? ' interactive' : ''}`}
        data-testid="browser-screen"
        onPointerDown={(e) => pointer(e, 'down')}
        onPointerMove={(e) => pointer(e, 'move')}
        onPointerUp={(e) => pointer(e, 'up')}
        onPointerCancel={(e) => pointer(e, 'up')}
        onContextMenu={(e) => e.preventDefault()}
      >
        {frame ? (
          <img
            ref={image}
            alt="Live Chromium page"
            draggable={false}
            src={`data:${frame.mime};base64,${frame.data}`}
          />
        ) : (
          <div className="browser-idle">
            <span>◎</span>
            <strong>
              {session ? 'Connecting to Chromium…' : 'Your browser, on canvas.'}
            </strong>
            <p>
              {session
                ? 'Waiting for the first frame.'
                : 'Start explicitly. Saved profiles keep cookies and site storage.'}
            </p>
            <small>
              {entry?.mode ?? 'persistent'} profile · isolated to this project
            </small>
          </div>
        )}
        <textarea
          ref={keyboard}
          className="browser-keyboard"
          aria-label="Browser keyboard input"
          autoComplete="off"
          spellCheck={false}
          disabled={!owns}
          onCompositionStart={() => {
            composing.current = true;
          }}
          onCompositionEnd={(e) => {
            composing.current = false;
            const text = e.currentTarget.value;
            e.currentTarget.value = '';
            if (text && shown.current)
              void send({ op: 'type', text }, shown.current.target);
          }}
          onChange={(e) => {
            if (!composing.current) {
              const text = e.target.value;
              e.target.value = '';
              if (text && shown.current)
                void send({ op: 'type', text }, shown.current.target);
            }
          }}
          onKeyDown={(e) => {
            e.stopPropagation();
            if (
              e.nativeEvent.isComposing ||
              ['Control', 'Meta', 'Alt', 'Shift'].includes(e.key)
            )
              return;
            if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey)
              return;
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v') return;
            e.preventDefault();
            const key = [
              e.ctrlKey ? 'Control' : '',
              e.metaKey ? 'Meta' : '',
              e.altKey ? 'Alt' : '',
              e.shiftKey ? 'Shift' : '',
              e.key === ' ' ? 'Space' : e.key,
            ]
              .filter(Boolean)
              .join('+');
            if (shown.current)
              void send({ op: 'press', key }, shown.current.target);
          }}
        />
      </div>
      <footer className="browser-footer">
        {session && <span>Sandboxed Chromium</span>}
        <span title={identity.browserId}>ID {identity.browserId}</span>
        <span>
          {session
            ? `${session.viewport.width} × ${session.viewport.height}`
            : 'No process'}
        </span>
        <span data-testid="browser-owner">
          {entry?.owner
            ? `${entry.owner.actor.kind}: ${entry.owner.actor.id}`
            : 'Control available'}
        </span>
        <span title={entry?.wiredAgentIds.join(', ')}>
          {entry?.wiredAgentIds.length ?? 0} agent wires
        </span>
      </footer>
      {error && (
        <div className="browser-error" role="alert">
          {error}
          <button
            aria-label="Dismiss browser error"
            onClick={() => setError('')}
          >
            ×
          </button>
        </div>
      )}
    </div>
  );
}
