import { createElement, lazy, Suspense } from 'react';
import type { UIPlugin, UIPluginProps } from '@devlab/ui-contracts';
const View = lazy(() =>
  import('./view.tsx').then((m) => ({ default: m.BrowserView })),
);
function Contribution(props: UIPluginProps) {
  return createElement(
    Suspense,
    { fallback: createElement('div', null, 'Loading browser…') },
    createElement(View, props),
  );
}
export const browserPanel: UIPlugin = {
  id: 'ui-browser',
  apiVersion: 1,
  title: 'Chromium browser',
  slot: 'browser',
  Component: Contribution,
};
