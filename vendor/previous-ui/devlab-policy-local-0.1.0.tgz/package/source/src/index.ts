import { createHash } from 'node:crypto';
import {
  canonicalJson,
  ToolRequestSchema,
  type PluginDefinition,
  type PermissionPolicy,
} from '@devlab/contracts';

export function localPolicy(
  options: { deny?: boolean } = {},
): PluginDefinition {
  return {
    manifest: {
      id: 'policy-local',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['policy'],
      requires: [],
      capabilities: [],
      reload: 'restart',
    },
    activate(scope) {
      const policy: PermissionPolicy = {
        async authorize(input) {
          const request = ToolRequestSchema.parse(input);
          if (options.deny)
            return {
              allowed: false,
              reason: 'The local profile denies tool execution',
            };
          const requestHash = createHash('sha256')
            .update(canonicalJson(request))
            .digest('hex');
          Object.freeze(request.args);
          Object.freeze(request);
          return {
            allowed: true,
            authorized: Object.freeze({
              authorizationVersion: 1 as const,
              request,
              requestHash,
              policyVersion: 'echo-only/1',
            }),
          };
        },
      };
      scope.provide('policy', policy);
    },
  };
}
