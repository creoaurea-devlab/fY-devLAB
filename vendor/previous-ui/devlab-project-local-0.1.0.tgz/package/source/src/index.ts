import {
  readFile,
  readdir,
  mkdir,
  realpath,
  lstat,
  open,
  rename,
  link,
  unlink,
} from 'node:fs/promises';
import { constants } from 'node:fs';
import {
  resolve,
  dirname,
  extname,
  basename,
  sep,
  isAbsolute,
} from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import {
  ApplicationError,
  CreateProjectSchema,
  OpenProjectSchema,
  ProjectSlugSchema,
  WriteProjectFileSchema,
  ProjectTreeSchema,
  type PluginDefinition,
  type Project,
  type ProjectCatalog,
  type ProjectTree,
  type RegistryItem,
} from '@devlab/contracts';
import { moduleFiles, webProjectFiles } from './template.ts';
const omitted = new Set([
  'node_modules',
  'dist',
  'vendor',
  'build',
  'build-output',
  'coverage',
  'secrets',
  'out',
  'release',
  '__pycache__',
]);
const textExtensions = new Set([
  '.ts',
  '.tsx',
  '.js',
  '.jsx',
  '.mjs',
  '.cjs',
  '.mts',
  '.cts',
  '.json',
  '.md',
  '.css',
  '.html',
  '.svg',
  '.txt',
  '.yaml',
  '.yml',
]);
const hash = (value: string | Buffer) =>
  createHash('sha256').update(value).digest('hex');
const denied = (message = 'Path is outside the selected project') =>
  new ApplicationError('PATH_DENIED', message);
const conflict = (message: string) => new ApplicationError('CONFLICT', message);

/** App-level path scope only. Interactive shells still have the local user's privileges. */
export function localProjects(options: {
  root: string;
  projectsRoot: string;
  terminalRoot?: string;
  registryFile?: string;
}): PluginDefinition {
  return {
    manifest: {
      id: 'project-local',
      version: '1.0.0',
      apiVersion: 1,
      provides: ['projects', 'workspace'],
      requires: [],
      capabilities: ['workspace:local'],
      reload: 'restart',
    },
    async activate(scope) {
      const root = await realpath(resolve(options.root));
      const optionsRoot = root;
      const projectsRoot = resolve(options.projectsRoot);
      await mkdir(projectsRoot, { recursive: true });
      if ((await realpath(projectsRoot)) !== projectsRoot)
        throw denied('Project directory cannot be a symlink');
      const registryFile = resolve(options.registryFile ?? resolve(projectsRoot, '.devlab-roots.json'));
      type Registration = { id: string; root: string; label: string };
      let registrations: Registration[] = [];
      try {
        const info = await lstat(registryFile);
        if (!info.isFile() || info.isSymbolicLink() || info.size > 131072) throw denied('Invalid project root registry');
        const parsed: unknown = JSON.parse(await readFile(registryFile, 'utf8'));
        if (!Array.isArray(parsed) || parsed.length > 100 || parsed.some(v =>
          !v || typeof v !== 'object' || Object.keys(v).sort().join(',') !== 'id,label,root' ||
          !/^folder-[a-f0-9]{24}$/.test(v.id) || !isAbsolute(v.root) || resolve(v.root) !== v.root ||
          typeof v.label !== 'string' || !v.label.length || v.label.length > 120 ||
          v.id !== 'folder-' + hash(v.root).slice(0, 24)) ||
          new Set(parsed.map(v => v.id)).size !== parsed.length) throw denied('Invalid project root registry');
        registrations = parsed;
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
      }
      async function saveRegistrations(next: Registration[]) {
        await mkdir(dirname(registryFile), { recursive: true });
        const temporary = registryFile + '.' + randomUUID() + '.tmp';
        const fd = await open(temporary, 'wx', 0o600);
        try {
          await fd.writeFile(JSON.stringify(next, null, 2) + '\n');
          await fd.sync();
          await fd.close();
          await rename(temporary, registryFile);
          registrations = next;
        } finally {
          await fd.close().catch(() => {});
          await unlink(temporary).catch(() => {});
        }
      }
      let alive = true;
      const pending = new Map<string, Promise<unknown>>();
      const active = () => {
        if (!alive)
          throw new ApplicationError(
            'NOT_READY',
            'Project adapter is disposed',
          );
      };
      const base: Project = {
        id: 'default',
        label: 'devLAB',
        base: true,
        location: '.',
        workspaceId: hash(root),
      };
      async function project(
        id: string,
      ): Promise<{ root: string; value: Project }> {
        active();
        if (id === 'default') return { root, value: base };
        const registered = registrations.find(p => p.id === id);
        if (registered) {
          if ((await realpath(registered.root).catch(() => '')) !== registered.root ||
            !(await lstat(registered.root)).isDirectory()) throw denied('Registered folder is unavailable');
          return { root: registered.root, value: { id, label: registered.label, base: false, location: registered.root, available: true } };
        }
        ProjectSlugSchema.parse(id);
        const target = resolve(projectsRoot, id);
        if (
          (await realpath(projectsRoot)) !== projectsRoot ||
          (await realpath(target).catch(() => '')) !== target ||
          !(await lstat(target)).isDirectory()
        )
          throw denied('Project is unavailable');
        let label = id;
        try {
          const config = JSON.parse(
            await safeRead(target, 'hood.project.json'),
          );
          if (typeof config.label === 'string')
            label = config.label.slice(0, 120) || id;
        } catch {
          /* Externally created directories need no metadata. */
        }
        return {
          root: target,
          value: { id, label, base: false, location: 'projects/' + id },
        };
      }
      function parts(path: string): string[] {
        const values = path.split('/');
        if (
          !path ||
          path.length > 512 ||
          isAbsolute(path) ||
          path.includes('\\') ||
          path.includes('\0') ||
          values.some(
            (p) =>
              !p ||
              p === '.' ||
              p === '..' ||
              p.startsWith('.') ||
              p.includes(':') ||
              omitted.has(p),
          )
        )
          throw denied();
        return values;
      }
      async function target(
        root: string,
        path: string,
        parents = false,
      ): Promise<string> {
        const values = parts(path);
        const absolute = resolve(root, ...values);
        if (
          root === optionsRoot &&
          (absolute === projectsRoot || absolute.startsWith(projectsRoot + sep))
        )
          throw denied();
        let cursor = root;
        if ((await realpath(root)) !== root) throw denied();
        for (const value of values.slice(0, -1)) {
          cursor = resolve(cursor, value);
          if (parents)
            await mkdir(cursor).catch((error) => {
              if (error.code !== 'EEXIST') throw error;
            });
          if (
            (await realpath(cursor).catch(() => '')) !== cursor ||
            !(await lstat(cursor)).isDirectory()
          )
            throw denied();
        }
        const result = resolve(root, ...values);
        const info = await lstat(result).catch((error) => {
          if (error.code === 'ENOENT') return null;
          throw error;
        });
        if (info?.isSymbolicLink()) throw denied();
        return result;
      }
      async function safeRead(root: string, path: string): Promise<string> {
        const file = await target(root, path);
        const fd = await open(
          file,
          constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK,
        );
        try {
          const stat = await fd.stat();
          if (!stat.isFile() || stat.size > 131072)
            throw denied('Text preview exceeds 128 KiB or is unavailable');
          if (
            process.platform === 'linux' &&
            (await realpath('/proc/self/fd/' + fd.fd)) !== file
          )
            throw denied();
          const data = await fd.readFile();
          if (data.length > 131072 || data.includes(0))
            throw denied('Binary or oversized file has no text preview');
          return data.toString('utf8');
        } finally {
          await fd.close();
        }
      }
      async function serial<T>(
        key: string,
        operation: () => Promise<T>,
      ): Promise<T> {
        active();
        const previous = pending.get(key) ?? Promise.resolve();
        const result = previous
          .catch(() => {})
          .then(() => {
            active();
            return operation();
          });
        pending.set(key, result);
        try {
          return await result;
        } finally {
          if (pending.get(key) === result) pending.delete(key);
        }
      }
      const service: ProjectCatalog = {
        async list() {
          active();
          const list: Project[] = [base];
          if ((await realpath(projectsRoot)) !== projectsRoot) throw denied();
          for (const dir of (
            await readdir(projectsRoot, { withFileTypes: true })
          ).sort((a, b) => a.name.localeCompare(b.name))) {
            if (list.length >= 101) break;
            if (
              !dir.isDirectory() ||
              !ProjectSlugSchema.safeParse(dir.name).success
            )
              continue;
            try {
              list.push((await project(dir.name)).value);
            } catch {
              /* Ignore links/racing removal. */
            }
          }
          for (const registered of registrations) {
            try { list.push((await project(registered.id)).value); }
            catch { list.push({ id: registered.id, label: registered.label, base: false, location: registered.root, available: false }); }
          }
          return list;
        },
        async root(id) { return (await project(id)).root; },
        async open(input) {
          const command = OpenProjectSchema.parse(input);
          return serial('project-create', async () => {
            if (!isAbsolute(command.path) || command.path.includes('\0')) throw denied('Open Folder requires an absolute directory');
            const path = await realpath(command.path).catch(() => { throw denied('Folder is unavailable'); });
            if (!(await lstat(path)).isDirectory()) throw denied('Open Folder requires a directory');
            if (path === root) return base;
            // Preserve child-project IDs even when opened through a symlink alias.
            if (dirname(path) === projectsRoot && ProjectSlugSchema.safeParse(basename(path)).success)
              return (await project(basename(path))).value;
            const existing = registrations.find(p => p.root === path);
            if (existing) return (await project(existing.id)).value;
            if (registrations.length >= 100) throw conflict('Registered folder limit reached (100)');
            const id = 'folder-' + hash(path).slice(0, 24);
            if (await lstat(resolve(projectsRoot, id)).catch(() => null)) throw conflict('Project identity collision');
            const value = { id, root: path, label: command.label ?? (basename(path).slice(0, 120) || path) };
            await saveRegistrations([...registrations, value]);
            return (await project(id)).value;
          });
        },
        async forget(id) {
          return serial('project-create', async () => {
            if (!registrations.some(p => p.id === id)) throw denied('Only registered folders can be removed from the catalog');
            await saveRegistrations(registrations.filter(p => p.id !== id));
          });
        },
        async create(input) {
          const command = CreateProjectSchema.parse(input);
          return serial('project-create', async () => {
            if (registrations.some(p => p.id === command.id)) throw conflict('Project identity already registered');
            if ((await service.list()).length >= 101)
              throw conflict('Project limit reached (100 child projects)');
            if ((await realpath(projectsRoot)) !== projectsRoot) throw denied();
            const folder = resolve(projectsRoot, command.id);
            try {
              await mkdir(folder);
            } catch (error) {
              if ((error as NodeJS.ErrnoException).code === 'EEXIST')
                throw conflict('Project already exists');
              throw error;
            }
            await mkdir(resolve(folder, 'src'));
            const port=14000+(parseInt(hash(folder).slice(0,6),16)%40000);
            const files = webProjectFiles(command.id,command.label,port);
            for (const [path, text] of Object.entries(files)) {
              const fd = await open(resolve(folder, path), 'wx', 0o600);
              try {
                await fd.writeFile(text);
              } finally {
                await fd.close();
              }
            }
            return (await project(command.id)).value;
          });
        },
        async inspect(id) {
          const selected = await project(id),
            entries: ProjectTree['entries'] = [],
            stamp: unknown[] = [];
          let directories = 0;
          async function walk(folder: string) {
            if (++directories > 2048)
              throw denied('Project directory budget exceeded');
            const directory = folder
              ? await target(selected.root, folder)
              : selected.root;
            if (
              (await realpath(directory)) !== directory ||
              !(await lstat(directory)).isDirectory()
            )
              throw denied();
            for (const child of (
              await readdir(directory, { withFileTypes: true })
            ).sort((a, b) => a.name.localeCompare(b.name))) {
              if (
                child.name.startsWith('.') ||
                omitted.has(child.name) ||
                child.isSymbolicLink()
              )
                continue;
              const path = folder ? folder + '/' + child.name : child.name;
              if (
                selected.root === root &&
                resolve(root, path) === projectsRoot
              )
                continue;
              if (!child.isDirectory() && !child.isFile()) continue;
              if (entries.length >= 5000)
                throw denied('Project file budget exceeded');
              const info = await lstat(resolve(selected.root, path));
              if (info.isSymbolicLink()) continue;
              const directory = info.isDirectory();
              entries.push({
                path,
                kind: directory ? 'directory' : 'file',
                bytes: directory ? 0 : info.size,
                editable:
                  !directory &&
                  info.size <= 131072 &&
                  textExtensions.has(extname(path)) &&
                  !['AGENTS.md', 'CLAUDE.md', 'SKILL.md'].includes(
                    basename(path),
                  ),
              });
              stamp.push([path, info.size, info.mtimeMs, info.ino]);
              if (directory) await walk(path);
            }
          }
          await walk('');
          const items: RegistryItem[] = [
            {
              id: 'project:root',
              label: selected.value.label,
              kind: 'group',
              parentId: null,
              detail: selected.value.base
                ? 'Base devLAB project'
                : 'Project-scoped workspace',
            },
          ];
          const ids = new Map<string, string>([['', 'project:root']]);
          for (const entry of entries) {
            const parent =
              dirname(entry.path) === '.' ? '' : dirname(entry.path);
            const module =
              entry.kind === 'directory' &&
              ['plugins', 'packages', 'apps', 'modules', 'features'].includes(
                basename(parent),
              );
            const id =
              (entry.kind === 'file' ? 'file:' : module ? 'module:' : 'dir:') +
              entry.path;
            ids.set(entry.path, id);
            items.push({
              id,
              label: basename(entry.path),
              kind:
                entry.kind === 'file'
                  ? 'file'
                  : module
                    ? 'module'
                    : 'directory',
              parentId: ids.get(parent)!,
              path: entry.path,
              bytes: entry.bytes,
              detail:
                entry.kind === 'directory'
                  ? module
                    ? 'Contract / adapter / plugin module'
                    : 'Directory'
                  : entry.editable
                    ? 'Editable text file'
                    : `${entry.bytes} bytes · metadata only`,
            });
          }
          return ProjectTreeSchema.parse({
            project: selected.value,
            revision: hash(JSON.stringify(stamp)),
            scannedAt: new Date().toISOString(),
            entries,
            graph: { items, edges: [] },
          });
        },
        async read(id, path) {
          const selected = await project(id),
            text = await safeRead(selected.root, path);
          return { path, text, sha256: hash(text) };
        },
        async write(input) {
          const command = WriteProjectFileSchema.parse(input);
          if (
            Buffer.byteLength(command.text) > 131072 ||
            command.text.includes('\0')
          )
            throw denied('Text must be at most 128 KiB');
          if (
            !textExtensions.has(extname(command.path)) ||
            ['AGENTS.md', 'CLAUDE.md', 'SKILL.md'].includes(
              basename(command.path),
            )
          )
            throw denied('This file is not editable');
          parts(command.path);
          return serial(command.projectId + ':' + command.path, async () => {
            const selected = await project(command.projectId);
            const file = await target(selected.root, command.path, true);
            const exists = await lstat(file).catch((error) => {
              if (error.code === 'ENOENT') return null;
              throw error;
            });
            if (exists && command.expectedHash === null)
              throw conflict('File already exists; open it before editing');
            if (!exists && command.expectedHash !== null)
              throw conflict('File was removed; reopen before saving');
            if (
              exists &&
              hash(await safeRead(selected.root, command.path)) !==
                command.expectedHash
            )
              throw conflict('File changed on disk; reopen before saving');
            const temporary = resolve(
              dirname(file),
              '.devlab-' + randomUUID() + '.tmp',
            );
            const fd = await open(temporary, 'wx', exists?.mode ?? 0o600);
            try {
              await fd.writeFile(command.text);
              await fd.sync();
              await fd.close();
              await target(selected.root, command.path);
              if (command.expectedHash === null)
                await link(temporary, file).catch((error) => {
                  if (error.code === 'EEXIST')
                    throw conflict('File already exists');
                  throw error;
                });
              else {
                if (
                  hash(await safeRead(selected.root, command.path)) !==
                  command.expectedHash
                )
                  throw conflict('File changed on disk');
                await rename(temporary, file);
              }
              return {
                path: command.path,
                text: command.text,
                sha256: hash(command.text),
              };
            } finally {
              await fd.close().catch(() => {});
              await unlink(temporary).catch(() => {});
            }
          });
        },
        async createModule(id, path) {
          parts(path);
          return serial(id + ':module:' + path, async () => {
            const selected = await project(id),
              folder = await target(selected.root, path, true);
            try {
              await mkdir(folder);
            } catch (error) {
              if ((error as NodeJS.ErrnoException).code === 'EEXIST')
                throw conflict('Module already exists');
              throw error;
            }
            const paths: string[] = [];
            for (const [name, text] of Object.entries(
              moduleFiles(basename(path)),
            )) {
              const file = path + '/' + name;
              const fd = await open(
                await target(selected.root, file),
                'wx',
                0o600,
              );
              try {
                await fd.writeFile(text);
              } finally {
                await fd.close();
              }
              paths.push(file);
            }
            return { paths };
          });
        },
      };
      scope.onDispose(async () => {
        alive = false;
        await Promise.allSettled([...pending.values()]);
      });
      scope.provide('projects', service);
      scope.provide('workspace', {
        async resolve(id, cwd) {
          const selected = await project(id);
          const actualRoot =
            id === 'default' && options.terminalRoot
              ? await realpath(resolve(options.terminalRoot))
              : selected.root;
          if (isAbsolute(cwd) || cwd.includes('\0')) throw denied();
          const result = await realpath(resolve(actualRoot, cwd)).catch(() => {
            throw denied();
          });
          if (result !== actualRoot && !result.startsWith(actualRoot + sep))
            throw denied();
          if (!(await lstat(result)).isDirectory()) throw denied();
          return result;
        },
      });
    },
  };
}
